-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 19, 2018 at 07:09 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kijacho`
--
CREATE DATABASE IF NOT EXISTS `kijacho` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `kijacho`;

-- --------------------------------------------------------

--
-- Table structure for table `health_officer`
--

CREATE TABLE IF NOT EXISTS `health_officer` (
  `officer_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `username` varchar(100) NOT NULL,
  `health_center` varchar(20) NOT NULL,
  `phone_no` varchar(13) NOT NULL,
  `mtaa` varchar(13) NOT NULL,
  `wilaya` varchar(20) NOT NULL,
  PRIMARY KEY (`officer_id`),
  KEY `idx_health_officer_username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `health_officer`
--

INSERT INTO `health_officer` (`officer_id`, `fname`, `lname`, `username`, `health_center`, `phone_no`, `mtaa`, `wilaya`) VALUES
(13, 'admin', 'admin', 'admin', 'admin', '12345678', 'admin', 'admin'),
(17, 'salum', 'siasa', 'salumsi', 'jkt ruvu k', '255673678796', 'kikosini', 'kibaha'),
(18, 'rehema', 'shemangale', 'rehemash', 'kinyerezi dispensary', '255715381132', 'kange', 'ilala');

-- --------------------------------------------------------

--
-- Table structure for table `maelezo_uzazi`
--

CREATE TABLE IF NOT EXISTS `maelezo_uzazi` (
  `uzazi_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_id` int(11) NOT NULL,
  `no_mimba_kusajiliwa` int(11) NOT NULL,
  `kujifungua_date` date NOT NULL,
  `saa_kujifungua` time NOT NULL,
  `njia_yakujifungua` varchar(20) NOT NULL,
  `sababu_kupasuliwa` varchar(50) DEFAULT NULL,
  `kondo_limetoka_date` date NOT NULL,
  `saa_kondokutoka` time NOT NULL,
  `kondo_na_membreni_kutoka` enum('ndio','hapana',',') NOT NULL,
  `kiasi_damu` varchar(20) NOT NULL,
  `ergometrine` varchar(20) NOT NULL,
  `msamba_kuchanika` varchar(15) NOT NULL,
  `name_alieshona_msamba` varchar(20) DEFAULT NULL,
  `cheo` varchar(20) DEFAULT NULL,
  `BP` varchar(10) NOT NULL,
  `hatua_ya_kwanza` time NOT NULL,
  `hatua_ya_pili` time NOT NULL,
  `hatua_ya_tatu` time NOT NULL,
  `name_mzalishaji` varchar(20) NOT NULL,
  `baada_ya_kujifungua_arv` varchar(15) DEFAULT NULL,
  `mtoto_jinsia` varchar(10) NOT NULL,
  `uzito_mtoto` int(11) NOT NULL,
  `mtoto_amepewa_arv` varchar(10) DEFAULT NULL,
  `lishe_ya_mtoto` varchar(10) NOT NULL,
  `apgar1` varchar(15) DEFAULT NULL,
  `apgar5` varchar(12) NOT NULL,
  `mengineyo` varchar(20) NOT NULL,
  `kituo` varchar(15) NOT NULL,
  PRIMARY KEY (`uzazi_id`),
  KEY `idx_maelezo_uzazi_p_id` (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `maelezo_uzazi`
--

INSERT INTO `maelezo_uzazi` (`uzazi_id`, `p_id`, `no_mimba_kusajiliwa`, `kujifungua_date`, `saa_kujifungua`, `njia_yakujifungua`, `sababu_kupasuliwa`, `kondo_limetoka_date`, `saa_kondokutoka`, `kondo_na_membreni_kutoka`, `kiasi_damu`, `ergometrine`, `msamba_kuchanika`, `name_alieshona_msamba`, `cheo`, `BP`, `hatua_ya_kwanza`, `hatua_ya_pili`, `hatua_ya_tatu`, `name_mzalishaji`, `baada_ya_kujifungua_arv`, `mtoto_jinsia`, `uzito_mtoto`, `mtoto_amepewa_arv`, `lishe_ya_mtoto`, `apgar1`, `apgar5`, `mengineyo`, `kituo`) VALUES
(3, 34, 1, '2018-09-08', '02:01:00', 'kawaida', '', '2018-09-28', '00:03:00', 'ndio', '23', 'hapana', 'umechanika', 'said', 'doctor', '', '02:03:00', '04:03:00', '06:32:00', 'said', 'hakunywa', 'kiume', 46, 'hakunywa', 'EBF', '2', '3', '', 'kinyerezi dispe');

-- --------------------------------------------------------

--
-- Table structure for table `muendelezo_uchungu`
--

CREATE TABLE IF NOT EXISTS `muendelezo_uchungu` (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `tarehe` date NOT NULL,
  `time` time NOT NULL,
  `no_mimba_kusajiliwa` int(11) NOT NULL,
  `checkk` int(11) NOT NULL,
  `mapigo_moyo_mtoto` int(11) NOT NULL,
  `maji_chupa` varchar(10) NOT NULL,
  `kubonywa_kichwa` varchar(10) NOT NULL,
  `cervix` int(11) NOT NULL,
  `kichwa_kutelemka` int(11) NOT NULL,
  `maumivu_uchungu` varchar(10) NOT NULL,
  `dawa` varchar(15) NOT NULL DEFAULT 'no',
  `mapigo_moyo_mama` int(11) NOT NULL,
  `bLood_pressure` int(11) NOT NULL,
  `albumin` varchar(10) NOT NULL,
  `sukari` varchar(10) NOT NULL,
  `acetone` varchar(10) NOT NULL,
  `joto_mwili` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  PRIMARY KEY (`u_id`),
  KEY `p_id` (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `muendelezo_uchungu`
--

INSERT INTO `muendelezo_uchungu` (`u_id`, `tarehe`, `time`, `no_mimba_kusajiliwa`, `checkk`, `mapigo_moyo_mtoto`, `maji_chupa`, `kubonywa_kichwa`, `cervix`, `kichwa_kutelemka`, `maumivu_uchungu`, `dawa`, `mapigo_moyo_mama`, `bLood_pressure`, `albumin`, `sukari`, `acetone`, `joto_mwili`, `p_id`) VALUES
(4, '2018-09-07', '02:22:00', 1, 1, 68, 'bado', 'wastani', 3, 3, 'kidogo', 'dawa', 67, 67, 'hakuna', 'hakuna', 'hakuna', 45, 34),
(5, '2018-09-07', '02:30:00', 1, 2, 69, 'bado', 'hakuna', 4, 2, 'kidogo', 'dawa', 75, 75, 'hakuna', 'hakuna', 'hakuna', 45, 34),
(6, '2018-09-07', '04:05:00', 1, 3, 60, 'bado', 'hakuna', 5, 2, 'kidogo', '', 89, 89, 'hakuna', 'hakuna', 'hakuna', 45, 34);

-- --------------------------------------------------------

--
-- Table structure for table `other_inf`
--

CREATE TABLE IF NOT EXISTS `other_inf` (
  `inf_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_id` int(11) NOT NULL,
  `Age` int(11) NOT NULL,
  `mimba_no` int(11) NOT NULL,
  `no_mimba_kusajiliwa` int(11) NOT NULL,
  `E_level` varchar(20) NOT NULL,
  `wilaya` varchar(20) NOT NULL,
  `mtaa` varchar(20) NOT NULL,
  `jina_mwenyekiti` varchar(20) NOT NULL,
  `clinic_name` varchar(20) NOT NULL,
  `kazi` varchar(20) NOT NULL,
  `no_mimba_zilizohalibika` int(11) NOT NULL,
  `umri_mimba_zilipoalibika` int(11) DEFAULT NULL,
  `mwaka_mimba_ilipohalibika` int(11) DEFAULT NULL,
  `miaka_mimba_mwisho` int(11) DEFAULT NULL,
  `njia_yakujifungua` enum('ndio','hapana',',') DEFAULT NULL,
  `mtoto_mfu` enum('ndio','hapana',',') DEFAULT NULL,
  `moyo` enum('ndio','hapana',',') DEFAULT NULL,
  `kisukari` enum('ndio','hapana',',') DEFAULT NULL,
  `kifua_kikuu` enum('ndio','hapana',',') DEFAULT NULL,
  `kilema_nyonga` enum('ndio','hapana',',') DEFAULT NULL,
  `kimo` enum('ndio','hapana',',') DEFAULT NULL,
  `kondo_kukwama` enum('ndio','hapana',',') DEFAULT NULL,
  `damu_nyingi` enum('ndio','hapana',',') DEFAULT NULL,
  `date_hedhi` date NOT NULL,
  `date_kujifungua` date NOT NULL,
  `nokuzaa` int(11) NOT NULL,
  `watoto_hai` int(11) NOT NULL,
  `no_chandarua` int(11) NOT NULL,
  `blood_group` varchar(10) NOT NULL,
  `vipimo_vingine` varchar(10) NOT NULL,
  PRIMARY KEY (`inf_id`),
  KEY `idx_previous_inf_p_id` (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `other_inf`
--

INSERT INTO `other_inf` (`inf_id`, `p_id`, `Age`, `mimba_no`, `no_mimba_kusajiliwa`, `E_level`, `wilaya`, `mtaa`, `jina_mwenyekiti`, `clinic_name`, `kazi`, `no_mimba_zilizohalibika`, `umri_mimba_zilipoalibika`, `mwaka_mimba_ilipohalibika`, `miaka_mimba_mwisho`, `njia_yakujifungua`, `mtoto_mfu`, `moyo`, `kisukari`, `kifua_kikuu`, `kilema_nyonga`, `kimo`, `kondo_kukwama`, `damu_nyingi`, `date_hedhi`, `date_kujifungua`, `nokuzaa`, `watoto_hai`, `no_chandarua`, `blood_group`, `vipimo_vingine`) VALUES
(3, 34, 25, 1, 1, 'masters', 'ilala', 'majumba sita', 'mambokiki', 'kinyerezi dispensary', 'project mananger', 0, 0, 0, 0, 'hapana', 'hapana', 'hapana', 'hapana', 'ndio', 'ndio', 'ndio', 'hapana', 'hapana', '2018-01-01', '2018-09-07', 0, 0, 12, 'AB', 'hakuna'),
(4, 35, 24, 1, 1, 'degree', 'ilala', 'kinyere', 'chngandevu', 'kinyerezi dispensary', 'mhasibu', 0, 0, 0, 0, 'hapana', 'hapana', 'hapana', 'ndio', 'ndio', 'ndio', 'hapana', 'hapana', 'hapana', '2018-03-05', '2019-02-09', 0, 0, 23, 'O', 'hakuna');

-- --------------------------------------------------------

--
-- Table structure for table `partner`
--

CREATE TABLE IF NOT EXISTS `partner` (
  `partner_id` int(11) NOT NULL AUTO_INCREMENT,
  `no_mimba_kusajiliwa` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `age` int(11) NOT NULL,
  `job` varchar(20) NOT NULL,
  `p_id` int(11) NOT NULL,
  `e_level` enum('primary','olevel_secondary','highlevel_secondary','certificate','diploma','degree','masters','phd',',') NOT NULL,
  PRIMARY KEY (`partner_id`),
  KEY `idx_partner_p_id` (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `partner`
--

INSERT INTO `partner` (`partner_id`, `no_mimba_kusajiliwa`, `name`, `age`, `job`, `p_id`, `e_level`) VALUES
(4, 1, 'joseph john', 29, 'mhasibu', 34, 'primary'),
(5, 1, 'Juma khamisi', 29, 'mhasibu', 35, 'degree');

-- --------------------------------------------------------

--
-- Table structure for table `pregnant_woman`
--

CREATE TABLE IF NOT EXISTS `pregnant_woman` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  PRIMARY KEY (`p_id`),
  KEY `idx_pregnant_woman_username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `pregnant_woman`
--

INSERT INTO `pregnant_woman` (`p_id`, `fname`, `lname`, `username`) VALUES
(34, 'happy', 'wilbert', 'happywi'),
(35, 'halima', 'ali', 'halimaal');

-- --------------------------------------------------------

--
-- Table structure for table `record_uchungu`
--

CREATE TABLE IF NOT EXISTS `record_uchungu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `p_id` int(11) NOT NULL,
  `no_mimba_kusajiliwa` int(11) NOT NULL,
  `jina_kituo` varchar(20) NOT NULL,
  `kulazwa_date` date NOT NULL,
  `uchungu_umeanza_date` date NOT NULL,
  `chupa_imepasuka` enum('ndio','hapana',',') NOT NULL,
  `date_chupakupasuka` date DEFAULT NULL,
  `umri_mimba` varchar(20) NOT NULL,
  `kimo_mimba` varchar(20) NOT NULL,
  `mlalo_mtoto` varchar(20) NOT NULL,
  `kitangulizi` varchar(20) NOT NULL,
  `sacral_promontary` enum('ndio','hapana',',') NOT NULL,
  `ischial_spines` enum('ndio','hapana',',') NOT NULL,
  `outlet_finyu` enum('ndio','hapana',',') NOT NULL,
  `nyonga_kubwa_yakutosha` enum('ndio','hapana',',') NOT NULL,
  `maoni` varchar(50) NOT NULL,
  `officer_name` varchar(20) NOT NULL,
  `cheo` varchar(20) NOT NULL,
  `chupa_imepasuka_bila_uchungu` enum('ndio','hapana',',') NOT NULL,
  `uchungu_kabla` enum('ndio','hapana',',') NOT NULL,
  `saa_toka_uchungu_uanze` enum('ndio','hapana',',') NOT NULL,
  `tangulizi_kibaya` enum('ndio','hapana',',') NOT NULL,
  `toka_damu_ukeni` enum('ndio','hapana',',') NOT NULL,
  `mapigo_mtoto_kubadilika` enum('ndio','hapana',',') NOT NULL,
  `homa` enum('ndio','hapana',',') NOT NULL,
  `kondo_lanyuma` enum('ndio','hapana',',') NOT NULL,
  `kifafa` enum('ndio','hapana',',') NOT NULL,
  `upungufu_damu` enum('ndio','hapana',',') NOT NULL,
  `nyonga_mtoto_mkubwa` enum('ndio','hapana',',') NOT NULL,
  `meconium` enum('ndio','hapana',',') NOT NULL,
  `saa_kulazwa` time NOT NULL,
  `saa_uchungu` time NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_record_uchungu` (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `record_uchungu`
--

INSERT INTO `record_uchungu` (`id`, `p_id`, `no_mimba_kusajiliwa`, `jina_kituo`, `kulazwa_date`, `uchungu_umeanza_date`, `chupa_imepasuka`, `date_chupakupasuka`, `umri_mimba`, `kimo_mimba`, `mlalo_mtoto`, `kitangulizi`, `sacral_promontary`, `ischial_spines`, `outlet_finyu`, `nyonga_kubwa_yakutosha`, `maoni`, `officer_name`, `cheo`, `chupa_imepasuka_bila_uchungu`, `uchungu_kabla`, `saa_toka_uchungu_uanze`, `tangulizi_kibaya`, `toka_damu_ukeni`, `mapigo_mtoto_kubadilika`, `homa`, `kondo_lanyuma`, `kifafa`, `upungufu_damu`, `nyonga_mtoto_mkubwa`, `meconium`, `saa_kulazwa`, `saa_uchungu`) VALUES
(21, 34, 1, 'kinyerezi dispensary', '2018-08-31', '2018-08-22', 'ndio', '2018-08-31', '40', '12', 'kichwa chin', 'kichwa', 'ndio', 'ndio', 'ndio', 'ndio', 'kujifungua kawaida', 'rehema', 'nurse', 'hapana', 'hapana', 'hapana', 'hapana', 'hapana', 'hapana', 'hapana', 'hapana', 'hapana', 'hapana', 'hapana', 'hapana', '11:23:00', '01:32:00');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(20) NOT NULL,
  `role` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` enum('active','not active','') NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `role`, `password`, `status`) VALUES
('admin', 'admin', 'd3710ca24e4424b9077a8b7e59eefb56032a62a4', 'active'),
('halimaal', 'p_woman', '2bbf3d2d37030e0bd616a1d5d200a2f47d341dd5', 'active'),
('happywi', 'p_woman', 'd43e0ad8150e7743d70e86c6725d13b788a4255c', 'active'),
('mamahealth', 'admin', 'aff4578bdac5257fd16d2b343f2f6d6de37fdee5', 'active'),
('rehemash', 'nurse', 'bafc6d7d5e1920194dd7ce3fccab75d2eaa6c9d2', 'active'),
('salumsi', 'nurse', 'c1445cd0dbab21f944f1e6bb0b80bb5623092985', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `ushauri`
--

CREATE TABLE IF NOT EXISTS `ushauri` (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_id` int(11) NOT NULL,
  `d_name` varchar(20) DEFAULT NULL,
  `maon` varchar(2000) NOT NULL,
  PRIMARY KEY (`u_id`),
  KEY `idx_ushauri_p_id` (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ushauri`
--

INSERT INTO `ushauri` (`u_id`, `p_id`, `d_name`, `maon`) VALUES
(2, 34, 'rehema shemangale', 'fanya mazoez ya viungo hasa kiuno');

-- --------------------------------------------------------

--
-- Table structure for table `visity_before_delivery`
--

CREATE TABLE IF NOT EXISTS `visity_before_delivery` (
  `visit_id` int(11) NOT NULL AUTO_INCREMENT,
  `visiti_no` int(11) DEFAULT NULL,
  `p_id` int(11) NOT NULL,
  `no_mimba_kusajiliwa` int(11) NOT NULL,
  `visit_date` date NOT NULL,
  `weight` varchar(20) NOT NULL,
  `blood_preassure` varchar(20) NOT NULL,
  `albumin` varchar(20) NOT NULL,
  `sukari_mkojo` varchar(20) NOT NULL,
  `umri_mimba` int(11) NOT NULL,
  `kimo_mimba` varchar(20) NOT NULL,
  `mlalo_mtoto` varchar(20) NOT NULL,
  `kitangulizi` varchar(20) DEFAULT NULL,
  `mtoto_kucheza` enum('ndio','hapana',',') DEFAULT NULL,
  `mapigo_moyo_mtoto` enum('yapo','hayapo',',') DEFAULT NULL,
  `kuvimba_miguu` varchar(20) NOT NULL,
  `dalili_za_hatari` enum('ndio','hapana',',') DEFAULT NULL,
  `uzazi_wa_mpango` enum('ndio','hapana',',') DEFAULT NULL,
  `magonjwa_ya_kujamiiana` enum('ndio','hapana',',') DEFAULT NULL,
  `return_date` date NOT NULL,
  `officer_name` varchar(20) NOT NULL,
  `cheo_muhudumu` varchar(20) NOT NULL,
  `hiv` enum('positive','negative',',') DEFAULT NULL,
  `adherence` enum('poor','good',',') DEFAULT NULL,
  `lishe_mtoto` varchar(10) NOT NULL,
  `damu` varchar(15) NOT NULL,
  `sulphadoxine` varchar(10) NOT NULL,
  `pepopunda` varchar(10) NOT NULL,
  `mebendazole` varchar(10) NOT NULL,
  `ctx` varchar(10) NOT NULL,
  `pmtct_dawa` varchar(10) NOT NULL,
  `art` int(11) NOT NULL,
  `folic` varchar(10) NOT NULL,
  PRIMARY KEY (`visit_id`),
  KEY `idx_visity_before_delivery_p_id` (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `visity_before_delivery`
--

INSERT INTO `visity_before_delivery` (`visit_id`, `visiti_no`, `p_id`, `no_mimba_kusajiliwa`, `visit_date`, `weight`, `blood_preassure`, `albumin`, `sukari_mkojo`, `umri_mimba`, `kimo_mimba`, `mlalo_mtoto`, `kitangulizi`, `mtoto_kucheza`, `mapigo_moyo_mtoto`, `kuvimba_miguu`, `dalili_za_hatari`, `uzazi_wa_mpango`, `magonjwa_ya_kujamiiana`, `return_date`, `officer_name`, `cheo_muhudumu`, `hiv`, `adherence`, `lishe_mtoto`, `damu`, `sulphadoxine`, `pepopunda`, `mebendazole`, `ctx`, `pmtct_dawa`, `art`, `folic`) VALUES
(28, 1, 34, 1, '2018-06-10', '67', '100', 'hakuna', 'hakuna', 14, '10', 'ubavu', 'miguu', 'ndio', 'hayapo', 'hapana', 'ndio', 'ndio', 'ndio', '2018-06-27', 'rehema', 'nurse', 'negative', 'good', 'EBF', '6', 'amepata', 'amepata', 'amepata', 'hajapata', 'hajapata', 0, 'amepata'),
(29, 2, 34, 1, '2018-06-27', '54', '23', 'hakuna', 'hakuna', 34, '13', 'ubavu', 'miguu', 'ndio', 'yapo', 'hapana', 'ndio', 'ndio', 'ndio', '2018-07-10', 'rehema', 'nurse', 'negative', 'poor', 'EBF', '5', 'amepata', 'amepata', 'amepata', 'amepata', 'amepata', 0, 'amepata'),
(30, 1, 35, 1, '2018-06-10', '50', '43', 'hakuna', 'hakuna', 20, '10', 'ubavu', 'miguu', 'ndio', 'yapo', 'hapana', 'ndio', 'ndio', 'ndio', '2018-06-23', 'rehema', 'nurse', 'positive', 'poor', 'EBF', '6', 'amepata', 'amepata', 'amepata', 'amepata', 'amepata', 0, 'amepata');

-- --------------------------------------------------------

--
-- Table structure for table `visit_after_delivery`
--

CREATE TABLE IF NOT EXISTS `visit_after_delivery` (
  `visit_id` int(11) NOT NULL AUTO_INCREMENT,
  `visit_no` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `no_mimba_kusajiliwa` int(11) NOT NULL,
  `visit_date` date NOT NULL,
  `joto_mwili` varchar(20) NOT NULL,
  `blood_preassure` varchar(20) NOT NULL,
  `hb` varchar(20) NOT NULL,
  `mtoto_ananyonya` varchar(10) NOT NULL,
  `maziwa_yanatoka` enum('ndio','hapana',',') NOT NULL,
  `mtoto_kunyonya_ndani_saa1` enum('ndio','hapana',',') NOT NULL,
  `chuchu_vidonda` enum('ndio','hapana',',') NOT NULL,
  `matiti_yamejaa` enum('ndio','hapana',',') NOT NULL,
  `matiti_majipu` enum('ndio','hapana',',') NOT NULL,
  `tumbo_uzazi_linanyea` enum('ndio','hapana',',') NOT NULL,
  `tumbo_maumivu_makali` enum('ndio','hapana',',') NOT NULL,
  `msamba_kuchanika` enum('ndio','hapana',',') NOT NULL,
  `msamba_alichanika` enum('ndio','hapana',',') NOT NULL,
  `aliongezewa_njia` enum('ndio','hapana',',') NOT NULL,
  `kidonda_kimepona` enum('ndio','hapana',',') NOT NULL,
  `kidonda_kinausaa` enum('ndio','hapana',',') NOT NULL,
  `kidonda_kimeachia` enum('ndio','hapana',',') NOT NULL,
  `lokia_inanuka` enum('ndio','hapana',',') NOT NULL,
  `lokia` enum('nyingi','wastani','kidogo',',') NOT NULL,
  `lokia_rangi_ngapi` varchar(20) NOT NULL,
  `hali_ya_akili` enum('mgonjwa','sio mgonjwa',',') NOT NULL,
  `ushauri_uzazi_wampango` enum('ndio','hapana',',') NOT NULL,
  `tiba_nyingine` varchar(50) DEFAULT NULL,
  `return_date` date NOT NULL,
  `officer_name` varchar(20) NOT NULL,
  `cheo` varchar(20) NOT NULL,
  `saa_kujifungua` time NOT NULL,
  `saa_kondokutoka` time NOT NULL,
  `lishe` varchar(10) NOT NULL,
  `vitamin_a` varchar(10) NOT NULL,
  `folic` varchar(10) NOT NULL,
  `furrous` varchar(10) NOT NULL,
  `ctx` varchar(10) NOT NULL,
  `pepopunda` varchar(10) NOT NULL,
  PRIMARY KEY (`visit_id`),
  KEY `idx_visit_after_delivery_p_id` (`p_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `visit_after_delivery`
--

INSERT INTO `visit_after_delivery` (`visit_id`, `visit_no`, `p_id`, `no_mimba_kusajiliwa`, `visit_date`, `joto_mwili`, `blood_preassure`, `hb`, `mtoto_ananyonya`, `maziwa_yanatoka`, `mtoto_kunyonya_ndani_saa1`, `chuchu_vidonda`, `matiti_yamejaa`, `matiti_majipu`, `tumbo_uzazi_linanyea`, `tumbo_maumivu_makali`, `msamba_kuchanika`, `msamba_alichanika`, `aliongezewa_njia`, `kidonda_kimepona`, `kidonda_kinausaa`, `kidonda_kimeachia`, `lokia_inanuka`, `lokia`, `lokia_rangi_ngapi`, `hali_ya_akili`, `ushauri_uzazi_wampango`, `tiba_nyingine`, `return_date`, `officer_name`, `cheo`, `saa_kujifungua`, `saa_kondokutoka`, `lishe`, `vitamin_a`, `folic`, `furrous`, `ctx`, `pepopunda`) VALUES
(48, 1, 34, 1, '2018-10-16', '23', '43', '8', 'ndio', 'ndio', 'ndio', 'hapana', 'hapana', 'hapana', 'hapana', 'hapana', 'hapana', 'ndio', 'ndio', 'hapana', 'hapana', 'ndio', 'hapana', 'wastani', '2', 'mgonjwa', 'ndio', 'hakuna', '2018-11-12', 'rehema', 'nurse', '00:00:00', '00:00:00', 'EBF', 'amepata', 'amepata', 'amepata', 'amepata', 'amepata');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `health_officer`
--
ALTER TABLE `health_officer`
  ADD CONSTRAINT `username` FOREIGN KEY (`username`) REFERENCES `user` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `maelezo_uzazi`
--
ALTER TABLE `maelezo_uzazi`
  ADD CONSTRAINT `fk_maelezo_uzazi` FOREIGN KEY (`p_id`) REFERENCES `pregnant_woman` (`p_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `muendelezo_uchungu`
--
ALTER TABLE `muendelezo_uchungu`
  ADD CONSTRAINT `uchungu` FOREIGN KEY (`p_id`) REFERENCES `pregnant_woman` (`p_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `other_inf`
--
ALTER TABLE `other_inf`
  ADD CONSTRAINT `fk_previous_inf_pregnant_woman` FOREIGN KEY (`p_id`) REFERENCES `pregnant_woman` (`p_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `partner`
--
ALTER TABLE `partner`
  ADD CONSTRAINT `fk_partner_pregnant_woman` FOREIGN KEY (`p_id`) REFERENCES `pregnant_woman` (`p_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pregnant_woman`
--
ALTER TABLE `pregnant_woman`
  ADD CONSTRAINT `fk_pregnant_woman_user` FOREIGN KEY (`username`) REFERENCES `user` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `record_uchungu`
--
ALTER TABLE `record_uchungu`
  ADD CONSTRAINT `fk_record_uchungu` FOREIGN KEY (`p_id`) REFERENCES `pregnant_woman` (`p_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ushauri`
--
ALTER TABLE `ushauri`
  ADD CONSTRAINT `fk_ushauri_pregnant_woman` FOREIGN KEY (`p_id`) REFERENCES `pregnant_woman` (`p_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `visity_before_delivery`
--
ALTER TABLE `visity_before_delivery`
  ADD CONSTRAINT `fk_visity_before_delivery` FOREIGN KEY (`p_id`) REFERENCES `pregnant_woman` (`p_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `visit_after_delivery`
--
ALTER TABLE `visit_after_delivery`
  ADD CONSTRAINT `fk_visit_after_delivery` FOREIGN KEY (`p_id`) REFERENCES `pregnant_woman` (`p_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
