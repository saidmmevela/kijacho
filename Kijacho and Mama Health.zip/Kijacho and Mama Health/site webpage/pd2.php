
         <?php
		 
include('functions.php');	
$id=$_GET['id'];

	
    require('FPDF-master/fpdf.php');
    $fullname = "";
	$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);



$sqlquery="SELECT* FROM pregnant_woman WHERE p_id=$id";
$reslt=mysql_query($sqlquery);
$_REQUEST=@mysql_fetch_assoc($reslt);

$sqlquery5="SELECT* FROM other_inf WHERE p_id=$id";
$reslt5=mysql_query($sqlquery5);
$_REQUEST5=@mysql_fetch_assoc($reslt5);

	$sqlquery1="SELECT * FROM record_uchungu WHERE p_id=$id ";
$reslt1=mysql_query($sqlquery1);
$_REQUEST1=@mysql_fetch_assoc($reslt1);










    $contractno = $_REQUEST['fname'];
   $sname = $_REQUEST['lname'];
  $fname = $_REQUEST['fname'];
   $age = $_REQUEST5['Age'];
  $dob = $_REQUEST['lname'];
    $cpprefix = $_REQUEST['lname'];
     $cpnum = $_REQUEST['lname'];
     $eadd = $_REQUEST['lname'];
    
    class PDF extends FPDF
    {
            function Header()
            {
//$this->Image('lifehead.jpg',25,10,155);
                $this->SetFont('Times','B',12);
                $this->Cell(80);
                $this->Ln(55);
            }
    }
    $pdf=new PDF();
    $pdf->AliasNbPages();
    $pdf->AddPage();
    $pdf->SetFont('Times','B','12');  
    //for($i=1;$i<=55;$i++)
    //(x,y)
	$pdf->SetXY(70,10);
    $pdf->Cell(10,30,'Record ya Uchungu ya Mama Mjamzito');
	$pdf->SetFont('Times','','12');  
    $pdf->SetXY(80,10);
    $pdf->Cell(10,55,'Jina la Mama :'. '  ' . $fname. '  '.$sname);
    //$pdf->SetXY(69,10);
    //$pdf->Cell(10,73);
    $pdf->SetXY(90,10); //TO INDENT
    $pdf->Cell(10,80,'Umri :'.'  '  .$age);
    //$pdf->SetXY(136,10);
    //$pdf->Cell(10,73,                                            'Contract Date');
   
$pdf->SetXY(55,53);
$width_cell=array(70,40);
$pdf->SetFillColor(193,229,252); // Background color of header 
// Header starts /// 
$pdf->Cell($width_cell[0],7,'KUHUSU',1,0,'C',true); // First header column 
$pdf->Cell($width_cell[1],7,'MAJIBU',1,1,'C',true); // Second header column

$pdf->SetXY(55,60);
// First row of data 
$pdf->Cell($width_cell[0],7,'jina la kituo',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['jina_kituo'],1,1,'C',false); // Second column of row 1 


 $pdf->SetXY(55,67);
// First row of data 
$pdf->Cell($width_cell[0],7,'Tarehe ya kulazwa',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kulazwa_date'],1,1,'C',false); // Second column of row 1 

$pdf->SetXY(55,74);
// First row of data 
$pdf->Cell($width_cell[0],7,'saa ya kulazwa',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['saa_kulazwa'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,81);
// First row of data 
$pdf->Cell($width_cell[0],7,'Tarehe uchungu umeanza',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['uchungu_umeanza_date'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,88);
// First row of data 
$pdf->Cell($width_cell[0],7,'saa uchungu umeanza',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['saa_uchungu'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,95);
// First row of data 
$pdf->Cell($width_cell[0],7,'chupa imepasuka',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['chupa_imepasuka'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,102);
// First row of data 
$pdf->Cell($width_cell[0],7,'Tarehe chupakupasuka',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['date_chupakupasuka'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,109);
// First row of data 
$pdf->Cell($width_cell[0],7,'umri wa mimba',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['umri_mimba'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,116);
// First row of data 
$pdf->Cell($width_cell[0],7,'kimo cha mimba',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kimo_mimba'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,123);
// First row of data 
$pdf->Cell($width_cell[0],7,'mlalo wa mtoto',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['mlalo_mtoto'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,130);
// First row of data 
$pdf->Cell($width_cell[0],7,'kitangulizi',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kitangulizi'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,137);
// First row of data 
$pdf->Cell($width_cell[0],7,'sacral promontary imefikiwa',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['sacral_promontary'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,144);
// First row of data 
$pdf->Cell($width_cell[0],7,'ischial spines imefikiwa',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['ischial_spines'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,151);
// First row of data 
$pdf->Cell($width_cell[0],7,'outlet finyu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['outlet_finyu'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,158);
// First row of data 
$pdf->Cell($width_cell[0],7,'nyonga kubwa yakutosha',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['nyonga_kubwa_yakutosha'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,165);
// First row of data 
$pdf->Cell($width_cell[0],7,'maoni',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['maoni'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,172);
// First row of data 
$pdf->Cell($width_cell[0],7,'chupa imepasuka bila uchungu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['chupa_imepasuka_bila_uchungu'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,179);
// First row of data 
$pdf->Cell($width_cell[0],7,'uchungu kabla',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['uchungu_kabla'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,186);
// First row of data 
$pdf->Cell($width_cell[0],7,'saa1 toka uchungu uanze',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['saa_toka_uchungu_uanze'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,193);
// First row of data 
$pdf->Cell($width_cell[0],7,'tangulizi kibaya',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['tangulizi_kibaya'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,200);
// First row of data 
$pdf->Cell($width_cell[0],7,'kutoka damu ukeni',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['toka_damu_ukeni'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,207);
// First row of data 
$pdf->Cell($width_cell[0],7,'mapigo ya moyo ya mtoto kubadilika',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['mapigo_mtoto_kubadilika'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,214);
// First row of data 
$pdf->Cell($width_cell[0],7,'homa',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['homa'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,221);
// First row of data 
$pdf->Cell($width_cell[0],7,'kondo lanyuma',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kondo_lanyuma'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,228);
// First row of data 
$pdf->Cell($width_cell[0],7,'kifafa cha mimba',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kifafa'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,235);
// First row of data 
$pdf->Cell($width_cell[0],7,'upungufu wa damu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['upungufu_damu'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,242);
// First row of data 
$pdf->Cell($width_cell[0],7,'mtoto mkubwa',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['nyonga_mtoto_mkubwa'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,249);
// First row of data 
$pdf->Cell($width_cell[0],7,'meconium',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['meconium'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,256);
// First row of data 
$pdf->Cell($width_cell[0],7,'Jina la Muhudumu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['officer_name'],1,0,'C',false); // Second column of row 1 


$pdf->SetXY(55,263);
// First row of data 
$pdf->Cell($width_cell[0],7,'Cheo cha mhudumu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['cheo'],1,0,'C',false); // Second column of row 1 

    $pdf->Output();
    ?>