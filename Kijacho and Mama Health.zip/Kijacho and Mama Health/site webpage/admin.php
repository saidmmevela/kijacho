<?php
include('functions.php');

if (!isLoggedIn()) {
	$_SESSION['msg'] = "You must log in first";
	header('location: login.php');
}

if (isset($_GET['logout'])) {
	session_destroy();
	unset($_SESSION['user']);
	header("location: ../kijacho/login.php");
}

?>
<!DOCTYPE html>
<html>
<head>
<link Rel="stylesheet" Href="index.css" type="text/css">
<title>kijacho and mama health</title>
</head>
<body id="main">
<div id="admcontainer">
<h1 align="center" style="color:#3399CC">Kijacho and Mama Health</h1>
<div class="bar"><form method="post">
<ul class="ul">
<li class="aulli"><a href="admin.php">Home</a></li>
<li class="aulli"><a><input class="buttn" type="submit" value="Register" name="registere"></a></li>
<li class="aulli"><a><input class="buttn" type="submit" value="Registered" name="register"></a></li>
<li class="aulli"><a href="login.php?logout='1'">Log out</a></li>
</ul></form>
</div>
<div>
<form method="post">
<?php
if (isset($_POST['register'])) {
registered();
}
else if (isset($_POST['srch'])) {
registered();
}

else if(isset($_POST['registere'])){
tast();
}

else if (isset($_POST['correct'])){
correct();
}


else if (isset($_POST['password'])){
password();
}
else if(isset($_POST['submit'])){
password();
}
else if(isset($_POST['registero'])){
registero();
}
else if (isset($_GET['change'])){
changep();
}
else if (isset($_GET['id'])){
enable();
}
else if (isset($_GET['edit'])){
edit();
}
else if (isset($_GET['delete'])){
delete();
}

else{
ahome();
}
?>
</form>
</div>
<div class="buttom">
<div class="footer">
<form method="post"><ul class="ful">
<li class="full"><a href="admin.php" >Home</a></li>
<li class="full"><a><input class="buttn" type="submit" value="Change Password" name="password"></a></li>
<li class="full"><a  href="login.php?logout='1'">log out</a></li></ul>


</form></div><div class="footer">
said_mmevela copyright &copy; 2018</div>
</div>
</div>
</body>
</html>