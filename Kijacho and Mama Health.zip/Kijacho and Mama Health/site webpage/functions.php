<?php   
session_start();
function isLoggedIn()
{
	if (isset($_SESSION['user'])) {
		return true;
	}
}

if (isset($_GET['logout'])) {
	session_destroy();
	unset($_SESSION['user']);
	header("location: login.php");
}
global $idtest;
    $pw=$idtest;

// connect to database
$db = mysql_connect("localhost","root","");
mysql_select_db("kijacho",$db) or die("connection feild");

// variable declaration
$username = "";
$email    = "";
$errors   = array(); 

if (isset($_GET['logout'])) {
	session_destroy();
	unset($_SESSION['user']);
	header("location: login.php");
}

//function of form of the pregnant woman registration

function pwregistration(){


echo'<form name="register" method="post">';
echo'<h2 align="center">Usajili wa Mama Mjamzito</h2>';
echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;"><legend align="center"><h3>Maelezo Binafsi ya Mama Mjamzito</h3></legend>';
$date=date('Y-m-d');
echo'<table width="700px" height="200px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td >Clinic Name</td><td align="right" ><input type="text" name="clinic" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Namba ya hati punguzo ya chandarua</td><td align="right"><input type="number" name="no_chandarua" min="1" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >First Name</td><td align="right" ><input type="text" name="Fname" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Kazi</td><td align="right"><input type="text" name="job" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Last Name</td><td align="right"><input type="text" name="Lname" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Education level</td><td align="right"><select  name="Elevel" required>
<option  value="primary">primary</option>
<option  value="olevel_secondary">olevel_secondary</option>
<option value="highlevel_secondary">highlevel_secondary</option>
<option  value="certificate">certificate</option>
<option value="diploma">diploma</option>
<option  value="degree">degree</option>
<option  value="masters">masters</option>
<option  value="phd">phd</option></select></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Age</td><td align="right"><input type="number" name="age" min="10" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Kimo (cm)</td><td align="right"><input type="number" name="kimo" min="1" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Jina la Mume/Mwenzi</td><td align="right"><input type="text" name="Npartner" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Kazi ya Mume/Mwenzi</td><td align="right"><input type="text" name="Jpartner" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td>Umri wa Mume/Mwenzi</td><td align="right"><input type="number" name="Apartner" min="10" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Elimu ya Mume/Mwenzi </td><td align="right"><select  name="PElevel" required>
<option  value="primary">primary</option>
<option  value="olevel_secondary">olevel_secondary</option>
<option  value="highlevel_secondary">highlevel_secondary</option>
<option value="certificate">certificate</option>
<option value="diploma">diploma</option>
<option value="degree">degree</option>
<option  value="masters">masters</option>
<option  value="phd">phd</option></select></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Kata/wilaya</td><td align="right"><input type="text" name="wilaya" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Jina la mwenyekiti</td><td align="right"><input type="text" name="chair_man" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Kiji/Kitongoji/Mtaa</td><td align="right"><input type="text" name="mtaa" required></td></tr></table></fieldset></td></tr>';
echo'</table></fieldset>';


echo'<fieldset align="center" style=" border-radius:7px; border-color:#E4E4E4;"><legend align="center"><h3>Habari kuhusu Uzazi uliotangaulia </h3></legend>';
echo'<table width="700px" height="200px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td >Mimba ya ngapi</td><td align="right"><input type="number" name="Npregnancy" min="1" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Amezaa mara ngapi</td><td align="right"><input type="number" min="0" name="nokuzaa"></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Watoto walio Hai</td><td align="right"><input type="number" name="watoto_hai"  min="0"></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>mimba zilizo halibika</td><td align="right"><input type="number" name="mimba_kuhalibika" min="0"></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >umri wa mimba kipindi zinahalibika</td><td align="right"><input type="number" name="umri_kuhalibika"  min="1"></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>miaka mingapi imepita toka mimba ya mwisho kuhalibika</td><td align="right"><input type="number" name="mwaka_kuhalibika" min="0"></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >mimba ya mwisho ilikuwa mwaka gani</td><td align="right"><input type="text" name="mimba_ya_mwisho"></td></tr></table></fieldset></td><td></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Tarehe ya kwanza ya hedhi ya mara ya mwisho(LNMP)</td><td align="right"><input type="date" name="date_hedhi" ></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Tarehe anayotazamiwa kujifungua(EDD)</td><td align="right"><input type="date" name="date_kujifungua" min='.$date.'></td></tr></table></fieldset></td></tr>';
echo'</table></fieldset>';


echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;"><legend align="center"><h3>Dalili za hatari na mengine</h3></legend>';
echo'<table width="700px" height="200px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td >kijifungua kwa kupasuliwa au vacum</td><td align="right"><select name="njia_kujifungua">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>kuzaa mtoto mfu/kifo cha mtoto mchanga(wiki1)</td><td align="right"><select name="mtoto_mfu">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >ugonjwa wa moyo</td><td align="right"><select name="moyo">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>ugonjwa wa kisukari</td><td align="right"><select name="kisukari">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >ugonjwa wa kifua kikuu</td><td align="right"><select name"kifuakikuu">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>kilema cha nyonga</td><td align="right"><select name="kilema_nyonga">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >kimo chini ya cm 150</td><td align="right"><select name="kimo">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>kutoka damu nyingi baada ya kujifungua</td><td align="right"><select name="damu_nyingi">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >kondo la nyuma kukwama</td><td align="right"><select name="kondo_kukwama">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td >Damu Group</td><td align="right"><input type="text" name="blood_group" required>
</td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Vipimo vingine</td><td align="right"><input type="text" name="vipimo_vingine" required>
</td></tr></table></fieldset></td><td></td></tr>';
echo'</table></fieldset>';
echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<table width="700px" height="20px" border="0" align="center"  >';

echo'<tr><td colspan="2" align="right"><input type="submit" name="pregister" value="Register" ></td><td colspan="2"><input type="reset" name="reset" value="cancel"></td></tr>';

echo'</table></fieldset>';
echo'</form>';
}




//fuction for sending form of pregnant woman registration to the database
function pregister(){
global $db;
$fname=$_POST['Fname'];
$lname=$_POST['Lname'];
$age=$_POST['age'];
$job=$_POST['job'];
$level=$_POST['Elevel'];
$pno=$_POST['Npregnancy'];
$mimbakualibika=$_POST['mimba_kuhalibika'];
$umrimimbakualibika=$_POST['umri_kuhalibika'];
$mwakamimbakualibika=$_POST['mwaka_kuhalibika'];
$mimbamwisho=$_POST['mimba_ya_mwisho'];
$npartner=$_POST['Npartner'];
$pepartner=$_POST['PElevel'];
$Jpartner=$_POST['Jpartner'];
$street=$_POST['mtaa'];
$kata=$_POST['wilaya'];
$Apartner=$_POST['Apartner'];
$username=$_POST['Fname'].substr($_POST['Lname'],0,2);
$password1=$_POST['Lname'].substr($_POST['Fname'],0,2);
$password=sha1($password1);
$status="active";
$role="p_woman";
$kujifungua=$_POST['njia_kujifungua'];
$mtoto_mfu=$_POST['mtoto_mfu'];
$moyo=$_POST['moyo'];
$kisukari=$_POST['kisukari'];
$kifua_kikuu=$_POST['kilema_nyonga'];
$kilema_nyonga=$_POST['kilema_nyonga'];
$kimo=$_POST['kimo'];
$kondo_kukwama=$_POST['kondo_kukwama'];
$damu_nyingi=$_POST['damu_nyingi'];
$wilaya=$_POST['wilaya'];
$mtaa=$_POST['mtaa'];
$chair_man=$_POST['chair_man'];
$clinic=$_POST['clinic'];
$pfname=$_POST['clinic'];
$date_hedhi=$_POST['date_hedhi'];
$date_kujifungua=$_POST['date_kujifungua'];
$nokuzaa=$_POST['nokuzaa'];
$watoto_hai=$_POST['watoto_hai'];
$vipimo_vingine=$_POST['vipimo_vingine'];
$blood_group=$_POST['blood_group'];
$no_chandarua=$_POST['no_chandarua'];
$no_mimba_kusajiliwa=1;

$sql="INSERT INTO user (username,password,role,status)
VALUES  ('$username','$password','$role','$status')";
if (!mysql_query($sql,$db))

  {

  die('Error: ' . mysql_error());

  }


$sqll="INSERT INTO pregnant_woman (username,fname,lname)

VALUES

('$username','$fname','$lname')";

if (!mysql_query($sqll))
  {

  die('Error: ' . mysql_error());
  }
  $sqlquery="SELECT* FROM pregnant_woman WHERE username='$username'";
  $sqlResult=mysql_query($sqlquery);
  if($sqlResult){
@$sqlRow=mysql_fetch_array($sqlResult,MYSQL_ASSOC);
$id=$sqlRow['p_id'];

 $sqlll="INSERT INTO partner (p_id,no_mimba_kusajiliwa,name,age,job,e_level)
VALUES  ('$id','$no_mimba_kusajiliwa','$npartner','$Apartner','$Jpartner','$pepartner')";
if (!mysql_query($sqlll,$db))

  {

  die('Error: ' . mysql_error());

  }
  
  $sqllll="INSERT INTO other_inf (no_chandarua,blood_group,vipimo_vingine,p_id,no_mimba_kusajiliwa,no_mimba_zilizohalibika,umri_mimba_zilipoalibika,mwaka_mimba_ilipohalibika,miaka_mimba_mwisho,njia_yakujifungua,mtoto_mfu,moyo,kisukari,kifua_kikuu,kilema_nyonga,kimo,kondo_kukwama,damu_nyingi,date_hedhi,date_kujifungua,nokuzaa,watoto_hai,Age, kazi,E_level, mimba_no,clinic_name,wilaya,mtaa,jina_mwenyekiti)
VALUES  ('$no_chandarua','$blood_group','$vipimo_vingine','$id','$no_mimba_kusajiliwa','$mimbakualibika','$umrimimbakualibika','$mwakamimbakualibika','$mimbamwisho','$kujifungua','$mtoto_mfu','$moyo','$kisukari','$kifua_kikuu','$kilema_nyonga','$kimo','$kondo_kukwama','$damu_nyingi','$date_hedhi','$date_kujifungua','$nokuzaa','$watoto_hai','$age','$job','$level','$pno','$clinic','$wilaya','$mtaa','$chair_man')";
if (!mysql_query($sqllll,$db))

  {

  die('Error: ' . mysql_error());

  } 
  else{
echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you have successfully registered pregnant wowan</p></td></tr>";
  }}
  
 else{ die('Error: ' . mysql_error());

  }
 

 
 


}

//mimba nyingine
function nyingine(){

$date=date('Y-m-d');
echo'<form name="register" method="post">';
echo'<h2 align="center">Usajili wa Mama Mjamzito</h2>';echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;"><legend align="center"><h3>Maelezo Binafsi ya Mama Mjamzito</h3></legend>';

echo'<table width="700px" height="200px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td >Clinic Name</td><td align="right" ><input type="text" name="clinic" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Namba ya hati punguzo ya chandarua</td><td align="right"><input type="number" name="no_chandarua" min="1" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td>Kazi</td><td align="right"><input type="text" name="job" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td>Education level</td><td align="right"><select  name="Elevel" required>
<option  value="primary">primary</option>
<option  value="olevel_secondary">olevel_secondary</option>
<option value="highlevel_secondary">highlevel_secondary</option>
<option  value="certificate">certificate</option>
<option value="diploma">diploma</option>
<option  value="degree">degree</option>
<option  value="masters">masters</option>
<option  value="phd">phd</option></select></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Umri</td><td align="right"><input type="number" name="age" min="10" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Kimo (cm)</td><td align="right"><input type="number" name="kimo" min="1" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Jina la Mume/Mwenzi</td><td align="right"><input type="text" name="Npartner" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Kazi ya Mume/Mwenzi</td><td align="right"><input type="text" name="Jpartner" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td>Umri wa Mume/Mwenzi</td><td align="right"><input type="number" name="Apartner" min="10" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Elimu ya Mume/Mwenzi </td><td align="right"><select  name="PElevel" required>
<option  value="primary">primary</option>
<option  value="olevel_secondary">olevel_secondary</option>
<option  value="highlevel_secondary">highlevel_secondary</option>
<option value="certificate">certificate</option>
<option value="diploma">diploma</option>
<option value="degree">degree</option>
<option  value="masters">masters</option>
<option  value="phd">phd</option></select></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Kata/wilaya</td><td align="right"><input type="text" name="wilaya" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Jina la mwenyekiti</td><td align="right"><input type="text" name="chair_man" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Kiji/Kitongoji/Mtaa</td><td align="right"><input type="text" name="mtaa" required></td></tr></table></fieldset></td></tr>';
echo'</table></fieldset>';


echo'<fieldset align="center" style=" border-radius:7px; border-color:#E4E4E4;"><legend align="center"><h3>Habari kuhusu uzazi uliotangulia</h3></legend>';
echo'<table width="700px" height="200px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td >Mimba ya ngapi</td><td align="right"><input type="number" name="Npregnancy" min="1" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Amezaa mara ngapi</td><td align="right"><input type="number" min="0" name="nokuzaa"></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Watoto walio Hai</td><td align="right"><input type="number" name="watoto_hai"  min="0"></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>mimba zilizo halibika</td><td align="right"><input type="number" name="mimba_kuhalibika" min="0"></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >umri wa mimba kipindi zinahalibika</td><td align="right"><input type="number" name="umri_kuhalibika"  min="1"></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>miaka mingapi imepita toka mimba ya mwisho kuhalibika</td><td align="right"><input type="number" name="mwaka_kuhalibika" min="0"></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >mimba ya mwisho ilikuwa mwaka gani</td><td align="right"><input type="text" name="mimba_ya_mwisho"></td></tr></table></fieldset></td><td></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Tarehe ya kwanza ya hedhi ya mara ya mwisho(LNMP)</td><td align="right"><input type="date" name="date_hedhi" ></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Tarehe anayotazamiwa kujifungua(EDD)</td><td align="right"><input type="date" name="date_kujifungua" min='.$date.'></td></tr></table></fieldset></td></tr>';
echo'</table></fieldset>';


echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;"><legend align="center"><h3>Dalili za hatari na mangineyo</h3></legend>';
echo'<table width="700px" height="200px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td >kijifungua kwa kupasuliwa au vacum</td><td align="right"><select name="njia_kujifungua">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>kuzaa mtoto mfu/kifo cha mtoto mchanga(wiki1)</td><td align="right"><select name="mtoto_mfu">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >ugonjwa wa moyo</td><td align="right"><select name="moyo">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>ugonjwa wa kisukari</td><td align="right"><select name="kisukari">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >ugonjwa wa kifua kikuu</td><td align="right"><select name"kifuakikuu">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>kilema cha nyonga</td><td align="right"><select name="kilema_nyonga">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >kimo chini ya cm 150</td><td align="right"><select name="kimo">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>kutoka damu nyingi baada ya kujifungua</td><td align="right"><select name="damu_nyingi">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >kondo la nyuma kukwama</td><td align="right"><select name="kondo_kukwama">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td >Damu Group</td><td align="right"><input type="text" name="blood_group" required>
</td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Vipimo vingine</td><td align="right"><input type="text" name="vipimo_vingine" required>
</td></tr></table></fieldset></td><td></td></tr>';
echo'</table></fieldset>';
echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<table width="700px" height="20px" border="0" align="center"  >';

echo'<tr><td colspan="2" align="right"><input type="submit" name="nyingine" value="Register" ></td><td colspan="2"><input type="reset" name="reset" value="cancel"></td></tr>';

echo'</table></fieldset>';
echo'</form>';
}

//form ya kusend mimba nyingine
function mimba(){

$id=$_GET['mimba'];






global $db;
$fname=$_POST['Fname'];
$lname=$_POST['Lname'];
$age=$_POST['age'];
$job=$_POST['job'];
$level=$_POST['Elevel'];
$pno=$_POST['Npregnancy'];
$mimbakualibika=$_POST['mimba_kuhalibika'];
$umrimimbakualibika=$_POST['umri_kuhalibika'];
$mwakamimbakualibika=$_POST['mwaka_kuhalibika'];
$mimbamwisho=$_POST['mimba_ya_mwisho'];
$npartner=$_POST['Npartner'];
$pepartner=$_POST['PElevel'];
$Jpartner=$_POST['Jpartner'];
$street=$_POST['mtaa'];
$kata=$_POST['wilaya'];
$Apartner=$_POST['Apartner'];
$username=$_POST['Fname'].substr($_POST['Lname'],0,2);
$password=$_POST['Lname'].substr($_POST['Fname'],0,2);
$status="active";
$role="p_woman";
$kujifungua=$_POST['njia_kujifungua'];
$mtoto_mfu=$_POST['mtoto_mfu'];
$moyo=$_POST['moyo'];
$kisukari=$_POST['kisukari'];
$kifua_kikuu=$_POST['kilema_nyonga'];
$kilema_nyonga=$_POST['kilema_nyonga'];
$kimo=$_POST['kimo'];
$kondo_kukwama=$_POST['kondo_kukwama'];
$damu_nyingi=$_POST['damu_nyingi'];
$wilaya=$_POST['wilaya'];
$mtaa=$_POST['mtaa'];
$chair_man=$_POST['chair_man'];
$clinic=$_POST['clinic'];
$pfname=$_POST['clinic'];
$date_hedhi=$_POST['date_hedhi'];
$date_kujifungua=$_POST['date_kujifungua'];
$nokuzaa=$_POST['nokuzaa'];
$watoto_hai=$_POST['watoto_hai'];
$blood_group=$_POST['blood_group'];
$vipimo_vingine=$_POST['vipimo_vingine'];
$no_chandarua=$_POST['no_chandarua'];
$no_mimba_kusajiliwa=$_POST['no_mimba_kusajiliwa'];


$sqlquery="SELECT* FROM pregnant_woman WHERE p_id=$id";

$sqlResult=mysql_query($sqlquery);

  if($sqlResult){
@$sqlRow=mysql_fetch_array($sqlResult,MYSQL_ASSOC);
$id=$sqlRow['p_id'];

 $sqlll="INSERT INTO partner (p_id,no_mimba_kusajiliwa,name,age,job,e_level)
VALUES  ('$id','$no_mimba_kusajiliwa','$npartner','$Apartner','$Jpartner','$pepartner')";
if (!mysql_query($sqlll,$db))

  {

  die('Error: ' . mysql_error());

  }
  
  $sqllll="INSERT INTO other_inf (vipimo_vingine,no_chandarua,blood_group,p_id,no_mimba_kusajiliwa,no_mimba_zilizohalibika,umri_mimba_zilipoalibika,mwaka_mimba_ilipohalibika,miaka_mimba_mwisho,njia_yakujifungua,mtoto_mfu,moyo,kisukari,kifua_kikuu,kilema_nyonga,kimo,kondo_kukwama,damu_nyingi,date_hedhi,date_kujifungua,nokuzaa,watoto_hai,Age, kazi,E_level, mimba_no,clinic_name,wilaya,mtaa,jina_mwenyekiti)
VALUES  ('$vipimo_vingine','$no_chandarua','$blood_group','$id','$no_mimba_kusajiliwa','$mimbakualibika','$umrimimbakualibika','$mwakamimbakualibika','$mimbamwisho','$kujifungua','$mtoto_mfu','$moyo','$kisukari','$kifua_kikuu','$kilema_nyonga','$kimo','$kondo_kukwama','$damu_nyingi','$date_hedhi','$date_kujifungua','$nokuzaa','$watoto_hai','$age','$job','$level','$pno','$clinic','$wilaya','$mtaa','$chair_man')";
if (!mysql_query($sqllll,$db))

  {

  die('Error: ' . mysql_error());

  } else{
echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you have successfully registered pregnant wowan</p></td></tr>";
  }}
  
  
}




//function for retrieve pregnant woman information
function preinfo(){

$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);

/*$sqlquery="SELECT* FROM user INNER JOIN health_officer ON user.username=health_officer.username";*/
echo'<input type="number" name="searchs" placeholder="enter registration no#" min="1"><input type="submit" name="srch" value="search"> ';
if(isset($_POST['srch'])){
$usern=$_POST['searchs'];
$sqlquery="SELECT * FROM pregnant_woman JOIN other_inf ON  pregnant_woman.p_id=other_inf.p_id JOIN user ON  pregnant_woman.username=user.username WHERE  pregnant_woman.p_id=$usern";
$sqlResult=mysql_query($sqlquery);
echo " <table border='0' class='report' align='center'><tr bgcolor='#CCCCCC'><th>p_id</th><th>first name</th><th>last name</th><th>age</th><th>job</th><th>pregnancy number</th><th> Report</th><th> status</th><th> enable/disable</th><th>Another pregnancy</th><th>Change password</th></tr>";
while(@$sqlRow=mysql_fetch_assoc($sqlResult))
{ 
echo "<tr>";
echo "<td>".$sqlRow['p_id']."</td>";
echo "<td>".$sqlRow['fname']."</td>";
echo "<td>".$sqlRow['lname']."</td>";
echo "<td>".$sqlRow['Age']."</td>";
echo "<td>".$sqlRow['kazi']."</td>";
echo "<td>".$sqlRow['mimba_no']."</td>";
echo "<td><a href='home.php?name=".$sqlRow['p_id']."'>Report</a></td>";
echo "<td>".$sqlRow['status']."</td>";
echo "<td><a href='home.php?id=".$sqlRow['p_id']."'>enable/disable</a></td>";
echo "<td><a href='home.php?mimba=".$sqlRow['p_id']."'>Another Pregnancy</a></td>";
echo "<td><a href='home.php?change=".$sqlRow['username']."'>change</a></td>";
echo"</tr>";

}}
else{

$sqlquery="SELECT * FROM pregnant_woman JOIN other_inf ON  pregnant_woman.p_id=other_inf.p_id JOIN user ON  pregnant_woman.username=user.username ";
$sqlResult=mysql_query($sqlquery);
echo " <table border='0' class='report' align='center'><tr bgcolor='#CCCCCC'><th>p_id</th><th>first name</th><th>last name</th><th>age</th><th>job</th><th>pregnancy number</th><th> Report</th><th> status</th><th> enable/disable</th><th>Another pregnancy</th><th>Change password</th></tr>";
while(@$sqlRow=mysql_fetch_assoc($sqlResult))
{ 
echo "<tr>";
echo "<td>".$sqlRow['p_id']."</td>";
echo "<td>".$sqlRow['fname']."</td>";
echo "<td>".$sqlRow['lname']."</td>";
echo "<td>".$sqlRow['Age']."</td>";
echo "<td>".$sqlRow['kazi']."</td>";
echo "<td>".$sqlRow['mimba_no']."</td>";
echo "<td><a href='home.php?name=".$sqlRow['p_id']."'>Report</a></td>";
echo "<td>".$sqlRow['status']."</td>";
echo "<td><a href='home.php?id=".$sqlRow['p_id']."'>enable/disable</a></td>";
echo "<td><a href='home.php?mimba=".$sqlRow['p_id']."'>Another Pregnancy</a></td>";
echo "<td><a href='home.php?change=".$sqlRow['username']."'>change</a></td>";
echo"</tr>";




}



}

}






//function for annual report
function anualreport(){

echo"<h2 align='center'>Selection for Time Range for HIV and Operation Derivery Statistic</h2>";

echo"<p  align='center' >    from: <input type='date' name='from'> to:  <input type='date' name='to'>  <input type='submit' name='generate' value='Generate'></p>";




if(isset($_POST['generate'])){
$from=$_POST['from'];
$to=$_POST['to'];

$sqllquery="SELECT DISTINCT  p_id FROM visity_before_delivery   WHERE visit_date>='$from' and visit_date<='$to' and hiv='negative' ";
$sqllResult=mysql_query($sqllquery);
$sqllquery1="SELECT DISTINCT  p_id FROM maelezo_uzazi   WHERE kujifungua_date>='$from' and kujifungua_date<='$to' and njia_yakujifungua='kupasuliwa' ";
$sqllResult2=mysql_query($sqllquery1);
$sqllquery3="SELECT DISTINCT  p_id FROM maelezo_uzazi   WHERE kujifungua_date>='$from' and kujifungua_date<='$to' ";
$sqllResult3=mysql_query($sqllquery3);



$sqllquer="SELECT DISTINCT  p_id FROM visity_before_delivery   WHERE visit_date>='$from' and visit_date<='$to' ";
$sqllResult1=mysql_query($sqllquer);

$td1='';$td3='';$td2='';$td4='';$td5='';$td6='';$td7='';$td8='';$td9='';

@$sqllRow1=mysql_num_rows($sqllResult1);
@$sqllRow=mysql_num_rows($sqllResult);
@$sqllRow2=mysql_num_rows($sqllResult2);
@$sqllRow3=mysql_num_rows($sqllResult3);
if($sqllRow1!=0){
if($sqllRow3!=0){
$res=$sqllRow/$sqllRow1*100;
$kuf=$sqllRow2/$sqllRow3*100;
//echo $sqllRow1;
//echo $sqllRow;
$td1.="<td bgcolor='#99CCFF'>".$sqllRow1."</td>";
$td2.="<td bgcolor='#99CCFF'>".$sqllRow."</td>";
$td3.="<td bgcolor='#99CCFF'>".$res."%</td>";
$td4.="<td bgcolor='#99CCFF'>".$sqllRow3."</td>";
$td5.="<td bgcolor='#99CCFF'>".$sqllRow2."</td>";
$td6.="<td bgcolor='#99CCFF'>".$kuf."%</td>";


echo " <table border='0' class='report' align='center'>

<br><tr ><th bgcolor='#CCCCCC'>Number of pregnant woman</th>";
echo $td1;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'>pregnant woman with HIV</th>";
echo $td2;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'>pregnant woman with HIV percent</th>";
echo $td3;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'>pregnant woman who deliver</th>";
echo $td4;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'>pregnant woman deliver with operation</th>";
echo $td5;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'>pregnant woman deliver with operation percent</th>";
echo $td6;
echo "</tr>";
}




else{
echo' <p align="center">there is no pregnant woman who deliver on that time</p>';
}
}
else{
echo' <p align="center">there is no pregnant woman on that time</p>';
}



}






}












//function for pregnant woman report
function report(){
$id=$_GET['name'];

$sqlquery="SELECT* FROM pregnant_woman WHERE p_id=$id";

$sqlResult=mysql_query($sqlquery);
@$sqlRow=mysql_fetch_array($sqlResult,MYSQL_ASSOC);
 $fname=$sqlRow['fname']; 
$lname=$sqlRow['lname']; 

echo"<h2 align='center'>Report of Pregnant Woman</h2>";
echo"<p align='center'>First name :".$fname."</p>";
echo"<p align='center'>Last name :".$lname."</p>";

echo"<p align='center'>Mimba ya ngapi kusajiliwa <input type='number' name='mimba_no' value='before delivery'><br>

 <table border='0' class='report' align='center'><tr bgcolor='#CCCCCC'><th><input type='submit' name='before' value='before delivery'></th><th><input type='submit' name='after' value='after delivery'></th><th><input type='submit' name='to' value='to delivery'></th><th><input type='submit' name='for' value='for delivery'></th><th><input type='submit' name='graph' value='progress labour pain'></th><th><input type='submit' name='inf' value='Other information'></th></tr></form></p>";


if(isset($_POST['before'])){
$mimba_no=$_POST['mimba_no'];
$sqllquery="SELECT* FROM visity_before_delivery   WHERE p_id=$id AND no_mimba_kusajiliwa=$mimba_no ";
$sqllResult=mysql_query($sqllquery);
$td1='';$td4='';$td5='';$td6='';$td7='';$td8='';$td9='';$td10='';$td11='';$td12='';$td13='';$td14='';$td15='';
$td2='';$td16='';$td17='';$td18='';$td19='';$td20='';$td21='';$td22='';$td23='';
$td3='';

$sqllR=@mysql_num_rows($sqllResult);
if($sqllR>=1){
echo"<p align='center'><a href='pd.php?id=".$id."' target='_blank'>Download file</a></p>";
}
while(@$sqllRow=mysql_fetch_assoc($sqllResult)){
$td1.="<td bgcolor='#99CCFF'>".$sqllRow['visiti_no']."</td>";
$td2.="<td bgcolor='#99CCFF'>".$sqllRow['visit_date']."</td>";
$td3.="<td bgcolor='#99CCFF'>".$sqllRow['weight']."</td>";
$td4.="<td bgcolor='#99CCFF'>".$sqllRow['blood_preassure']."</td>";
$td5.="<td bgcolor='#99CCFF'>".$sqllRow['albumin']."</td>";
$td6.="<td bgcolor='#99CCFF'>".$sqllRow['sukari_mkojo']."</td>";
$td7.="<td bgcolor='#99CCFF'>".$sqllRow['umri_mimba']."</td>";
$td8.="<td bgcolor='#99CCFF'>".$sqllRow['kimo_mimba']."</td>";
$td9.="<td bgcolor='#99CCFF'>".$sqllRow['mlalo_mtoto']."</td>";
$td10.="<td bgcolor='#99CCFF'>".$sqllRow['kitangulizi']."</td>";
$td11.="<td bgcolor='#99CCFF'>".$sqllRow['mtoto_kucheza']."</td>";
$td12.="<td bgcolor='#99CCFF'>".$sqllRow['mapigo_moyo_mtoto']."</td>";
$td13.="<td bgcolor='#99CCFF'>".$sqllRow['kuvimba_miguu']."</td>";
$td14.="<td bgcolor='#99CCFF'>".$sqllRow['pepopunda']."</td>";
$td15.="<td bgcolor='#99CCFF'>".$sqllRow['dalili_za_hatari']."</td>";
$td16.="<td bgcolor='#99CCFF'>".$sqllRow['uzazi_wa_mpango']."</td>";
$td17.="<td bgcolor='#99CCFF'>".$sqllRow['magonjwa_ya_kujamiiana']."</td>";
$td18.="<td bgcolor='#99CCFF'>".$sqllRow['return_date']."</td>";
$td19.="<td bgcolor='#99CCFF'>".$sqllRow['officer_name']."</td>";
$td20.="<td bgcolor='#99CCFF'>".$sqllRow['hiv']."</td>";
$td21.="<td bgcolor='#99CCFF'>".$sqllRow['adherence']."</td>";
$td22.="<td bgcolor='#99CCFF'>".$sqllRow['lishe_mtoto']."</td>";
$td23.="<td bgcolor='#99CCFF'>".$sqllRow['damu']."</td>";

}

echo " <table border='0' class='report' align='center'>

<br><tr ><th bgcolor='#CCCCCC'>visiti_no</th>";
echo $td1;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'>visit date</th>";
echo $td2;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'>weight</th>";
echo $td3;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'>blood preassure</th>";
echo $td4;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>albumin</th>";
echo $td5;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>sukari mkojo</th>";
echo $td6;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>umri wa mimba</th>";
echo $td7;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>kimo cha mimba</th>";
echo $td8;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>mlalo wa mtoto</th>";
echo $td9;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>kitangulizi</th>";
echo $td10;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>mtoto kucheza</th>";
echo $td11;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>mapigo ya moyo ya mtoto</th>";
echo $td12;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>kuvimba miguu</th>";
echo $td13;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>pepopunda</th>";
echo $td14;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>dalili za hatari</th>";
echo $td15;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>uzazi wa mpango</th>";
echo $td16;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>magonjwa ya kujamiiana</th>";
echo $td17;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>return_date</th>";
echo $td18;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>officer name</th>";
echo $td19;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>hiv</th>";
echo $td20;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>adherence</th>";
echo $td21;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>lishe_mtoto</th>";
echo $td22;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>dam</th>";
echo $td23;
echo "</tr>";




}


else if(isset($_POST['after'])){
$mimba_no=$_POST['mimba_no'];
$sqllquery="SELECT* FROM visit_after_delivery   WHERE p_id=$id AND no_mimba_kusajiliwa=$mimba_no";
$sqllResult=mysql_query($sqllquery);
$td1='';$td4='';$td5='';$td6='';$td7='';$td8='';$td9='';$td10='';$td11='';$td12='';$td13='';$td14='';$td15='';
$td2='';$td16='';$td17='';$td18='';$td19='';$td20='';$td21='';$td22='';$td23='';$td24='';$td25='';$td26='';$td27='';
$td3='';$td28='';$td29='';$td30='';$td31='';

$sqllR=@mysql_num_rows($sqllResult);
if($sqllR>=1){
echo"<p align='center'><a href='pd1.php?id=".$id."' target='_blank'>Download file</a></p>";
}


while(@$sqllRow=mysql_fetch_assoc($sqllResult)){
$td1.="<td bgcolor='#99CCFF'>".$sqllRow['visit_no']."</td>";
$td2.="<td bgcolor='#99CCFF'>".$sqllRow['visit_date']."</td>";
$td3.="<td bgcolor='#99CCFF'>".$sqllRow['joto_mwili']."</td>";
$td4.="<td bgcolor='#99CCFF'>".$sqllRow['blood_preassure']."</td>";
$td5.="<td bgcolor='#99CCFF'>".$sqllRow['hb']."</td>";
$td6.="<td bgcolor='#99CCFF'>".$sqllRow['lishe']."</td>";
$td7.="<td bgcolor='#99CCFF'>".$sqllRow['mtoto_ananyonya']."</td>";
$td8.="<td bgcolor='#99CCFF'>".$sqllRow['maziwa_yanatoka']."</td>";
$td9.="<td bgcolor='#99CCFF'>".$sqllRow['mtoto_kunyonya_ndani_saa1']."</td>";
$td10.="<td bgcolor='#99CCFF'>".$sqllRow['chuchu_vidonda']."</td>";
$td11.="<td bgcolor='#99CCFF'>".$sqllRow['matiti_yamejaa']."</td>";
$td12.="<td bgcolor='#99CCFF'>".$sqllRow['matiti_majipu']."</td>";
$td13.="<td bgcolor='#99CCFF'>".$sqllRow['tumbo_uzazi_linanyea']."</td>";
$td14.="<td bgcolor='#99CCFF'>".$sqllRow['tumbo_maumivu_makali']."</td>";
$td15.="<td bgcolor='#99CCFF'>".$sqllRow['msamba_kuchanika']."</td>";
$td16.="<td bgcolor='#99CCFF'>".$sqllRow['msamba_alichanika']."</td>";
$td17.="<td bgcolor='#99CCFF'>".$sqllRow['aliongezewa_njia']."</td>";
$td18.="<td bgcolor='#99CCFF'>".$sqllRow['kidonda_kimepona']."</td>";
$td19.="<td bgcolor='#99CCFF'>".$sqllRow['kidonda_kinausaa']."</td>";
$td20.="<td bgcolor='#99CCFF'>".$sqllRow['kidonda_kimeachia']."</td>";
$td21.="<td bgcolor='#99CCFF'>".$sqllRow['lokia_inanuka']."</td>";
$td22.="<td bgcolor='#99CCFF'>".$sqllRow['lokia']."</td>";
$td23.="<td bgcolor='#99CCFF'>".$sqllRow['lokia_rangi_ngapi']."</td>";
$td24.="<td bgcolor='#99CCFF'>".$sqllRow['hali_ya_akili']."</td>";
$td25.="<td bgcolor='#99CCFF'>".$sqllRow['ushauri_uzazi_wampango']."</td>";
$td26.="<td bgcolor='#99CCFF'>".$sqllRow['pepopunda']."</td>";
$td27.="<td bgcolor='#99CCFF'>".$sqllRow['ctx']."</td>";
$td28.="<td bgcolor='#99CCFF'>".$sqllRow['vitamin_a']."</td>";
$td29.="<td bgcolor='#99CCFF'>".$sqllRow['tiba_nyingine']."</td>";
$td30.="<td bgcolor='#99CCFF'>".$sqllRow['return_date']."</td>";
$td31.="<td bgcolor='#99CCFF'>".$sqllRow['officer_name']."</td>";



}

echo " <table border='0' class='report' align='center'>

<br><tr ><th bgcolor='#CCCCCC'>visiti_no</th>";
echo $td1;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'>visit date</th>";
echo $td2;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'>joto la mwili</th>";
echo $td3;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'>blood preassure</th>";
echo $td4;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>hb</th>";
echo $td5;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>PMTCT lishe ya mtoto</th>";
echo $td6;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>mtoto ananyonya?</th>";
echo $td7;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>maziwa yanatoka</th>";
echo $td8;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>mtoto ameanza kunyonya ndani ya saa 1</th>";
echo $td9;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>chuchu zina vidonda</th>";
echo $td10;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>matiti yamejaa sana</th>";
echo $td11;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>matiti yana majibu</th>";
echo $td12;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>tumbo la uzazi linanyea</th>";
echo $td13;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>tumbo la uzazi linamaumivu makali</th>";
echo $td14;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>msamba hakuchanika?</th>";
echo $td15;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>msamba alichanika</th>";
echo $td16;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>aliongezewa njia</th>";
echo $td17;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>kidonda kimepona</th>";
echo $td18;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>kidonda kinausaa</th>";
echo $td19;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>kidonda kimeachia</th>";
echo $td20;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>lokia inanuka?</th>";
echo $td21;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>lokia kiasi gani?</th>";
echo $td22;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>lokia rangi ngapi</th>";
echo $td23;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>hali ya akili</th>";
echo $td24;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>ushauri uzazi wa mpango</th>";
echo $td25;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>pepopunda</th>";
echo $td26;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>pmtct/ctx kama mama anaishi na VVU</th>";
echo $td27;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>vitamini A</th>";
echo $td28;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>tiba nyingine</th>";
echo $td29;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>tarehe ya kurudi</th>";
echo $td30;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>jina la mhudumu</th>";
echo $td31;
echo "</tr>";


}



else if(isset($_POST['to'])){
$mimba_no=$_POST['mimba_no'];
$sqllquery="SELECT* FROM record_uchungu WHERE p_id=$id AND no_mimba_kusajiliwa=$mimba_no ";
$sqllResult=mysql_query($sqllquery);
$td1='';$td4='';$td5='';$td6='';$td7='';$td8='';$td9='';$td10='';$td11='';$td12='';$td13='';$td14='';$td15='';
$td2='';$td16='';$td17='';$td18='';$td19='';$td20='';$td21='';$td22='';$td23='';$td24='';$td25='';$td26='';$td27='';
$td3='';$td28='';$td29='';$td30='';$td31='';

$sqllR=@mysql_num_rows($sqllResult);
if($sqllR>=1){
echo"<p align='center'><a href='pd2.php?id=".$id."' target='_blank'>Download file</a></p>";
}

while(@$sqllRow=mysql_fetch_assoc($sqllResult)){
$td1.="<td bgcolor='#99CCFF'>".$sqllRow['jina_kituo']."</td>";
$td2.="<td bgcolor='#99CCFF'>".$sqllRow['kulazwa_date']."  ".$sqllRow['saa_kulazwa']."</td>";
$td3.="<td bgcolor='#99CCFF'>".$sqllRow['uchungu_umeanza_date']."   ".$sqllRow['saa_uchungu']."</td>";
$td4.="<td bgcolor='#99CCFF'>".$sqllRow['chupa_imepasuka']."</td>";
$td5.="<td bgcolor='#99CCFF'>".$sqllRow['date_chupakupasuka']."</td>";
$td6.="<td bgcolor='#99CCFF'>".$sqllRow['umri_mimba']."</td>";
$td7.="<td bgcolor='#99CCFF'>".$sqllRow['kimo_mimba']."</td>";
$td8.="<td bgcolor='#99CCFF'>".$sqllRow['mlalo_mtoto']."</td>";
$td9.="<td bgcolor='#99CCFF'>".$sqllRow['kitangulizi']."</td>";
$td10.="<td bgcolor='#99CCFF'>".$sqllRow['sacral_promontary']."</td>";
$td11.="<td bgcolor='#99CCFF'>".$sqllRow['ischial_spines']."</td>";
$td12.="<td bgcolor='#99CCFF'>".$sqllRow['outlet_finyu']."</td>";
$td13.="<td bgcolor='#99CCFF'>".$sqllRow['nyonga_kubwa_yakutosha']."</td>";
$td14.="<td bgcolor='#99CCFF'>".$sqllRow['maoni']."</td>";
$td15.="<td bgcolor='#99CCFF'>".$sqllRow['chupa_imepasuka_bila_uchungu']."</td>";
$td16.="<td bgcolor='#99CCFF'>".$sqllRow['uchungu_kabla']."</td>";
$td17.="<td bgcolor='#99CCFF'>".$sqllRow['saa_toka_uchungu_uanze']."</td>";$td18.="<td bgcolor='#99CCFF'>".$sqllRow['tangulizi_kibaya']."</td>";
$td19.="<td bgcolor='#99CCFF'>".$sqllRow['toka_damu_ukeni']."</td>";
$td20.="<td bgcolor='#99CCFF'>".$sqllRow['mapigo_mtoto_kubadilika']."</td>";
$td21.="<td bgcolor='#99CCFF'>".$sqllRow['homa']."</td>";
$td22.="<td bgcolor='#99CCFF'>".$sqllRow['kondo_lanyuma']."</td>";
$td23.="<td bgcolor='#99CCFF'>".$sqllRow['kifafa']."</td>";
$td24.="<td bgcolor='#99CCFF'>".$sqllRow['upungufu_damu']."</td>";
$td25.="<td bgcolor='#99CCFF'>".$sqllRow['nyonga_mtoto_mkubwa']."</td>";
$td26.="<td bgcolor='#99CCFF'>".$sqllRow['meconium']."</td>";
$td27.="<td bgcolor='#99CCFF'>".$sqllRow['officer_name']."</td>";



}

echo " <table border='0' class='report' align='center'>

<br><tr ><th bgcolor='#CCCCCC'  align='left'>jina la kituo</th>";
echo $td1;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC' align='left'>Tarehe ya kulazwa na saa</th>";
echo $td2;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'  align='left'>uchungu umeanza tarehe na saa</th>";
echo $td3;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC' align='left'>chupa imepasuka?</th>";
echo $td4;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>tarehe chupa imepasuka</th>";
echo $td5;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>umri wa mimba (wiki)</th>";
echo $td6;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'  align='left'>kimo cha mimba</th>";
echo $td7;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>mlalo wa mtoto</th>";
echo $td8;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>kitangulizi</th>";
echo $td9;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>sacral promontory imefikiwa?</th>";
echo $td10;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>ischial spines imejitokeza</th>";
echo $td11;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>outlet finyu?</th>";
echo $td12;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>nyonga ni kubwa ya kutosha?</th>";
echo $td13;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>maoni</th>";
echo $td14;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>chupa imepasuka bila uchungu</th>";
echo $td15;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>uchungu kabla ya wiki 34</th>";
echo $td16;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>ni zaid ya saa 12 toka uchungu uanze</th>";
echo $td17;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>mlalo tangulizi kibaya cha mtoto</th>";
echo $td18;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>kutoka damu ukeni</th>";
echo $td19;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>mapigo ya moyo ya mtoto yanabadilika</th>";
echo $td20;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>homa zaidi ya 38 centigrade</th>";
echo $td21;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>kondo la nyuma kukwama</th>";
echo $td22;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>kifafa cha mimba au BP zaidi ya 140/90</th>";
echo $td23;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>upungufu wa damu chini ya(8.5gm/d)</th>";
echo $td24;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>nyonga nyembamba au mtoto mkubwa</th>";
echo $td25;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>meconium</th>";
echo $td26;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>jina la mhudumu</th>";
echo $td27;
echo "</tr>";


}


else if(isset($_POST['for'])){
$mimba_no=$_POST['mimba_no'];
$sqllquery="SELECT* FROM maelezo_uzazi WHERE p_id=$id AND no_mimba_kusajiliwa=$mimba_no ";
$sqllResult=mysql_query($sqllquery);
$td1='';$td4='';$td5='';$td6='';$td7='';$td8='';$td9='';$td10='';$td11='';$td12='';$td13='';$td14='';$td15='';
$td2='';$td16='';$td17='';$td18='';$td19='';$td20='';$td21='';$td22='';$td23='';$td24='';$td25='';$td26='';$td27='';
$td3='';$td28='';$td29='';$td30='';$td31='';

$sqllR=@mysql_num_rows($sqllResult);
if($sqllR==1){
echo"<p align='center'><a href='pd3.php?id=".$id."' target='_blank'>Download file</a></p>";
}


while(@$sqllRow=mysql_fetch_assoc($sqllResult)){
$td1.="<td bgcolor='#99CCFF'>".$sqllRow['kujifungua_date']."   ".$sqllRow['saa_kujifungua']."</td>";
$td2.="<td bgcolor='#99CCFF'>".$sqllRow['njia_yakujifungua']."</td>";
$td3.="<td bgcolor='#99CCFF'>".$sqllRow['sababu_kupasuliwa']."</td>";
$td4.="<td bgcolor='#99CCFF'>".$sqllRow['kondo_limetoka_date']."   ".$sqllRow['saa_kondokutoka']."</td>";
$td5.="<td bgcolor='#99CCFF'>".$sqllRow['kondo_na_membreni_kutoka']."</td>";
$td6.="<td bgcolor='#99CCFF'>".$sqllRow['kiasi_damu']."</td>";
$td7.="<td bgcolor='#99CCFF'>".$sqllRow['ergometrine']."</td>";
$td8.="<td bgcolor='#99CCFF'>".$sqllRow['msamba_kuchanika']."</td>";
$td9.="<td bgcolor='#99CCFF'>".$sqllRow['name_alieshona_msamba']."</td>";
$td10.="<td bgcolor='#99CCFF'>".$sqllRow['cheo']."</td>";
$td11.="<td bgcolor='#99CCFF'>".$sqllRow['BP']."</td>";
$td12.="<td bgcolor='#99CCFF'>".$sqllRow['hatua_ya_kwanza']."</td>";
$td13.="<td bgcolor='#99CCFF'>".$sqllRow['hatua_ya_pili']."</td>";
$td14.="<td bgcolor='#99CCFF'>".$sqllRow['hatua_ya_tatu']."</td>";
$td15.="<td bgcolor='#99CCFF'>".$sqllRow['name_mzalishaji']."</td>";
$td16.="<td bgcolor='#99CCFF'>".$sqllRow['mengineyo']."</td>";
$td17.="<td bgcolor='#99CCFF'>".$sqllRow['baada_ya_kujifungua_arv']."</td>";
$td18.="<td bgcolor='#99CCFF'>".$sqllRow['mtoto_jinsia']."</td>";
$td19.="<td bgcolor='#99CCFF'>".$sqllRow['uzito_mtoto']."</td>";
$td20.="<td bgcolor='#99CCFF'>".$sqllRow['mtoto_amepewa_arv']."</td>";
$td22.="<td bgcolor='#99CCFF'>".$sqllRow['lishe_ya_mtoto']."</td>";
$td23.="<td bgcolor='#99CCFF'>".$sqllRow['apgar1']."</td>";
$td24.="<td bgcolor='#99CCFF'>".$sqllRow['apgar5']."</td>";



}

echo " <table border='0' class='report' align='center'>

<br><tr ><th bgcolor='#CCCCCC'  align='left'>Kujifungua tarehe na saa</th>";
echo $td1;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC' align='left'>Njia ya kujifungua</th>";
echo $td2;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Kama mama amepasuliwa: Sababu za kupasuliwa</th>";
echo $td3;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC' align='left'>Kondo limetoka tarehe na saa</th>";
echo $td4;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Kondo na Membreni zimetoka kamili?</th>";
echo $td5;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Damu iliyotoka</th>";
echo $td6;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Ergometrine/oxtocin</th>";
echo $td7;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Msamba</th>";
echo $td8;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Jina la aliyeshona msamba</th>";
echo $td9;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>cheo</th>";
echo $td10;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>BP baada ya kujifungua</th>";
echo $td11;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Hatua ya 1 saa</th>";
echo $td12;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Hatua ya 2 saa</th>";
echo $td13;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Hatua ya 3 saa</th>";
echo $td14;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Jina la mzalishaji</th>";
echo $td15;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Mengineyo muhimu</th>";
echo $td16;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>ARV baada ya kujifungua</th>";
echo $td17;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Jinsia ya mtoto</th>";
echo $td18;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Uzito wa mtoto</th>";
echo $td19;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>APGAR score 1 dakika</th>";
echo $td23;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>APGAR score 5 dakika</th>";
echo $td24;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Kama mama ni PMTCT, je mtoto amepewa ARV </th>";
echo $td20;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Lishe ya mtoto</th>";
echo $td22;
echo "</tr>";



}



//graph
else if(isset($_POST['graph'])){

$mimba_no=$_POST['mimba_no'];
$sqllquery="SELECT* FROM muendelezo_uchungu WHERE p_id=$id AND no_mimba_kusajiliwa=$mimba_no ";
$sqllResult=mysql_query($sqllquery);
$td1='';$td4='';$td5='';$td6='';$td7='';$td8='';$td9='';$td10='';$td11='';$td12='';$td13='';$td14='';$td15='';
$td2='';$td16='';$td17='';$td18='';$td19='';$td20='';$td21='';$td22='';$td23='';$td24='';$td25='';$td26='';$td27='';
$td3='';$td28='';$td29='';$td30='';$td31='';


$sqllR=@mysql_num_rows($sqllResult);
if($sqllR>=1){
echo"<p align='center'><a href='pd4.php?id=".$id."' target='_blank'>Download file</a></p>";
}
while(@$sqllRow=mysql_fetch_assoc($sqllResult)){
$td1.="<td bgcolor='#99CCFF'>".$sqllRow['tarehe']."</td>";
$td2.="<td bgcolor='#99CCFF'>".$sqllRow['mapigo_moyo_mtoto']."</td>";
$td3.="<td bgcolor='#99CCFF'>".$sqllRow['maji_chupa']."</td>";
$td4.="<td bgcolor='#99CCFF'>".$sqllRow['kubonywa_kichwa']."</td>";
$td5.="<td bgcolor='#99CCFF'>".$sqllRow['cervix']."</td>";
$td6.="<td bgcolor='#99CCFF'>".$sqllRow['kichwa_kutelemka']."</td>";
$td7.="<td bgcolor='#99CCFF'>".$sqllRow['dawa']."</td>";
$td8.="<td bgcolor='#99CCFF'>".$sqllRow['mapigo_moyo_mama']."</td>";
$td9.="<td bgcolor='#99CCFF'>".$sqllRow['bLood_pressure']."</td>";
$td10.="<td bgcolor='#99CCFF'>".$sqllRow['albumin']."</td>";
$td11.="<td bgcolor='#99CCFF'>".$sqllRow['sukari']."</td>";
$td12.="<td bgcolor='#99CCFF'>".$sqllRow['acetone']."</td>";
$td13.="<td bgcolor='#99CCFF'>".$sqllRow['joto_mwili']."</td>";
$td14.="<td bgcolor='#99CCFF'>".$sqllRow['checkk']."</td>";
$td15.="<td bgcolor='#99CCFF'>".$sqllRow['time']."</td>";




}

echo " <table border='0' class='report' align='center'>

<br><tr ><th bgcolor='#CCCCCC'  align='left'>Tarehe</th>";
echo $td1;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC' align='left'>saa</th>";
echo $td15;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC' align='left'>kipimo cha</th>";
echo $td14;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC' align='left'>mapigo ya moyo ya mtoto</th>";
echo $td2;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'  align='left'>maji ya chupa</th>";
echo $td3;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC' align='left'>Kubonywa kichwa(moulding)</th>";
echo $td4;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Ukubwa wa njia</th>";
echo $td5;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>kichwa kutelemka</th>";
echo $td6;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'  align='left'>dawa zilizotolewa</th>";
echo $td7;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>mapigo moyo mama kwa dakika</th>";
echo $td8;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>shinikizo la damu</th>";
echo $td9;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>albumin</th>";
echo $td10;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>sukari</th>";
echo $td11;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>acetone</th>";
echo $td12;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>joto mwili</th>";
echo $td13;
echo "</tr>";

}











else if(isset($_POST['inf'])){
$mimba_no=$_POST['mimba_no'];
$sqllquery="SELECT* FROM other_inf WHERE p_id=$id AND no_mimba_kusajiliwa=$mimba_no";

$sqllquer="SELECT* FROM partner WHERE p_id=$id AND no_mimba_kusajiliwa=$mimba_no";
$sqllResult=mysql_query($sqllquery);
$sqllResul=mysql_query($sqllquer);
$td1='';$td4='';$td5='';$td6='';$td7='';$td8='';$td9='';$td10='';$td11='';$td12='';$td13='';$td14='';$td15='';
$td2='';$td16='';$td17='';$td18='';$td19='';$td20='';$td21='';$td22='';$td23='';$td24='';$td25='';$td26='';$td27='';
$td3='';$td28='';$td29='';$td30='';$td31='';

$sqllR=@mysql_num_rows($sqllResult);
$sqll=@mysql_num_rows($sqllResul);
if($sqllR>=1 && $sqll>=1){
echo"<p align='center'><a href='pd5.php?id=".$id."' target='_blank'>Download file</a></p>";
}

@$sqllRow=mysql_fetch_assoc($sqllResult);
@$sqllRo=mysql_fetch_assoc($sqllResul);
$td1.="<td bgcolor='#99CCFF'>".$sqllRow['Age']."</td>";
$td2.="<td bgcolor='#99CCFF'>".$sqllRow['E_level']."</td>";
$td3.="<td bgcolor='#99CCFF'>".$sqllRow['wilaya']."</td>";
$td4.="<td bgcolor='#99CCFF'>".$sqllRow['mtaa']."</td>";
$td5.="<td bgcolor='#99CCFF'>".$sqllRow['jina_mwenyekiti']."</td>";
$td6.="<td bgcolor='#99CCFF'>".$sqllRow['clinic_name']."</td>";
$td7.="<td bgcolor='#99CCFF'>".$sqllRow['kazi']."</td>";
$td8.="<td bgcolor='#99CCFF'>".$sqllRow['no_mimba_zilizohalibika']."</td>";
$td9.="<td bgcolor='#99CCFF'>".$sqllRow['umri_mimba_zilipoalibika']."</td>";
$td10.="<td bgcolor='#99CCFF'>".$sqllRow['mwaka_mimba_ilipohalibika']."</td>";
$td11.="<td bgcolor='#99CCFF'>".$sqllRow['miaka_mimba_mwisho']."</td>";
$td12.="<td bgcolor='#99CCFF'>".$sqllRow['njia_yakujifungua']."</td>";
$td13.="<td bgcolor='#99CCFF'>".$sqllRow['mtoto_mfu']."</td>";
$td14.="<td bgcolor='#99CCFF'>".$sqllRow['moyo']."</td>";
$td15.="<td bgcolor='#99CCFF'>".$sqllRow['kisukari']."</td>";
$td16.="<td bgcolor='#99CCFF'>".$sqllRow['kifua_kikuu']."</td>";
$td17.="<td bgcolor='#99CCFF'>".$sqllRow['kilema_nyonga']."</td>";
$td18.="<td bgcolor='#99CCFF'>".$sqllRow['kimo']."</td>";
$td19.="<td bgcolor='#99CCFF'>".$sqllRow['kondo_kukwama']."</td>";
$td20.="<td bgcolor='#99CCFF'>".$sqllRow['damu_nyingi']."</td>";
$td21.="<td bgcolor='#99CCFF'>".$sqllRow['date_hedhi']."</td>";
$td22.="<td bgcolor='#99CCFF'>".$sqllRow['date_kujifungua']."</td>";
$td23.="<td bgcolor='#99CCFF'>".$sqllRow['nokuzaa']."</td>";
$td24.="<td bgcolor='#99CCFF'>".$sqllRow['watoto_hai']."</td>";
$td25.="<td bgcolor='#99CCFF'>".$sqllRow['no_chandarua']."</td>";
$td26.="<td bgcolor='#99CCFF'>".$sqllRow['blood_group']."</td>";
$td27.="<td bgcolor='#99CCFF'>".$sqllRow['vipimo_vingine']."</td>";
$td28.="<td bgcolor='#99CCFF'>".$sqllRo['name']."</td>";
$td29.="<td bgcolor='#99CCFF'>".$sqllRo['age']."</td>";
$td30.="<td bgcolor='#99CCFF'>".$sqllRo['job']."</td>";
$td31.="<td bgcolor='#99CCFF'>".$sqllRo['e_level']."</td>";





echo " <table border='0' class='report' align='center'>

<br><tr ><th bgcolor='#CCCCCC'>Umri wa Mjamzito</th>";
echo $td1;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'>Kiwango cha elimu</th>";
echo $td2;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'>Wilaya</th>";
echo $td3;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'>mtaa</th>";
echo $td4;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>Jina la mwenyekiti</th>";
echo $td5;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>Kituo cha afya</th>";
echo $td6;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>Kazi ya mjamzito</th>";
echo $td7;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>Mimba zilizo halibika</th>";
echo $td8;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>Umri wa mimba kipindi zinahalibika</th>";
echo $td9;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>mwaka wa mwisho mimba iliyo halibika</th>";
echo $td10;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>mwaka wa mwisho mimba iliyo halibika</th>";
echo $td11;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>Njia ya kujifungua</th>";
echo $td12;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>kuzaa mtoto mfu au kufariki ndani ya wiki moja</th>";
echo $td13;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>Ugonjwa wa moyo</th>";
echo $td14;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>ugonjwa wa kisukari</th>";
echo $td15;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>Ugonjwa wa kifua kikuu</th>";
echo $td16;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>kilema cha nyonga</th>";
echo $td17;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>kimo</th>";
echo $td18;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>kondo kukwama</th>";
echo $td19;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>kutokwa damu nyingi</th>";
echo $td20;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>tarehe ya mwisho kupata hedhi</th>";
echo $td21;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>Tarehe inayotazamiwa kujifungua</th>";
echo $td22;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>kazaa mara ngapi</th>";
echo $td23;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>watoto walio hai</th>";
echo $td24;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>namba ya chandarua</th>";
echo $td25;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>Group la damu</th>";
echo $td26;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>vipimo vingine</th>";
echo $td27;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>Jina la mwenzi</th>";
echo $td28;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>umri wa mwenzi</th>";
echo $td29;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>kazi ya mwenzi</th>";
echo $td30;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>kiwango cha elimu cha mwenzi</th>";
echo $td31;
echo "</tr>";


}










}

//function for edit admin request
function edit(){
$id=$_GET['edit'];

$sqlquery="SELECT* FROM pregnant_woman WHERE p_id=$id";

echo '<form  name="register" method="post">';
echo '<h2 align="center">Correction for Health Officer</h2>';
echo '<table width="420px" height="400px" border="0" align="center" style=" background-color:#99CCFF; border-radius:7px;" >';
echo '<tr><td align="center">phone number</td><td align="center"><input type="text"  pattern="[0-9]{12}" title="ten number eg. 255673730232" name="pnumber" required></td></tr>';
echo '<tr><td align="center">kituo cha kazi</td><td align="center"><input type="text" name="clinic" required></td></tr>';
echo '<tr><td align="center">Kata/ wilaya</td><td align="center"><input type="text" name="kata" required></td></tr>';
echo '<tr><td align="center">Street</td><td align="center"><input type="text" name="street" ></td></tr>';
echo '<tr><td align="center"><input type="submit" name="correct" value="Register" ></td><td align="center"><input type="reset" name="reset" value="cancel"></td></tr>';
echo '</table>';
echo '</form>';

}

//function to send form of coreection of health officer to the database
function correct(){
global $db;
$id=$_GET['edit'];

$pnumber=$_POST['pnumber'];
$clinic=$_POST['clinic'];
$wilaya=$_POST['kata'];
$street=$_POST['street'];
  
  
$sql="UPDATE health_officer SET Phone_no=$pnumber, health_center='$clinic', wilaya='$wilaya', mtaa='$street' WHERE username='$id'";

if (!mysql_query($sql,$db))

  {

  die('Error: ' . mysql_error());

  }
else{
echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you have successfully correct health officer information</p></td></tr>";

} 


}


//function to send form of delete health officer to the database
function delete(){
global $db;
$id=$_GET['delete'];
$sqlquery=mysql_query("SELECT* FROM user   WHERE username='$id'");
@$sqlRow=mysql_fetch_array($sqlquery);

$admin="admin";
if($sqlRow['role']!=$admin){  
  
$sql="DELETE FROM user WHERE username='$id'";

if (!mysql_query($sql))

  {

  die('Error: ' . mysql_error());

  }
else{
echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you have successfully delete health officer</p></td></tr>";
} 
}
 else{
echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you can not delete this user</p></td></tr>";
}
}




//function for enable/disable user
function enable(){
$id=$_GET['id'];
$sqlquery=mysql_query("SELECT* FROM user INNER JOIN health_officer ON user.username=health_officer.username  WHERE officer_id='$id'");
@$sqlRow=mysql_fetch_array($sqlquery,MYSQL_ASSOC);
$active="active";
$ntactivity="not active";
$admin="admin";
if($sqlRow['role']!=$admin){

if($sqlRow['status']==$ntactivity){

$s=mysql_query("UPDATE user INNER JOIN health_officer ON user.username=health_officer.username SET status='active' WHERE officer_id='$id'");
if($s){
echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you have success activate ".$sqlRow['fname']." ".$sqlRow['lname'].".</p></td></tr>";

}
}
else if($sqlRow['status']==$active){

$s=mysql_query("UPDATE user INNER JOIN health_officer ON user.username=health_officer.username SET status='not active' WHERE officer_id='$id'");
if($s){

echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you have success diactivate ".$sqlRow['fname']." ".$sqlRow['lname'].".</p></td></tr>";
}

}}

else{echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you can not disable this user</p></td></tr>";
}

}

//function for enable/disable user
function enablep(){
$id=$_GET['id'];
$sqlquery=mysql_query("SELECT* FROM user INNER JOIN pregnant_woman ON user.username=pregnant_woman.username  WHERE p_id='$id'");
@$sqlRow=mysql_fetch_array($sqlquery,MYSQL_ASSOC);
$active="active";
$ntactivity="not active";

if($sqlRow['status']==$ntactivity){

$s=mysql_query("UPDATE user INNER JOIN pregnant_woman ON user.username=pregnant_woman.username SET status='active' WHERE p_id='$id'");
if($s){
echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you have success activate ".$sqlRow['fname']." ".$sqlRow['lname'].".</p></td></tr>";

}
}
else if($sqlRow['status']==$active){

$s=mysql_query("UPDATE user INNER JOIN pregnant_woman ON user.username=pregnant_woman.username SET status='not active' WHERE p_id='$id'");
if($s){

echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you have success diactivate ".$sqlRow['fname']." ".$sqlRow['lname'].".</p></td></tr>";
}

}

else{echo"wrng";}

}






//function to view form for health officer registration
function tast(){


echo '<form  name="register" method="post">';
echo '<h2 align="center">Registration for Health Officer</h2>';
echo '<table width="420px" height="400px" border="0" align="center" style=" background-color:#99CCFF; border-radius:7px;" >';
echo '<tr><td align="center">First Name</td><td align="center"><input type="text" name="Fname" required></td></tr>';
echo '<tr><td align="center">Last Name</td><td align="center"><input type="text" name="Lname" required></td></tr>';
echo '<tr><td align="center">cheo</td><td align="center" ><select name="role" required>';
echo '<option value="nurse">nurse</option>';

echo '<option value="midwife">midwife</option>';
echo '</select></td></tr>';
echo '<tr><td align="center">phone number</td><td align="center"><input type="text" pattern="[0-9]{12}" placeholder="eg. 255673730232" title="twelve number  eg. 255673730232" name="pnumber" required></td></tr>';
echo '<tr><td align="center">kituo cha kazi</td><td align="center"><input type="text" name="clinic" required></td></tr>';
echo '<tr><td align="center">Kata/ wilaya</td><td align="center"><input type="text" name="kata" required></td></tr>';
echo '<tr><td align="center">Street</td><td align="center"><input type="text" name="street" required></td></tr>';
echo '<tr><td align="center"><input type="submit" name="registero" value="Register" ></td><td align="center"><input type="reset" name="reset" value="cancel"></td></tr>';
echo '</table>';
echo '</form>';

}



//function to send form of health officer to the database
function registero(){
global $db;
$fname=$_POST['Fname'];
$lname=$_POST['Lname'];
$role=$_POST['role'];
$pnumber=$_POST['pnumber'];
$clinic=$_POST['clinic'];
$wilaya=$_POST['kata'];
$street=$_POST['street'];
$username=$_POST['Fname'].substr($_POST['Lname'],0,2);
$password=$_POST['Lname'].substr($_POST['Fname'],0,2);
$passwrd=sha1($password);
$status="active";
  
mysql_select_db("kijacho", $db);

 $sqll="INSERT INTO user (username,password,role,status)
VALUES  ('$username','$passwrd','$role','$status')";
if (!mysql_query($sqll,$db))

  {

  die('Error: ' . mysql_error());

  }



$sql="INSERT INTO health_officer (username,fname,lname,Phone_no, health_center, wilaya, mtaa)

VALUES

('$username','$fname','$lname','$pnumber','$clinic','$wilaya','$street')";

if (!mysql_query($sql,$db))

  {

  die('Error: ' . mysql_error());

  }
else{
echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you have successfully registered health officer</p></td></tr>";

} 


}





// function to retrieve registered health officer
function registered(){

	global $db;
	
$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);

echo'<input type="text" name="searchs" placeholder="enter username " min="1"><input type="submit" name="srch" value="search"> ';
if(isset($_POST['srch'])){
$heathid=$_POST['searchs'];

$sqlquery="SELECT* FROM user INNER JOIN health_officer ON user.username=health_officer.username  WHERE health_officer.username='$heathid' ";

$sqlResult=mysql_query($sqlquery);

echo " <table border='0' class='report' align='center'><tr bgcolor='#CCCCCC'><th>First Name</th><th>Last Name</th><th> username</th>
<th>Health center</th><th>Phone number</th><th> Mtaa</th><th>Wilaya</th><th>Status</th><th>Edit</th><th>Delete User</th><th>Enable/Disable</th><th>Change officer Password</th>
</tr>";
while(@$sqlRow=mysql_fetch_assoc($sqlResult))
{ 
echo "<tr>";
echo "<td>".$sqlRow['fname']."</td>";
echo "<td>".$sqlRow['lname']."</td>";
echo "<td>".$sqlRow['username']."</td>";
echo "<td>".$sqlRow['health_center']."</td>";
echo "<td>".$sqlRow['phone_no']."</td>";
echo "<td>".$sqlRow['mtaa']."</td>";
echo "<td>".$sqlRow['wilaya']."</td>";
echo "<td>".$sqlRow['status']."</td>";
echo "<td><a href='admin.php?edit=".$sqlRow['username']."'>Edit</a></td>";
echo "<td><a href='admin.php?delete=".$sqlRow['username']."'>Delete</a></td>";
echo "<td><a href='admin.php?id=".$sqlRow['officer_id']."'>enable/disable</a></td>";
echo "<td><a href='admin.php?change=".$sqlRow['username']."'>change</a></td>";
echo"</tr>";
}}
else{
$sqlquery="SELECT* FROM user INNER JOIN health_officer ON user.username=health_officer.username";

$sqlResult=mysql_query($sqlquery);

echo " <table border='0' class='report' align='center'><tr bgcolor='#CCCCCC'><th>First Name</th><th>Last Name</th><th> username</th>
<th>Health center</th><th>Phone number</th><th> Mtaa</th><th>Wilaya</th><th>Status</th><th>Edit</th><th>Delete User</th><th>Enable/Disable</th><th>Change officer Password</th>
</tr>";
while(@$sqlRow=mysql_fetch_assoc($sqlResult))
{ 
echo "<tr>";
echo "<td>".$sqlRow['fname']."</td>";
echo "<td>".$sqlRow['lname']."</td>";
echo "<td>".$sqlRow['username']."</td>";
echo "<td>".$sqlRow['health_center']."</td>";
echo "<td>".$sqlRow['phone_no']."</td>";
echo "<td>".$sqlRow['mtaa']."</td>";
echo "<td>".$sqlRow['wilaya']."</td>";
echo "<td>".$sqlRow['status']."</td>";
echo "<td><a href='admin.php?edit=".$sqlRow['username']."'>Edit</a></td>";
echo "<td><a href='admin.php?delete=".$sqlRow['username']."'>Delete</a></td>";
echo "<td><a href='admin.php?id=".$sqlRow['officer_id']."'>enable/disable</a></td>";
echo "<td><a href='admin.php?change=".$sqlRow['username']."'>change</a></td>";
echo"</tr>";
}

}

}







// escape string
function e($val){
	global $db;
	return @mysqli_real_escape_string($db, trim($val));  
}

function display_error() {
	global $errors;

	if (count($errors) > 0){
		echo '<div class="error">';
			foreach ($errors as $error){
				echo $error .'<br>';
			}
		echo '</div>';
	}
}
	

if(isset($_POST['report'])){
view();
}


function view(){
	global $db;
	$qt="SELECT * FROM `pregnat_woman`";
   $result=mysql_query($qt);
   @$logged_in_usr = mysql_fetch_assoc($result);
   $_SESSION['pregnat_woman'] = $logged_in_usr;
	

}





//condition for log in
if (isset($_POST['login'])) {
	login();
}

// LOGIN USER function
function login(){
	global $db, $username, $errors;

	// grap form values
	$user = $_POST['username'];
	$passs = $_POST['password'];
	$pass=sha1($passs);
	

	
	// attempt login if no errors on form  
	
$q="SELECT* FROM user WHERE username='$user' and password='$pass'";		


$result=mysql_query($q);


/*if($logged_in_user['username']==$user &&$logged_in_user['password']==$pass){*/
@$count=mysql_num_rows($result);

if($count==1) 
	{
	@$logged_in_user = mysql_fetch_assoc($result);
	
	$qt="SELECT* FROM user INNER JOIN health_officer ON user.username=health_officer.username";
	$results=mysql_query($qt);
    @$logged_in_users = mysql_fetch_assoc($results);
	
	$qtr="SELECT* FROM user INNER JOIN pregnant_woman ON user.username=pregnant_woman.username";
	$resultst=mysql_query($qtr);
    @$logged_in_usr = mysql_fetch_assoc($resultst);
	
	if ($logged_in_user['role'] == 'admin') {
              	header('location: admin.php');
				$_SESSION['user'] = $logged_in_user;
				$_SESSION['success']  = "You are now logged in"; 
					  
			}
    else if ($logged_in_user['role'] == 'p_woman') {
              	if($logged_in_user['status'] == 'active'){
					
				$_SESSION['user'] = $logged_in_user;
				$_SESSION['success']  = "You are now logged in";
				header('location: pwoman.php');	 }
				else{array_push($errors, "yuor no longer valid to log in");}
				
			}
	else if($logged_in_user['role'] == 'nurse'||$logged_in_user['role'] == 'midwife'){
				  if($logged_in_user['status'] == 'active'){			
				$_SESSION['user'] = $logged_in_user;
				$_SESSION['success']  = "You are now logged in";
                header('location: home.php');}
				else{array_push($errors, "yuor no longer valid to log in");}
				
            }
			
	
	}
	else{array_push($errors, "Wrong username/password combination");	
		}
	
	}
	
	
	
	
	
	
	
	
	// return user array from their id
	function getUserById($id){
	global $db;
	$query = "SELECT * FROM user WHERE id=".$id;
	$result = mysqli_query($db, $query);

	$user = mysqli_fetch_assoc($result);
	return $user;
}
	
	
	
	
	
	
	
	function vist(){
	
	echo"<ul><li class='displi' ><a href='visitdlv.php'>visit after delivery</a></li>
<li class='displi'><a href='visit.php'>visit before delivery</a></li></ul>
</li>";
	
	}
	
	
	
	
 function isAdmin()
{
	if (isset($_SESSION['user']) && $_SESSION['user']['role'] == 'admin' ) {
		return true;
	}else{
		return false;
	}
}


//function for form of visit before deliver
function bfdelivery(){

echo'<form name="visit" method="post">
<h2 align="center">Record ya mahudhurio</h2>';
$date=date('Y-m-d');
echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;"><legend align="center"><h3>Vipimo vya mwili na dawa</h3></legend>';

echo'<table width="700px" height="200px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td >Hudhurio namba</td><td align="right" ><input type="number" name="Vnumber" min="1"required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Namba ya Mjamzito</td><td align="right"><input type="number" name="Pid" min="1" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Hii ni Mimba ya ngapi toka usajiliwe</td><td align="right" ><input type="number" name="no_mimba_kusajiliwa" min="1" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Tarehe ya Hudhurio</td><td align="right"><input type="date" name="date" min='.$date.' required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Uzito (kilo)</td><td align="right"><input type="number" name="uzito" min="1" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Blood preasure (140/90mmHg)</td><td align="right"><input type="number" name="preasure" min="1" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Albumin kwenye mkojo (+)</td><td align="right"><input type="text" name="albumin" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Damu/Hb (8.5gm/d)</td><td align="right"><input type="number" name="damu_hb" min="1" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Sukari Kwenye Mkojo</td><td align="right"><input type="text" name="mkojo_sukari" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Umri wa mimba kwa wiki</td><td align="right"><input type="number" name="umri_mimba" min="1" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td>Kimo cha Mimba kwa Wiki</td><td align="right"><input type="number" name="kimo_mimba" min="10" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Mlalo wa Mtoto</td><td align="right"><input type="text" name="mlalo_mtoto" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Kitangulizi</td><td align="right"><input type="text" name="kitangulizi" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Mtoto anacheza baada ya wiki 20</td><td align="right"><select  name="mtoto_kucheza" required><option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Mapigo ya moyo ya mtoto baada ya wiki 20</td><td align="right"><select  name="moyo_bt" required><option value="yapo">yapo</option>
<option value="hayapo">hayapo</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td >Kuvimba miguu (Oedema)(++)</td><td align="right"><input type="text" name="miguu"  required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Folic Acid</td><td align="right"><select name="folic" required>
<option value="amepata">amepata</option>
<option value="hajapata">hajapata</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Ferrous Sulphate</td><td align="right"><select  name="ferrous" required><option value="amepata">amepata</option><option value="hajapata">hajapata</option></td></tr></table></fieldset></td></tr>';



echo'</table></fieldset>';


echo'<fieldset align="center" style=" border-radius:7px; border-color:#E4E4E4;"><legend align="center"><h3>Malaria</h3></legend>';
echo'<table width="700px" height="100px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td >Sulphadoxine/Pyrimelhmine</td><td align="right"><select name="kufia_tumboni" required>
<option value="amepata">amepata</option>
<option value="hajapata">hajapata</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Pepopunda</td><td align="right"><select name="pepopunda" required>
<option value="amepata">amepata</option>
<option value="hajapata">hajapata</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Mebendazole(500gm start)</td><td align="right"><select name="mebendazole" required>
<option value="amepata">amepata</option>
<option value="hajapata">hajapata</option></select></td></tr></table></fieldset></td><td></td></tr>';
echo'</table></fieldset>';


echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;"><legend align="center"><h3>Ushauri</h3></legend>';
echo'<table width="700px" height="100px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td >Mama ameshauri kuhusu dalili za hatari</td><td align="right"><select name="dhatari">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Mama ameshauriwa kuhusu uzazi wa mpango</td><td align="right"><select name="mpango">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Ameshauriwa kuhusu maandalizi ya kujifungua</td><td align="right"><select name="maandalizi">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Magonjwa yatokanayo na kujamiiana na matumizi sahihi ya kondomu</td><td align="right"><select name="sti"><option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'</table></fieldset>';


echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;"><legend align="center"><h3>PMTCT</h3></legend>';
echo'<table width="700px" height="100px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td >HIV</td><td align="right"><select name="hiv">
<option value="positive">positive</option>
<option value="negative">negative</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>PMTCT/ART </td><td align="right"><input type"number" name="art" ></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Dawa (1N,1Z,1K)</td><td align="right"><select name="dawa">
<option value="amepata">amepata</option>
<option value="hajapata">hajapata</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>CTX</td><td align="right"><select name="ctx"><option value="amepata">amepata</option><option value="hajapata">hajapata</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Uhusiano na huduma ya  CTC</td><td align="right"><input type="text" name="pmtct_ctc">
</td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Ushauri juu ya lishe</td><td align="right"><select name="maziwa"><option value="EBF">maziwa ya mama pekee</option><option value="RF">Maziwa mbadala</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Ufuasi(Adherence)</td><td align="right"><select name="ufuasi"><option value="poor">poor</option>
<option value="good">good</option></select>
</td></tr></table></fieldset></td><td></td></tr>';
echo'</table></fieldset>';


echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;"><legend align="center"><h3>Dalali za hatari na Mengineyo</h3></legend>';
echo'<table width="700px" height="100px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td>Mtoto kufia tumboni</td><td align="right"><select name="kufia_tumbon">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Mtoto amelala vibaya baada ya wiki 36</td><td align="right"><select name="amelala_vibaya">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Mama anamapacha</td><td align="right"><select name="mapacha">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Anadalili za hatari</td><td align="right"><select name="dalili_hatari"><option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Jina la mhudumu</td><td align="right"><input type="text" name="name" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Tarehe ya kurudi</td><td align="right"><input type="date" name="r_date" min='.$date.' required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td>cheo cha mhudumu</td><td align="right"><input type="text" name="cheo" required>
</td></tr></table></fieldset></td><td></td</tr>';
echo'</table></fieldset>';



echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<table width="700px" height="20px" border="0" align="center"  >';

echo'<tr><td colspan="2" align="right"><input type="submit" name="bfregister" value="Register" ></td><td colspan="2"><input type="reset" name="reset" value="cancel"></td></tr>';

echo'</table></fieldset>';
echo'</form>';

}


//function form sending data of visit before delivery to the database



function bfregister(){
global $db;
$Vnumber=$_POST['Vnumber'];
$Pid=$_POST['Pid'];
$date=$_POST['date'];
$uzito=$_POST['uzito'];
$preasure=$_POST['preasure'];
$albumin=$_POST['albumin'];
$damu_hb=$_POST['damu_hb'];
$mkojo_sukari=$_POST['mkojo_sukari'];
$umri_mimba=$_POST['umri_mimba'];
$kimo=$_POST['kimo_mimba'];
$mlalo=$_POST['mlalo_mtoto'];
$kitangulizi=$_POST['kitangulizi'];
$cheza=$_POST['mtoto_kucheza'];
$moyobt=$_POST['moyo_bt'];
$miguu=$_POST['miguu'];
$ferrous=$_POST['ferrous'];
$folic=$_POST['folic'];
$mebendazole=$_POST['mebendazole'];
$pepopunda=$_POST['pepopunda'];
$dhatari=$_POST['dhatari'];
$mpango=$_POST['mpango'];
$maandalizi=$_POST['maandalizi'];
$sti=$_POST['sti'];
$maziwa=$_POST['maziwa'];
$ufuasi=$_POST['ufuasi'];
$Rdate=$_POST['r_date'];
$mhudumu=$_POST['name'];
$role=$_POST['cheo'];
$hiv=$_POST['hiv'];
$art=$_POST['art'];
$pmtct_dawa=$_POST['dawa'];
$ctx=$_POST['ctx'];
$sulphadoxine=$_POST['kufia_tumboni'];
$no_mimba_kusajiliwa=$_POST['no_mimba_kusajiliwa'];

$query="SELECT visiti_no,p_id,no_mimba_kusajiliwa FROM visity_before_delivery WHERE p_id=$Pid  ";
$reslt=mysql_query($query);
$check=mysql_fetch_assoc($reslt);

$quer="SELECT * FROM pregnant_woman WHERE p_id=$Pid";
$resl=mysql_query($quer);
$chec=mysql_num_rows($resl);
$vno=$check['visiti_no'];
$id=$check['p_id'];


$kusajili=$check['no_mimba_kusajiliwa'];
if($chec==1){
if(($vno!= $Vnumber && $kusajili==$no_mimba_kusajiliwa)||($vno== $Vnumber && $kusajili!=$no_mimba_kusajiliwa)||($vno!= $Vnumber && $kusajili!=$no_mimba_kusajiliwa))
{

$sql="INSERT INTO visity_before_delivery (pepopunda,mebendazole,ctx, pmtct_dawa,art,folic,sulphadoxine,visiti_no,no_mimba_kusajiliwa,p_id,visit_date,weight,blood_preassure, albumin, sukari_mkojo, umri_mimba, kimo_mimba, mlalo_mtoto, kitangulizi, mtoto_kucheza, mapigo_moyo_mtoto, kuvimba_miguu, dalili_za_hatari, uzazi_wa_mpango, magonjwa_ya_kujamiiana, return_date, officer_name, cheo_muhudumu, hiv, adherence, lishe_mtoto,damu)

VALUES

('$pepopunda','$mebendazole','$ctx','$pmtct_dawa','$art','$folic','$sulphadoxine','$Vnumber','$no_mimba_kusajiliwa','$Pid','$date','$uzito','$preasure','$albumin','$mkojo_sukari','$umri_mimba','$kimo','$mlalo','$kitangulizi','$cheza','$moyobt','$miguu','$dhatari','$mpango','$sti','$Rdate','$mhudumu','$role','$hiv','$ufuasi','$maziwa','$damu_hb')";

if (mysql_query($sql,$db))

  {
   echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you have successfully added record</p></td></tr>";

  

  }
  else{die('Error: ' . mysql_error());
  }}
  else{echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you have repeat to record this visit make sure you enter right visit number</p></td></tr>";
}}
else{echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>pregnant woman number you put is not registered</p></td></tr>";
}


}





//function for form of visit after delivery
function aftdelivery(){
 
echo'<form name="visit" method="post">
<h2 align="center">Record ya mahudhurio baada ya kujifungua</h2>';

echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;">';
$date=date('Y-m-d');
echo'<table width="700px" height="200px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset ><table width="350px"><tr><td >Hudhurio namba</td><td align="right" ><input type="number" name="Vnumber" min="1"required></td></tr></table></fieldset></td><td><fieldset ><table width="350px"><tr><td>Namba ya Mjamzito</td><td align="right"><input type="number" name="Pid" min="1" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset ><table width="350px"><tr><td >Hii ni Mimba ya ngapi toka usajiliwe</td><td align="right" ><input type="number" name="no_mimba_kusajiliwa" min="1" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Tarehe ya Hudhurio</td><td align="right"><input type="date" name="date" min='.$date.' required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset ><table width="350px"><tr><td >Joto la mwili</td><td align="right"><input type="number" name="joto_mwili" min="1" required></td></tr></table></fieldset></td><td><fieldset ><table width="350px"><tr><td>Blood preasure (140/100mmHg)</td><td align="right"><input type="number" name="preasure" min="1" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset ><table width="350px"><tr><td >Hb chini ya 60% (8.5Gram/dl)</td><td align="right"><input type="text" name="hb" required></td></tr></table></fieldset></td><td><fieldset ><table width="350px"><tr><td>Lishe ya mtoto</td><td align="right"><select  name="lishe"  required><option value="EBF" >maziwa ya mama pekee</option><option value="RF" >maziwa mbadala</option></select></td></tr></table></fieldset></td></tr>';

echo'</table></fieldset>';


echo'<fieldset align="center" style=" border-radius:7px; border-color:#E4E4E4;"><legend align="center"><h3>Matiti</h3></legend>';
echo'<table width="700px" height="100px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td >Mtoto ananyonya</td><td align="right"><select name="kunyonya" required>
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>maziwa yanatoka</td><td align="right"><select name="maziwa_yanatoka" required>
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Mtoto ameanza kunyonya ndani ya saa 1</td><td align="right"><select name="kuanza_kunyonya" required>
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td >Chuchu zina vidonda</td><td align="right"><select name="chuchu_vidonda" required>
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Yamejaa sana</td><td align="right"><select name="kujaa" required>
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td >Yana jipu</td><td align="right"><select name="majipu" required>
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Chunguza unyonyeshaji, toa ushauri</td><td align="right"><textarea name="unyonyeshaji" required></textarea>
</td></tr></table></fieldset></td></tr>';
echo'</table></fieldset>';


echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;"><legend align="center"><h3>Tumbo la uzazi</h3></legend>';
echo'<table width="700px" height="50px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td >Linanyea?</td><td align="right"><select name="linanyea">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>maumivu makali</td><td align="right"><select name="maumivu">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td></tr>';
echo'</table></fieldset>';


echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;"><legend align="center"><h3>Sehemu za uke</h3></legend>';
echo'<table width="700px" height="100px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td >Msamba hakuchanika</td><td align="right"><select name="kuchanika">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Msamba alichanika (tear) </td><td align="right"><select  name="alichanika" ><option value="ndio">ndio</option><option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Aliongezewa njia (Episiolomy)</td><td align="right"><select name="aliongezewa">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Kidonda kimepona</td><td align="right"><select name="kupona"><option value="ndio">ndio</option><option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Kidonda kina usaha</td><td align="right"><select name="usaha">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option>
</td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Kidonda kimeachia</td><td align="right"><select name="kuachia"><option value="ndio">ndio</option><option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Lokia inanuka</td><td align="right"><select name="kunuka"><option value="ndio">ndio</option>
<option value="hapana">hapana</option></select>
</td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td >Lokia</td><td align="right"><select name="kiasi"><option value="nyingi">nyingi</option>
<option value="wastani">wastani</option><option value="kidogo">kidogo</option></select>
</td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Lokia rangi ngapi</td><td align="right"><input type="number" min="1" name="rangi">
</td></tr></table></fieldset></td><td></td></tr>';
echo'</table></fieldset>';


echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;"><legend align="center"><h3>Hli ya akili na uzazi wa mpango</h3></legend>';
echo'<table width="700px" height="100px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td>Mgonjwa wa akili</td><td align="right"><select name="hali_ya_akili">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Matatizo mengineyo</td><td align="right"><input type="text" name="matatizo_mengine">
</td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Ushauri kuhusu uzazi wa mpango umetolewa</td><td align="right"><select name="ushauri_uzazi">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td><td></td></tr>';
echo'</table></fieldset>';



echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;"><legend align="center"><h3>Dawa za kinga na vinginevyo</h3></legend>';
echo'<table width="700px" height="100px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td >Ferrous sulphate</td><td align="right"><select name="ferrous">
<option value="amepata">amepata</option>
<option value="hajapata">hajapata</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Folicacid </td><td align="right"><select  name="folic" ><option value="amepata">amepata</option><option value="hajapata">hajapata</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Pepopunda</td><td align="right"><input type="text" name="pepopunda">
</td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>PMTCT/CTX</td><td align="right"><select name="pmtct_ctx"><option value="amepata">amepata</option><option value="hajapata">hajapata</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Dawa anazotumia baada ya kujifungua</td><td align="right"><input type="text" name="dawa_pm">
</td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Vitamin A</td><td align="right"><select name="vitamin_a"><option value="amepata">amepata</option><option value="hajapata">hajapata</option></td></tr></table></fieldset></td></tr>';

echo'<tr><td><fieldset><table width="350px"><tr><td >Tiba nyingine</td><td align="right"><input type="text" name="nyingine_tiba">
</td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td >Tarehe ya kurudi</td><td align="right"><input type="date" name="r_date" min='.$date.'>
</td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Jina la Mhudumu</td><td align="right"><input type="text"  name="name">
</td></tr></table></fieldset></td><td><fieldset><table width="350px">
<tr><td >cheo cha Mhudumu</td><td align="right"><input type="text" name="cheo">
</td></tr></table></fieldset></td></tr>';
echo'</table></fieldset>';




echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<table width="700px" height="20px" border="0" align="center"  >';

echo'<tr><td colspan="2" align="right"><input type="submit" name="aftregister" value="Register" ></td><td colspan="2"><input type="reset" name="reset" value="cancel"></td></tr>';

echo'</table></fieldset>';
echo'</form>';

}



//function to send data from after delivery form to the database


function aftregister(){
global $db;

$role="nurse";
$Vnumber=$_POST['Vnumber'];

$Pid=$_POST['Pid'];
$date=$_POST['date'];
$joto_mwili=$_POST['joto_mwili'];
$preasure=$_POST['preasure'];
$albumin=$_POST['hb'];
$ctx=$_POST['pmtct_ctx'];
$kunyonya=$_POST['kunyonya'];
$maziwa_kutoka=$_POST['maziwa_yanatoka'];
$start_kunyonya=$_POST['kuanza_kunyonya'];
$chuchu_vidonda=$_POST['chuchu_vidonda'];
$matiti_kujaa=$_POST['kujaa'];
$matiti_majipu=$_POST['majipu'];
$t_linanyea=$_POST['linanyea'];
$t_maumivu=$_POST['maumivu'];
$msamba_kuchanika=$_POST['kuchanika'];
$tear=$_POST['alichanika'];
$kuongezewa_njia=$_POST['aliongezewa'];
$kidonda_kupona=$_POST['kupona'];
$kidonda_usaa=$_POST['usaha'];
$kidonda_kuachia=$_POST['kuachia'];
$lokia_kunuka=$_POST['kunuka'];
$kiasi_lokia=$_POST['kiasi'];
$lokia_rangi=$_POST['rangi'];

$ushauli=$_POST['ushauri_uzazi'];
$ferrous=$_POST['ferrous'];
$folic=$_POST['folic'];
$pepopunda=$_POST['pepopunda'];
$vitamin_a=$_POST['vitamin_a'];
$other=$_POST['nyingine_tiba'];
$Rdate=$_POST['r_date'];
$Nmhudumu=$_POST['name'];
$lishe=$_POST['lishe'];



$no_mimba_kusajiliwa=$_POST['no_mimba_kusajiliwa'];


$query="SELECT visit_no,p_id,no_mimba_kusajiliwa FROM visit_after_delivery WHERE p_id=$Pid";
$reslt=mysql_query($query);
@$check=mysql_fetch_assoc($reslt);
$vno=$check['visit_no'];
$id=$check['p_id'];
$kusajili=$check['no_mimba_kusajiliwa'];

$quer="SELECT * FROM pregnant_woman WHERE p_id=$Pid";
$resl=mysql_query($quer);
$chec=mysql_num_rows($resl);



if($chec==1){

if(($vno!= $Vnumber && $kusajili==$no_mimba_kusajiliwa)||($vno== $Vnumber && $kusajili!=$no_mimba_kusajiliwa)||($vno!= $Vnumber && $kusajili!=$no_mimba_kusajiliwa))
{



$sql=mysql_query("INSERT INTO visit_after_delivery (cheo,lishe,furrous,folic,pepopunda,ctx, vitamin_a,visit_no,no_mimba_kusajiliwa,p_id,visit_date,joto_mwili,blood_preassure, hb, mtoto_ananyonya, maziwa_yanatoka, mtoto_kunyonya_ndani_saa1, chuchu_vidonda,
matiti_yamejaa, matiti_majipu, tumbo_uzazi_linanyea, tumbo_maumivu_makali, msamba_kuchanika, msamba_alichanika, aliongezewa_njia, kidonda_kimepona, kidonda_kinausaa, kidonda_kimeachia,
lokia_inanuka, lokia, lokia_rangi_ngapi,ushauri_uzazi_wampango,tiba_nyingine,return_date,officer_name)

VALUES

('$role','$lishe','$ferrous','$folic','$pepopunda','$ctx','$vitamin_a','$Vnumber','$no_mimba_kusajiliwa','$Pid','$date','$joto_mwili','$preasure','$albumin','$kunyonya','$maziwa_kutoka','$start_kunyonya','$chuchu_vidonda',
'$matiti_kujaa','$matiti_majipu','$t_linanyea','$t_maumivu','$msamba_kuchanika','$tear','$kuongezewa_njia','$kidonda_kupona','$kidonda_usaa','$kidonda_kuachia',
'$lokia_kunuka','$kiasi_lokia','$lokia_rangi','$ushauli','$other','$Rdate','$Nmhudumu')");

if ($sql)

  {
   echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you have successfully added record</p></td></tr>";

if($Vnumber==4) {
$sql=mysql_query("DELETE FROM ushauri WHERE p_id=$Pid");
} 

  }
  else{die('Error: ' . mysql_error());
  }}
  else{echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you have repeat to record this visit make sure you enter right visit number</p></td></tr>";
}
}
else{echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>pregnant woman number you put is not registered</p></td></tr>";
}


}






//fuction for the form of delivery information
function fordelivery(){
 
echo'<form name="visit" method="post">
<h2 align="center">Maelezo ya uzazi</h2>';




echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;">';

echo'<table width="700px" height="200px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td >Namba ya Mama</td><td align="right" ><input type="number" name="P_id" min="1"required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Hii ni mimba ya ngapi toka kusajiliwa</td><td align="right"><input type="number" name="mimba_no" min="1" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Jina la kituo cha afya</td><td align="right" ><input type="text" name="kituo" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Kujifungua Tarehe na saa</td><td align="right"><input type="date" name="kudate"  required><input type="time" name="kutime" ></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Njia ya kujifungua</td><td align="right"><input type="text" name="njia_kujifungua"  required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Kama amepasuliwa : sababu</td><td align="right"><input type="text" name="sababu" >
</td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Kondo limetoka tarehe tarehe na saa</td><td align="right"><input type="date" name="kodate" required><input type="time" name="kotime" ></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Kondo na membreni zimetoka kamili</td><td align="right"><select  name="Kondo_kutoka_kamili" required><option value="ndio">ndio</option><option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Damu iliyotoka (ml)</td><td align="right"><input type="number" name="damu_kiasi" min="1" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>ERGOMETRINE/OXTOCIN </td><td align="right"><input type="text" name="ergometrine"  required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td>Jina aliyeshona msamba</td><td align="right"><input type="text" name="jina_msamba"  required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Msamba</td><td align="right"><select  name="msamba" required><option value="haukuchanika">haukuchanika</option>
<option value="umechanika">umechanika</option><option value="ulichanywa">ulichanywa</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >cheo cha aliyeshona msamba</td><td align="right"><input type="text" name="cheo" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>BP baada ya kujifungua</td><td align="right"><input type="text" name="p_kujifungua" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Hatua ya kwanza saa na dakika</td><td align="right"><input type="time"  name="hatua1" ></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td >Hatua ya pili saa na dakika</td><td align="right"><input type="time"  name="hatua2"></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Hatua ya tatu saa na dakika</td><td align="right"><input type="time"  name="hatua3"></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Jina la mzalishaji</td><td align="right"><input type="text"  name="jina_mzalishaji" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Mengineyo muhimu</td><td align="right"><input type="text"  name="mengine_muhimu" ></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Baada ya kujifungua</td><td align="right"><select  name="baada_kujifungua" required><option value="1Z">1Z</option>
<option value="1A">1A</option><option value="hakunywa">hakunywa</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Mtoto jinsia</td><td align="right"><input type="text"  name="mtoto_jinsia_" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td >Mtoto uzito</td><td align="right"><input type="number"  name="mtoto_uzito" min="1" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >APGAR score 1 dakika</td><td align="right"><input type="number"  name="dakika1" min="1" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td >APGAR score 5 dakika</td><td align="right"><input type="number"  name="5dakika" min="1" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Kama mama ni pmtct, je mtoto amepewa ARVs </td><td align="right"><select name="arv">
<option value="N">N</option>
<option value="Z">Z</option><option value="hakunywa">hakunywa</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Lishe ya mtoto</td><td align="right"><select name="lishe">
<option value="EBF">Maziwa ya mama pekee</option>
<option value="RF">maziwa mbadala</option><option value="unasihi">unasihi</option></select></td></tr></table></fieldset></td></tr>';

echo'</table></fieldset>';

echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<table width="700px" height="20px" border="0" align="center"  >';

echo'<tr><td colspan="2" align="right"><input type="submit" name="forregister" value="Register" ></td><td colspan="2"><input type="reset" name="reset" value="cancel"></td></tr>';

echo'</table></fieldset>';
echo'</form>';

}
//function to send after delivery form to the database



function forregister(){
global $db;
$Pid=$_POST['P_id'];
$date=$_POST['kudate'];
$njia_yakujifungua=$_POST['njia_kujifungua'];
$sababu_kupasuliwa=$_POST['sababu'];
$kondo_limetoka_tarehe=$_POST['kodate'];
$kondo_na_membreni=$_POST['Kondo_kutoka_kamili'];
$damu_iliyitoka=$_POST['damu_kiasi'];
$ergometrine=$_POST['ergometrine'];
$msamba=$_POST['msamba'];
$jina_aliyemshona=$_POST['jina_msamba'];
$cheo=$_POST['cheo'];
$bp=$_POST['p_kujifungua'];
$hatua1=$_POST['hatua1'];
$hatua2=$_POST['hatua2'];
$hatua3=$_POST['hatua3'];
$jina_aliyemzalisha=$_POST['jina_mzalishaji'];
$arv_kujifungua=$_POST['baada_kujifungua'];
$jinsia=$_POST['mtoto_jinsia_'];
$uzito=$_POST['mtoto_uzito'];
$apgar5=$_POST['5dakika'];
$apgar1=$_POST['dakika1'];
$mama_pmtct=$_POST['arv'];

$lishe=$_POST['lishe'];
$ktime=$_POST['kutime'];
$kotime=$_POST['kotime'];
$kituo=$_POST['kituo'];
$no_mimba_kusajiliwa=$_POST['mimba_no'];




$query="SELECT * FROM maelezo_uzazi WHERE p_id=$Pid";
$reslt=mysql_query($query);
@$check=mysql_fetch_assoc($reslt);

$id=$check['p_id'];
$kusajili=$check['no_mimba_kusajiliwa'];

$quer="SELECT * FROM pregnant_woman WHERE p_id=$Pid";
$resl=mysql_query($quer);
$chec=mysql_num_rows($resl);

if($chec==1){

if($kusajili !=$no_mimba_kusajiliwa )
{


$sql="INSERT INTO maelezo_uzazi (kituo,p_id,no_mimba_kusajiliwa,kujifungua_date,njia_yakujifungua,sababu_kupasuliwa, kondo_limetoka_date, kondo_na_membreni_kutoka, kiasi_damu, ergometrine, msamba_kuchanika,
name_alieshona_msamba, cheo, hatua_ya_kwanza, hatua_ya_pili, hatua_ya_tatu, name_mzalishaji, baada_ya_kujifungua_arv, mtoto_jinsia, uzito_mtoto,apgar1,apgar5, mtoto_amepewa_arv,
lishe_ya_mtoto, saa_kujifungua,saa_kondokutoka )

VALUES

('$kituo','$Pid','$no_mimba_kusajiliwa','$date','$njia_yakujifungua','$sababu_kupasuliwa','$kondo_limetoka_tarehe','$kondo_na_membreni','$damu_iliyitoka','$ergometrine','$msamba','$jina_aliyemshona',
'$cheo','$hatua1','$hatua2','$hatua3','$jina_aliyemzalisha','$arv_kujifungua','$jinsia','$uzito','$apgar1','$apgar5','$mama_pmtct',
'$lishe','$ktime','$kotime')";

if (!mysql_query($sql,$db))

  {

  die('Error: ' . mysql_error());

  }


else{
   echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you have successfully added record</p></td></tr>";

}
}

  else{echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>this record for this pregnant woman have alread been recorded make sure you enter right pregnant woman number</p></td></tr>";
}
}
else{echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>pregnant woman number you put is not registered</p></td></tr>";
}


}








//function for todelivery form
function todelivery(){
$date=date("Y-m-d");
echo'<form name="visit" method="post">
<h2 align="center">Record ya Uchungu</h2>';




echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;">';

echo'<table width="700px" height="200px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td >Namba ya mjamzito</td><td align="right" ><input type="number" name="P_id" min="1"required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Hii ni mimba ya ngapi toka kusajiliwa</td><td align="right"><input type="number" name="mimba_no" min="1" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Jina la kituo cha afya</td><td align="right" ><input type="text" name="kituo" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Kulazwa Tarehe na saa</td><td align="right"><input type="date" name="ku_date"  required><input type="time" name="kutime"  required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >uchungu umeanza tarehe na saa</td><td align="right"><input type="date" name="uchungu_date"  required><input type="time" name="uchungu_time" required ></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Chupa imepasuka</td><td align="right"><select name="chupa_kupasuka" required>
<option value="ndio">Ndio</option>
<option value="hapana">Hapana</option></select></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >chupa imepasuka tarehe na saa</td><td align="right"><input type="date" name="chupa" required><input type="time" name="chupa_time" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Umri wa mimba (wiki)</td><td align="right"><input type="number" name="umri_mimba" min="1" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Kimo cha mimba (wiki)</td><td align="right"><input type="number" name="kimo_mimba" min="1" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Mlalo wa mtoto</td><td align="right"><input type="text" name="mlalo_mtoto"  required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td>Kitanglizi</td><td align="right"><input type="text" name="kitangulizi"  required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Sacral Promontory imefikiwa?</td><td align="right"><select  name="sacral" required><option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Ischial Spines zimejitokeza?</td><td align="right"><select  name="ischial" required><option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Ooutlet Finyu</td><td align="right"><select  name="outlet" required><option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Nyonga ni kubwa ya kutosha</td><td align="right"><select  name="nyonga" required><option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td >Maoni ya mpimaji</td><td align="right"><textarea type="text" name="maoni"  required></textarea></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Jina la mhudumu</td><td align="right"><input type="text" name="name" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Cheo cha mhudumu</td><td align="right"><input type="text"  name="cheo" required></td></tr></table></fieldset></td></tr>';



echo'</table></fieldset>';

echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;"><legend align="center"><h3>Dalili za hatari</h3></legend>';
echo'<table width="700px" height="100px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td >Dalili zozote za hatari</td><td align="right"><select name="dhatari">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Chupa imepasuka bila uchungu</td><td align="right"><select name="bila_uchungu">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></select></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Uchungu kabla ya wiki 34</td><td align="right"><select name="uchungu_kabla_34">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Nizaidi ya saa 12 tokea uchungu uipoanza</td><td align="right"><select name="saa_12_uchungu"><option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Mlalo kitangulizi kibaya cha mtoto</td><td align="right"><select name="kitangulizi_kibaya">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Kutoka damu ukeni</td><td align="right"><select name="damu_ukeni"><option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Mapigo ya moyo ya mtoto kubadilika badilika</td><td align="right"><select name="kubadilika">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Homa zaidi ya 38 centigrade</td><td align="right"><select name="homa"><option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Kondo la nyuma kukwama</td><td align="right"><select name="kondo_kukwama">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Kifafa cha mimba au BP zaidi ya 140/90</td><td align="right"><select name="kifafa"><option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Upungufu wa damu</td><td align="right"><select name="upungufu_damu">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Nyonga nyembamba au mtoto mkubwa</td><td align="right"><select name="nyonga_nyembamba"><option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Meconium</td><td align="right"><select name="meconium">
<option value="ndio">ndio</option>
<option value="hapana">hapana</option></td></tr></table></fieldset></td><td></td</tr>';

echo'</table></fieldset>';

echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<table width="700px" height="20px" border="0" align="center"  >';

echo'<tr><td colspan="2" align="right"><input type="submit" name="toregister" value="Register" ></td><td colspan="2"><input type="reset" name="reset" value="cancel"></td></tr>';

echo'</table></fieldset>';
echo'</form>';


}

//function to send data from to delivery to the database


function toregister(){
global $db;

$Pid=$_POST['P_id'];
$date=$_POST['ku_date'];
$kituo=$_POST['kituo'];
$uchungu_tarehe=$_POST['uchungu_date'];
$chupa_kupasuka=$_POST['chupa_kupasuka'];
$tarehe=$_POST['chupa'];
$umri_mimba=$_POST['umri_mimba'];
$kimo_mimba=$_POST['kimo_mimba'];
$mlalo_mtoto=$_POST['mlalo_mtoto'];
$kitangulizi=$_POST['kitangulizi'];
$secral=$_POST['sacral'];
$ischial=$_POST['ischial'];
$ouliel=$_POST['outlet'];
$nyonga_kubwa=$_POST['nyonga'];
$bila_uchungu=$_POST['bila_uchungu'];
$uchungu_kabla=$_POST['uchungu_kabla_34'];
$zaidi_saa12=$_POST['saa_12_uchungu'];
$kitnguliz_kibaya=$_POST['kitangulizi_kibaya'];
$damu_ukeni=$_POST['damu_ukeni'];
$mapigo_kubadilika=$_POST['kubadilika'];
$homa=$_POST['homa'];
$kondo_lanyuma=$_POST['kondo_kukwama'];
$kifafa=$_POST['kifafa'];
$upungufu_damu=$_POST['upungufu_damu'];
$nyonga_mtoto_mkubwa=$_POST['nyonga_nyembamba'];
$meconium=$_POST['meconium'];
$maoni=$_POST['maoni'];
$jina_mhudumu=$_POST['name'];
$cheo=$_POST['cheo'];
$utime=$_POST['uchungu_time'];
$kutime=$_POST['kutime'];
$no_mimba_kusajiliwa=$_POST['mimba_no'];


$query="SELECT * FROM record_uchungu WHERE p_id=$Pid ";
$reslt=mysql_query($query);
@$check=mysql_fetch_assoc($reslt);

$id=$check['p_id'];
$kusajili=$check['no_mimba_kusajiliwa'];

$quer="SELECT * FROM pregnant_woman WHERE p_id=$Pid";
$resl=mysql_query($quer);
$chec=mysql_num_rows($resl);

if($chec==1 ){

if($kusajili !=$no_mimba_kusajiliwa )
{


$sql="INSERT INTO record_uchungu (p_id,no_mimba_kusajiliwa,jina_kituo,kulazwa_date,uchungu_umeanza_date, chupa_imepasuka, date_chupakupasuka, umri_mimba,kimo_mimba, mlalo_mtoto,
kitangulizi, sacral_promontary, ischial_spines, outlet_finyu, nyonga_kubwa_yakutosha, maoni, officer_name, cheo, chupa_imepasuka_bila_uchungu,uchungu_kabla,
saa_toka_uchungu_uanze,tangulizi_kibaya, toka_damu_ukeni,mapigo_mtoto_kubadilika,homa,kondo_lanyuma,kifafa,upungufu_damu,nyonga_mtoto_mkubwa,meconium,saa_kulazwa,saa_uchungu)


VALUES 
('$Pid','$no_mimba_kusajiliwa','$kituo','$date','$uchungu_tarehe','$chupa_kupasuka','$tarehe','$umri_mimba','$kimo_mimba','$mlalo_mtoto','$kitangulizi',
'$secral','$ischial','$ouliel','$nyonga_kubwa','$maoni','$jina_mhudumu','$cheo','$bila_uchungu','$uchungu_kabla','$zaidi_saa12',
'$kitnguliz_kibaya','$damu_ukeni','$mapigo_kubadilika','$homa','$kondo_lanyuma','$kifafa',
'$upungufu_damu','$nyonga_mtoto_mkubwa','$meconium','$kutime','$utime')";



if (!mysql_query($sql,$db))

  {
  die('Error: ' . mysql_error());
  }
else{

   echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you have successfully added record</p></td></tr>";

}

}

  else{echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>this record for this pregnant woman have alread been recorded make sure you enter right pregnant woman number</p></td></tr>";
}
}
else{echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>pregnant woman number you put is not registered</p></td></tr>";
}



}

//progress function

function progress(){
$date=date("Y-m-d");
echo'<form name="visit" method="post">
<h2 align="center">Maendeleo ya uchungu</h2>';




echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;">';

echo'<table width="700px" height="200px" border="0" align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<tr><td><fieldset><table width="350px"><tr><td >Namba ya mjamzito</td><td align="right" ><input type="number" name="p_id" min="1"required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Hii ni mimba ya ngapi toka kusajiliwa</td><td align="right"><input type="number" name="mimba_no" min="1" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >kipimo cha</td><td align="right" ><input type="number" min="1" name="kipimo" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Mapigo ya moyo ya mtoto</td><td align="right" ><input type="number" min="1" name="mapigo_mtoto" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Tarehe na saa</td><td align="right"><input type="date" name="kudate"  required><input type="time" name="kutime"  ></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Maji ya chupa</td><td align="right"><input type="text" name="maji_chupa"  required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Kubonywa kichwa (moulding)</td><td align="right"><select name="kubonywa_kichwa" required>
<option value="hakuna">hakuna</option>
<option value="wastani">wastan</option><option value="sana">sana</option></select></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Njia kufunguka (cervix)</td><td align="right"><input type="number" name="cervix" min="1" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Kichwa kutelemka</td><td align="right"><input type="number" name="kichwa_kutelemka" min="1" required></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Maumivu ya uchungu</td><td align="right"><input type="text" name="maumivu_uchungu"  required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>dawa</td><td align="right"><input type="text" name="dawa" ></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td>Mapigo ya moyo ya mama kwa dakika</td><td align="right"><input type="number" name="mapigo_moyo_mama"  min="1" required></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Blood preassure</td><td align="right"><input type="number" name="blood_preassure"  required>
</td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Albumin kwenye mkojo</td><td align="right"><select  name="albumin" required><option value="ipo">ipo</option>
<option value="hakuna">hakuna</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td>Sukari kwenye mkojo</td><td align="right"><select  name="sukari" required><option value="ipo">ipo</option>
<option value="hakuna">hakuna</option></td></tr></table></fieldset></td></tr>';
echo'<tr><td><fieldset><table width="350px"><tr><td >Acetone kwenye mkojo</td><td align="right"><select  name="acetone" required><option value="ipo">ipo</option>
<option value="hakuna">hakuna</option></td></tr></table></fieldset></td><td><fieldset><table width="350px"><tr><td >Joto la mwili</td><td align="right"><input type="number" name="joto_mwili"  required></td></tr></table></fieldset></td></tr>';

echo'</table></fieldset>';
echo'<fieldset align="center" style="  border-radius:7px; border-color:#E4E4E4;" >';
echo'<table width="700px" height="20px" border="0" align="center"  >';

echo'<tr><td colspan="2" align="right"><input type="submit" name="progrss" value="Register" ></td><td colspan="2"><input type="reset" name="reset" value="cancel"></td></tr>';

echo'</table></fieldset>';
echo'</form>';


}

//function to send data from to progress to the database


function progrss(){
global $db;

$Pid=$_POST['p_id'];
$date=$_POST['kudate'];
$time=$_POST['kutime'];
$mapigo_moyo_mtoto=$_POST['mapigo_mtoto'];
$maji_chupa=$_POST['maji_chupa'];
$kubonywa_kichwa=$_POST['kubonywa_kichwa'];
$cervix=$_POST['cervix'];
$kichwa_kutelemka=$_POST['kichwa_kutelemka'];
$maumivu_uchungu=$_POST['maumivu_uchungu'];
$dawa=$_POST['dawa'];
$mapigo_moyo_mama=$_POST['mapigo_moyo_mama'];
$blood_pressure=$_POST['mapigo_moyo_mama'];
$albumin=$_POST['albumin'];
$sukari=$_POST['sukari'];
$acetone=$_POST['acetone'];
$joto_mwili=$_POST['joto_mwili'];
$mimba_no=$_POST['mimba_no'];
$kipimo=$_POST['kipimo'];


$sql="INSERT INTO muendelezo_uchungu (p_id,no_mimba_kusajiliwa,checkk,tarehe,time,mapigo_moyo_mtoto,maji_chupa, kubonywa_kichwa, cervix, kichwa_kutelemka,maumivu_uchungu, dawa,
mapigo_moyo_mama, blood_pressure, albumin,sukari, acetone, joto_mwili)


VALUES 
('$Pid','$mimba_no','$kipimo','$date','$time','$mapigo_moyo_mtoto','$maji_chupa','$kubonywa_kichwa','$cervix','$kichwa_kutelemka','$maumivu_uchungu','$dawa','$mapigo_moyo_mama',
'$blood_pressure','$albumin','$sukari','$acetone','$joto_mwili')";

if (!mysql_query($sql,$db))

  {
  die('Error: ' . mysql_error());
  }else{
   echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you have successfully added record</p></td></tr>";

}

}

function about(){
echo'<table border="0" width="900px" align="center">
<tr><td><p>Kijacho na Mama Health ipo kumsaidia mwanamke mjamzito kutokana na kuhifadhi kumbukumbu
 zao na utoaji wa ushauri, kwa kuzingatia kanuni na viwango vinavyowezesha huduma ya ujauzito kutolewa katika kituo cha afya,
 hii itasaidia nchi katika jitihada zao kupunguza kiwango cha vifo vinavyosababishwa na masuala ya ujauzito.</p>
<p>Kijacho na Mama Health husaidia utoaji wa utunzaji wa ujauzito, huduma ya ujauzito ni huduma ya 
mwanamke mjamzito hupata kutoka kwa wataalamu wa afya wakati wa ujauzito.
huduma ya ujauzito inaweza kutolewa na muuguzi au mkunga kulingana na hali yake. </p></td><tr>';

}



function main(){
echo'<table border="0" width="900px" align="center">
<tr><td><p>Kumsaidia mwanamke mjamzito katika safari kutoka mimba hadi kujifungua. Pata uongozi na uhakikisho unayohitaji kuhusu matatizo, maendeleo, tabia na habari za afya ya uzazi. </p>
<p>Kuwa mzazi na kumtunza mtoto inaweza kuwa uzoefu mzuri lakini wakati mwingine, inaweza kuwa tofauti pale unapo fanya maamuzi juu ya kuzaliwa kwa watoto wako ambayo inaweza kuwa mpya kwako. Kuteseka kutokana na unyogovu baada ya kuzaa, kuwa mzazi mmoja, kupitia kuvunjika kwa uhusiano na talaka na kupoteza utambulisho wako kunaweza kuleta matatizo zaidi pale unapo kuwa mjamzito.</p></td><tr>';

}




function ahome(){
echo'<div class="pic">

</div>';
echo'<table border="0" width="900px" align="center">
<tr><td><p>Be ethical and this is the job for the people to make sure that pregnant women are health and they giving birth to the health baby dont forget to do this job wisely because any error will endup affecting pregnant woman health. </p>
</td><tr>';

}

function home(){
echo'<div class="pic">

</div>';
echo'<table border="0" width="900px" align="center">
<tr><td><p>Be ethical and this is the job for the people to make sure that pregnant women are health and they giving birth to the health baby dont forget to do this job wisely because any error will endup affecting pregnant woman health. </p></td><tr>';
echo'<tr><td><h3>Register</h3>';
echo'<p>You can register new pregnant woman who is not registered in the system.</p></td><tr>';
echo'<tr><td><h3>Registered</h3>';
echo'<p>You can view all pregnant woman who have been registered in the system and you can enable or disable a pregnant woman to use her account.</p></td><tr>';
echo'<tr><td><h3>Record</h3>';
echo'<p>In this you can be able to take record of the pregnant woman according to the visit.</p></td><tr>';
echo'<tr><td><h3>Change Password</h3>';
echo'<p>You can be able to change your password.</p></td><tr>';

}

function phome(){
echo'<div class="pic">

</div>';
echo'<table border="0" width="800px" align="center">
<tr><td><p>Ili kudumisha afya yako tunakuhimiza kufuata maelekezo yote na ushauri uliopatikana,
 pia tunakuhimiza kutembelea ukurasa wako kila siku ili kuhakikisha unaimalisha afya yako na yaujauzito iwe salama. </p></td><tr>';
echo'<tr><td><h3>counseling</h3>';
echo'<p>Unaweza kuona kila ushauri juu ya hali yako na pia unaweza kupata ushauri kuhusu hali ambayo inaweza kuonekana kwako.</p></td><tr>';


echo'<tr><td><h3>Record</h3>';
echo'<p>Katika hili unaweza kuona rekodi yako ya kila hudhurio na matokeo ya vipimo.</p></td><tr>';

echo'<tr><td><h3>Change Password</h3>';
echo'<p>Katika hili Unauwezo wa kubadilisha neno lako la siri(password) kwaajili ya kuingia kwenye ukurasa wako .</p></td><tr>';

echo'<tr><td><h3>Log out</h3>';
echo'<p>Katika hili unaweza kutoka nje ya ukurasa wako.</p></td><tr>';

}


//function for counseling
function counseling(){
global $db;
	
$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);
 if (isset($_SESSION['user'])){
 $user=$_SESSION['user']['username'];
$sqlquery="SELECT* FROM pregnant_woman
INNER JOIN visit_after_delivery ON pregnant_woman.p_id=visit_after_delivery.p_id 
INNER JOIN visity_before_delivery ON pregnant_woman.p_id=visity_before_delivery.p_id 
INNER JOIN other_inf ON pregnant_woman.p_id=other_inf.p_id 
INNER JOIN record_uchungu ON pregnant_woman.p_id=record_uchungu.p_id  WHERE username='$user'";

$sqlResult=mysql_query($sqlquery);

@$sqlRow=mysql_fetch_assoc($sqlResult);

echo'<table border="0" width="900px" align="center"><form method="post">';


/*echo"<tr><td colspan='2'><h3 align='center'>".$sqlRow['fname']." ".$sqlRow['lname']." Counseling</h3></td></tr>";*/
echo"<tr><td width='100px'><input type='text' name='tatizo' spaceholder='kuhusu' required></td><td><input type='submit' name='search' value='Tafuta' ></td></tr></form><form method='post'>";
echo"<tr ><td colspan='2'><h4><input class='butt' style='color:#336699;   font-weight: bold;' type='submit' name='ushauri' value='Ushauri wa nurse/mkunga'></h4></td></tr>";
/*if($sqlRow['age']<20|| $sqlRow['miaka_mimba_mwisho']>=10
		||$sqlRow['njia_kujifungua']=="ndio"||$sqlRow['mtoto_mfu']=="ndio"
		||$sqlRow['no_mimba_zilizohalibika']>=2||$sqlRow['moyo']="ndio"
		||$sqlRow['kisukari']=="ndio"||$sqlRow['kifua_kikuu']=="ndio"){
			echo"<tr ><td colspan='2'>1. Mama mjamzito unapaswa ufikishwe kituo cha afya au hospital kwa uchunguzi na ushauri</td></tr>"; 
			} else{echo"<tr><td><p> </p></td></tr>";}
			
			if($sqlRow['pregnancy_no']>=5|| $sqlRow['age']>=35
		||$sqlRow['kimo']<150||$sqlRow['njia_yakujifungua']=="ndio"
		||$sqlRow['kondo_kukwama']>="ndio"||$sqlRow['damu_nyingi']="ndio"
		||$sqlRow['kilema_nyonga']=="ndio"){
			echo"<tr><td colspan='2'>2.Mama mjamzito unapaswa ukajifungulie katika kituo cha afya au hospital</td></tr>"; 
			}else{echo"<tr><td><p> </p></td></tr>";}*/
			
	echo"<tr ><td colspan='2'><p><b>Ugonjwa wa asubuhi</b><br>Ugonjwa wa asubuhi ni dalili ya kawaida ya ujauzito wa mapema ambayo kwa kawaida huondoka mwishoni mwa miezi mitatu ya kwanza. Ugonjwa wa asubuhi au kichefuchefu (au bila kutapika) inaweza kutokea wakati wowote wa siku na husababishwa na mabadiliko ya homoni wakati wa ujauzito.<u><input class='butt' align='right' type='submit' value='soma zaidi' name='asubuhi'></u></p> </td></tr>";		
	echo"<tr ><td colspan='2'><p><b>Maumivu ya nyonga wakati wa ujauzito</b><br>Wakati wa ujauzito, mishipa katika mwili wako kawaida huwa myepesi na kunyoosha ili kukuandaa kwa kujifungua. Hii inaweza kuweka matatizo kwenye viungo vya nyuma na nyonga, ambayo inaweza kusababisha maumivu ya nyonga.Kuna mambo kadhaa unaweza kufanya ili kuzuia maumivu ya nyonga wakati wa ujauzito wako.<u><input class='butt' align='right' type='submit' value='soma zaidi' name='backhead'></u></p></td></tr>"; 
	echo"<tr ><td colspan='2'><p><b>Kujaa kwa kibofucha mkojo wakati wa ujauzito</b><br>Wakati wa ujauzito, wanawake wengi hupata hali mbaya zaidi. Kudumisha chakula cha afya na kufanya mazoezi ya kawaida unaweza kusaidia kufanya mimba yako isiwe na wasiwasi kidogo.<u><input class='butt' align='right' type='submit' value='soma zaidi' name='kibofu'></u></p></td></tr>"; 	
	echo"<tr ><td colspan='2'><p><b>Mabadiliko ya ngozi yako wakati wa ujauzito</b><br>Kama mimba yako inakua, unaweza kupata kwamba unapata mabadiliko kwenye ngozi yako na nywele. Wanawake wengine wanaweza kupata mabaka meusi ya uso wao na mabadiliko ya homoni inaweza kufanya ngozi yako kuwa kidogo nyeusi.<u><input class='butt' align='right' type='submit' value='soma zaidi' name='ngozi'></u></p></td></tr>";		
	echo"<tr ><td colspan='2'><p><b>Kupatwa na uchovu wakati wa ujauzito</b><br>Kujisikia uchovu na joto zaidi kuliko kawaida ni kawaida wakati wa ujauzito. Wengi wa wanawake wajawazito pia wanajivunjika na hii ni kutokana na mabadiliko ya homoni.<u><input class='butt' align='right' type='submit' value='soma zaidi' name='uchovu'></u></p></td></tr>"; 
	echo"<tr ><td colspan='2'><p><b>Maumivu ya kichwa na kuvimbiwa wakati wa ujauzito</b><br>Wanawake wengi wanapata kuwa na maumivu ya kichwa na kuvimbiwa katika hatua mbalimbali za ujauzito wao. Kufanya mabadiliko katika maisha yako, kama kupata mapumziko mengi na kudumisha chakula cha afya kunaweza kusaidia kuboresha baadhi ya dalili.<u><input class='butt' align='right' type='submit' value='soma zaidi' name='kichwa'></u></p></td></tr>"; 
	echo"<tr ><td colspan='2'><p><b>Ganzi ya mguu wakati wa ujauzito</b><br>Ganzi ya mguu ni sehemu ya kawaida lakini wakati mwingine haifai ya mimba yako. Jua jinsi ya kutibu na kusaidia kuzuia mabuu ya mguu.<u><input class='butt' align='right' type='submit' value='soma zaidi' name='ganzi'></u></p></td></tr>"; 
	echo"<tr ><td colspan='2'><p><b>Kuvimba wakati wa ujauzito</b><br>Vidonda vya miguu na miguu ni kawaida sana wakati wa ujauzito. Jua jinsi unavyoweza kusaidia kupunguza matatizo na kujua kama dalili yoyote ni mbaya.<u><input class='butt' align='right' type='submit' value='soma zaidi' name='kuvimba'></u></p></td></tr>"; 
	echo"<tr ><td colspan='2'><p><b>Utoaji wa magonjwa wakati wa ujauzito</b><br>Wakati wa ujauzito, karibu wanawake wote wana ukimbizi zaidi wa uke. Hii hutokea kwa sababu kizazi (shingo ya tumbo) na kuta za uke hupata nyepesi wakati wa ujauzito na kutokwa huongezeka ili kusaidia kuzuia maambukizi yoyote ya kusafiri kutoka kwa uke hadi tumboni.<u><input class='butt' align='right' type='submit' value='soma zaidi' name='magonjwa'></u></p></td></tr>"; 
	echo"<tr ><td colspan='2'><p><b>Mishipa ya vurugu</b><br>Mishipa ya vurugu ni ya kawaida, lakini haifai sehemu ya ujauzito na kwa kawaida huenda bila matibabu. Angalia hapa jinsi unaweza kupunguza urahisi.<u><input class='butt' align='right' type='submit' value='soma zaidi' name='mishipa'></u></p></td></tr></form>"; 

		
 

}}


function search(){
global $db;
$special="tumbo";
$asubuhi="asubuhi";
$magonjwa="magonjwa";
$mishipa="mishipa";
$ngozi="ngozi";
$ganzi="ganzi";
$nyonga="nyonga";
$kichwa="kichwa";
$uchovu="uchovu";
$kuvimba="kuvimba";
$kibofu="kibofu";
$sentence=$_POST['tatizo'];
if(strpos($sentence,$special)!==false)
{
if (isset($_SESSION['user'])){
 $user=$_SESSION['user']['username'];
$sqlquery="SELECT* FROM pregnant_woman
INNER JOIN visit_after_delivery ON pregnant_woman.p_id=visit_after_delivery.p_id 
INNER JOIN visity_before_delivery ON pregnant_woman.p_id=visity_before_delivery.p_id 
INNER JOIN other_inf ON pregnant_woman.p_id=other_inf.p_id 
INNER JOIN record_uchungu ON pregnant_woman.p_id=record_uchungu.p_id  WHERE username='$user'";

$sqlResult=mysql_query($sqlquery);

@$sqlRow=mysql_fetch_assoc($sqlResult);

echo'<table border="0" width="900px" align="center"><form method="post">';
echo"<tr><td width='100px'><input type='text' name='tatizo' spaceholder='kuhusu' required></td><td><input type='submit' name='search' value='Tafuta'></td></tr></form>";
echo"<tr ><td colspan='2'><h2 style='color:#336699'>Matumbo ya kibofu na kifua wakati wa ujauzito</h2></td></tr>";

			
	echo"<tr ><td colspan='2'><p>Wakati wa ujauzito, wanawake wengi hupata hali mbaya zaidi kama kuvimbiwa, wanaohitaji urinate mara nyingi zaidi, kutokuwepo na haemorrhoids (piles). Kudumisha lishe bora (lishe) na kufanya zoezi la kawaida (harakati) kunaweza kusaidia kufanya mimba yako isiwe na wasiwasi kidogo.<br><br>		
	<b>Kudumu</b><br>Unaweza kuwa mgonjwa sana mapema mimba kwa sababu ya mabadiliko ya homoni katika mwili wako. Kunyimwa kunaweza kumaanisha kuwa huenda kupita viti (mara kwa mara) mara nyingi kama unavyofanya kawaida, una shida zaidi kuliko kawaida au hauwezi kuondoa kabisa matumbo yako. Kunyimwa pia kunaweza kusababisha viti vyako kuwa ngumu, ngumu, kubwa au ndogo.<br>
	Kuna mambo machache ambayo unaweza kufanya ili kuzuia kuvimbiwa. Hizi ni pamoja na:<br><br>
	<ul style='color:#336699'><li>kula vyakula vilivyo juu ya nyuzi, kama vile mikate yote ya nafaka, nafaka nzima, matunda na mboga mboga, na vimelea kama vile maharagwe na lenti.</li>
	<li>   hoja mara kwa mara ili kuweka misuli yako toni.</li>
	<li>  kunywa maji mengi - kutosha kwamba huna kiu.</li>
	<li>   Epuka virutubisho vya chuma kama wanavyoweza kukufanya uidhinishwe: waulize daktari wako ikiwa unaweza kusimamia bila yao au kubadilisha aina tofauti.</li>
	</ul></p><p>
	<b>Hemorrhoids</b><br>
     Hemorrhoids, pia inajulikana kama 'piles', ni mishipa yaliyoenea na yenye kuvimba ndani au karibu na rectum ya chini na anus. Mtu yeyote anaweza kupata upungufu wa damu - hawana tu kutokea wakati wa ujauzito. Unapokuwa mjamzito, haemorrhoid inaweza kutokea kuvimbiwa na / au shinikizo kutoka kichwa cha mtoto.</p><p>Shughuli nyingine ambazo zinaweza kusaidia kupunguza maumivu yako nyuma ni pamoja na:<br>
	 Haemorrhoids inaweza kupoteza, kumaliza, kujisikia sana au hata kutokwa na damu. Kwa kawaida unaweza kujisikia ubongo wao karibu na anus yako. Wanaweza pia kwenda kwenye choo wasiwasi au chungu. Unaweza pia kuona maumivu wakati wa kupita kinyesi (futi, poo) na kutokwa kwa kamasi baadaye. Wakati mwingine unaweza kujisikia kama kwamba matumbo yako bado yujaa na yanahitaji kuacha.
    <br>Haemorrhoids kawaida kutoweka ndani ya wiki baada ya kuzaliwa.</p>
    <p><b>Jinsi ya kupunguza haemorrhoids</b><br>
     Kunyimwa huweza kusababisha damu na kama hii ni kesi kujaribu kuweka viti yako laini na ya kawaida. Unaweza kusaidia kupunguza damu, na kuwazuia, kwa kufanya mabadiliko mengine kwenye mlo wako na maisha yako:<br><br>
	<ul style='color:#336699'><li>  kula chakula kikubwa cha nyuzi, kama mkate mkate wote, matunda na mboga mboga, na kunywa maji mengi - hii itawazuia kuvimbiwa, ambayo inaweza kuwafanya kuwa mbaya zaidi.</li>
	<li> kuepuka kusimama kwa muda mrefu.</li>
	<li>  senda mara kwa mara ili kuboresha mzunguko wako.</li>
	<li> unaweza kupata ni manufaa kutumia kitambaa kilichopunguka katika maji ya iced ili kupunguza maumivu - shikike kwa upole dhidi ya haemorrhoids.</li>
	<li> ikiwa haemorrhoids hutazama nje, kuwafukuza kwa upole nyuma ndani ya kutumia jelly yenye kulainisha.</li>
	<li> kuepuka kupinga kupita kinyesi kama hii inaweza kuwafanya kuwa mbaya zaidi.</li>
	<li> baada ya kupitisha choo, kusafisha anus yako na karatasi ya choo yenye unyevu badala ya karatasi ya choo kavu</li></ul>
	<p>Kuna madawa ambayo yanaweza kusaidia kuvuta uvimbe karibu na anus yako. Hizi huchukua dalili lakini sio sababu ya damu. Waulize daktari wako, mkunga wa uzazi au mfamasia ikiwa wanaweza kupendekeza mafuta mazuri ili kupunguza urahisi. Usitumie cream au dawa bila kuangalia kwanza nao..<br>
  <br><b> Mzunguko wa mara kwa mara</b><br>
  Uhitaji wa kukimbia mara nyingi (kupitisha maji, au pee) mara nyingi huanza kutoka mapema mimba yako. Wakati mwingine inaendelea vizuri kupitia mimba. Katika mimba ya baadaye haja ya kurudisha mara kwa mara matokeo kutoka kichwa cha mtoto kinachozidi au kupumzika kwenye kibofu cha kibofu.<br></p><p>
   Ikiwa unapata kwamba unahitaji kuamka usiku ili urinate, jaribu kukata vinywaji wakati wa jioni. Lakini hakikisha kunywa maji mengi yasiyo ya pombe, vinywaji vya kahawa wakati wa mchana. Baadaye wakati wa ujauzito, wanawake fulani wanaona husaidia kuharudisha nyuma na mbele wakati wanapo kwenye choo. Hii inapunguza shinikizo la tumbo kwenye kibofu cha kibofu ili uweze kuitumia vizuri. Kisha huenda usihitaji kupitisha maji tena hivi karibuni.<br>
  

	</p></td></tr>"; 
		
 
}
}
else if(strpos($sentence,$kibofu)!==false){
echo kibofu();
}
else if(strpos($sentence,$ganzi)!==false){
echo ganzi();
}
else if(strpos($sentence,$ngozi)!==false){
echo ngozi();
}
else if(strpos($sentence,$asubuhi)!==false){
echo asubuhi();
}
else if(strpos($sentence,$mishipa)!==false){
echo mishipa();
}
else if(strpos($sentence,$magonjwa)!==false){
echo magonjwa();
}
else if(strpos($sentence,$kuvimba)!==false){
echo kuvimba();
}
else if(strpos($sentence,$nyonga)!==false){
echo backhead();
}
else if(strpos($sentence,$uchovu)!==false){
echo uchovu();
}
else if(strpos($sentence,$kichwa)!==false){
echo kichwa();
}
else{
if (isset($_SESSION['user'])){
 $user=$_SESSION['user']['username'];
$sqlquery="SELECT* FROM pregnant_woman
INNER JOIN visit_after_delivery ON pregnant_woman.p_id=visit_after_delivery.p_id 
INNER JOIN visity_before_delivery ON pregnant_woman.p_id=visity_before_delivery.p_id 
INNER JOIN other_inf ON pregnant_woman.p_id=other_inf.p_id 
INNER JOIN record_uchungu ON pregnant_woman.p_id=record_uchungu.p_id  WHERE username='$user'";

$sqlResult=mysql_query($sqlquery);

@$sqlRow=mysql_fetch_assoc($sqlResult);

echo'<table border="0" width="900px" align="center"><form method="post">';
echo"<tr><td width='100px'><input type='text' name='tatizo' spaceholder='kuhusu' required></td><td><input type='submit' name='search' value='Tafuta'></td></tr></form>";

			
	echo"<tr ><td colspan='2'><p>	
	Haijaweza kupata unachokitafuta kwahiyo unashauriwa kufika hospitari haraka iwezekanavyo pale unapoona dalili zozote ambazo huzijui na zile za hatari
	

	</p></td></tr>"; 
}


}







}






//function for change password form
function password(){
global $db;


	
echo "<form method='post'> <table border='0' class='report' align='center'>";
echo"<tr ><td>old password</td><td><input type='password' name='old' required></td></tr>";
echo"<tr ><td>new password</td><td><input type='password' name='new' required></td></tr>";
echo"<tr ><td>confirm new password</td><td><input type='password' name='rnew' required></td></tr>";
echo"<tr ><td colspan='2' align='center'><input type='submit' name='submit' value='submit'></td></tr>";
	

$session=$_SESSION['user']['password'];
$username=$_SESSION['user']['username'];
$user=$_SESSION['user'];
$old=sha1($_POST['old']);
if($user){
if(isset($_POST['submit'])){
if($old==$session){

if($_POST['new']==$_POST['rnew']){

$new=$_POST['new'];
$new1=sha1($new);
if(strlen($new)>8||strlen($new)<8){
echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>password must be exactly 8 character</p></td></tr>";

}

else if(strlen($new)==8){
$s=mysql_query("UPDATE user SET password='$new1' WHERE username='$username'");
if($s){

echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you have successfully change your password</p></td></tr>";

}
else{echo"fail";}
}
}
else if($_POST['new']!=$_POST['rnew']){ 
echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>new passwords do not match</p></td></tr>";
}
}
else {
echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>wrong old password</p></td></tr>";

}
}
	
	}}

	
	
	
	//function for change pregnant woman password form
function changep(){
global $db;
$id=$_GET['change'];


echo "<form method='post'> <table border='0' class='report' align='center'>";
echo"<tr ><td>Your username</td><td><input type='text' name='name' required></td></tr>";
echo"<tr ><td>Your password</td><td><input type='password' name='pass' required></td></tr>";
echo"<tr ><td>user new password</td><td><input type='password' name='rnew' required></td></tr>";
echo"<tr ><td colspan='2' align='center'><input type='submit' name='change' value='submit'></td></tr>";
	

$session=$_SESSION['user']['password'];
$username=$_SESSION['user']['username'];
$user=$_SESSION['user'];
if($user){
if(isset($_POST['change'])){
if($_POST['pass']==$session && $_POST['name']==$username ){

$new=$_POST['rnew'];
$new1=sha1($new);
if(strlen($new)>8||strlen($new)<8){
echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>password must be exactly 8 character</p></td></tr>";

}
else if(strlen($new)==8){
$s=mysql_query("UPDATE user  SET password='$new1' WHERE username='$id'");
if($s){
//echo'<script type="javascript">alert("you have successfully change password for that user" )</script>';
echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>you have successfully change password for that user </p></td></tr>";

}
else{echo"fail";}
}

}
else {
echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>wrong username or password</p></td></tr>";

}
}
	
	}}

	
	
	
	
	
	
	
	
function mtazamo(){
if (isset($_SESSION['user'])){
 $user=$_SESSION['user']['username'];
$sqlquery="SELECT* FROM pregnant_woman
INNER JOIN other_inf ON pregnant_woman.p_id=other_inf.p_id WHERE username='$user'";

$sqlResult=mysql_query($sqlquery);

@$sqlRow=mysql_fetch_assoc($sqlResult);

 $fname=$sqlRow['fname']; 
$lname=$sqlRow['lname']; 
$id=$sqlRow['p_id'];
$datekujifungu=$sqlRow['date_kujifungua'];


if(date("Y-m-d")<$datekujifungu){
$curent=date_create(date("Y-m-d"));
$destination=date_create($datekujifungu);
$days=date_diff($curent,$destination);
echo'<p align="right" style="margin:0 padding: 0">zimebaki siku '. $days->format("%a ").'kujifungua </p>';}

}}
	
	
function pwnr(){
global $db;
	

 if (isset($_SESSION['user'])){
$user=$_SESSION['user']['username'];

$sqlquery="SELECT * FROM pregnant_woman WHERE username='$user'";

$sqlResult=mysql_query($sqlquery);

@$sqlRow=mysql_fetch_assoc($sqlResult);
 $fname=$sqlRow['fname']; 
$lname=$sqlRow['lname']; 
$id=$sqlRow['p_id'];



echo'<form method="post"><table border="0" width="400px"  align="center">';
echo"<tr><td><h3 align='center'>Taarifa za ".$fname." ".$lname."</h3></td></tr></table>";
echo"<tr><td><p align='center'>Mimba ya ngapi kusajiliwa</td><td><input type='number' name='mimba_no' min='1' ></p></td></tr></table>";


echo "<table border='0' class='report' align='center'><tr bgcolor='#CCCCCC'><th><input type='submit' name='before' value='kabla ya kujifungua'></th><th><input type='submit' name='after' value='Baada ya kujifungua'></th><th><input type='submit' name='to' value='Taarifa za uchungu'></th><th><input type='submit' name='for' value='Maelezo ya uzazi'></th><th><input type='submit' name='graph' value='Muendelezo wa uchungu'></th></tr></form>";


if(isset($_POST['before'])){
$no_mimba=$_POST['mimba_no'];
$sqllquery="SELECT* FROM visity_before_delivery WHERE p_id=$id  AND no_mimba_kusajiliwa=$no_mimba";
$sqllResult=mysql_query($sqllquery);
$td1='';$td4='';$td5='';$td6='';$td7='';$td8='';$td9='';$td10='';$td11='';$td12='';$td13='';$td14='';$td15='';
$td2='';$td16='';$td17='';$td18='';$td19='';$td20='';$td21='';$td22='';$td23=''; $td24='';
$td3='';  

$sqllR=@mysql_num_rows($sqllResult);
if($sqllR>=1){
echo"<p align='center'><a href='pd.php?id=".$id."' target='_blank'>Pakua Taarifa</a></p>";
}


while(@$sqllRow=mysql_fetch_assoc($sqllResult)){
$td1.="<td bgcolor='#99CCFF'>".$sqllRow['visiti_no']."</td>";
$td2.="<td bgcolor='#99CCFF'>".$sqllRow['visit_date']."</td>";
$td3.="<td bgcolor='#99CCFF'>".$sqllRow['weight']."</td>";
$td4.="<td bgcolor='#99CCFF'>".$sqllRow['blood_preassure']."</td>";
$td5.="<td bgcolor='#99CCFF'>".$sqllRow['albumin']."</td>";
$td6.="<td bgcolor='#99CCFF'>".$sqllRow['sukari_mkojo']."</td>";
$td7.="<td bgcolor='#99CCFF'>".$sqllRow['umri_mimba']."</td>";
$td8.="<td bgcolor='#99CCFF'>".$sqllRow['kimo_mimba']."</td>";
$td9.="<td bgcolor='#99CCFF'>".$sqllRow['mlalo_mtoto']."</td>";
$td10.="<td bgcolor='#99CCFF'>".$sqllRow['kitangulizi']."</td>";
$td11.="<td bgcolor='#99CCFF'>".$sqllRow['mtoto_kucheza']."</td>";
$td12.="<td bgcolor='#99CCFF'>".$sqllRow['mapigo_moyo_mtoto']."</td>";
$td13.="<td bgcolor='#99CCFF'>".$sqllRow['kuvimba_miguu']."</td>";
$td14.="<td bgcolor='#99CCFF'>".$sqllRow['pepopunda']."</td>";
$td15.="<td bgcolor='#99CCFF'>".$sqllRow['dalili_za_hatari']."</td>";
$td16.="<td bgcolor='#99CCFF'>".$sqllRow['uzazi_wa_mpango']."</td>";
$td17.="<td bgcolor='#99CCFF'>".$sqllRow['magonjwa_ya_kujamiiana']."</td>";
$td18.="<td bgcolor='#99CCFF'>".$sqllRow['return_date']."</td>";
$td19.="<td bgcolor='#99CCFF'>".$sqllRow['officer_name']."</td>";
$td20.="<td bgcolor='#99CCFF'>".$sqllRow['hiv']."</td>";
$td21.="<td bgcolor='#99CCFF'>".$sqllRow['adherence']."</td>";
$td22.="<td bgcolor='#99CCFF'>".$sqllRow['lishe_mtoto']."</td>";
$td23.="<td bgcolor='#99CCFF'>".$sqllRow['damu']."</td>";
$td24.="<td bgcolor='#99CCFF'>".$sqllRow['return_date']."</td>";

}

echo " <table border='0' class='report' align='center'>

<br><tr ><th bgcolor='#CCCCCC'>visiti_n</th>";
echo $td1;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'>visit date</th>";
echo $td2;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'>weight</th>";
echo $td3;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'>blood preassure</th>";
echo $td4;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>albumin</th>";
echo $td5;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>sukari mkojo</th>";
echo $td6;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>umri wa mimba</th>";
echo $td7;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>kimo cha mimba</th>";
echo $td8;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>mlalo wa mtoto</th>";
echo $td9;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>kitangulizi</th>";
echo $td10;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>mtoto kucheza</th>";
echo $td11;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>mapigo ya moyo ya mtoto</th>";
echo $td12;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>kuvimba miguu</th>";
echo $td13;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>pepopunda</th>";
echo $td14;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>dalili za hatari</th>";
echo $td15;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>uzazi wa mpango</th>";
echo $td16;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>magonjwa ya kujamiiana</th>";
echo $td17;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'>officer name</th>";
echo $td19;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>hiv</th>";
echo $td20;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>adherence</th>";
echo $td21;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>lishe_mtoto</th>";
echo $td22;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>damu</th>";
echo $td23;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'>inapaswa urudi kituo cha afya tarehe </th>";
echo $td24;
echo "</tr>";



}


else if(isset($_POST['after'])){
$no_mimba=$_POST['mimba_no'];
$sqllquery="SELECT* FROM visit_after_delivery WHERE p_id=$id AND no_mimba_kusajiliwa=$no_mimba ";
$sqllResult=mysql_query($sqllquery);
$td1='';$td4='';$td5='';$td6='';$td7='';$td8='';$td9='';$td10='';$td11='';$td12='';$td13='';$td14='';$td15='';
$td2='';$td16='';$td17='';$td18='';$td19='';$td20='';$td21='';$td22='';$td23='';$td24='';$td25='';$td26='';$td27='';
$td3='';$td28='';$td29='';$td30='';$td31='';

$sqllR=@mysql_num_rows($sqllResult);
if($sqllR>=1){
echo"<p align='center'><a href='pd1.php?id=".$id."' target='_blank'>Pakua Taarifa</a></p>";
}


while(@$sqllRow=mysql_fetch_assoc($sqllResult)){
$td1.="<td bgcolor='#99CCFF'>".$sqllRow['visit_no']."</td>";
$td2.="<td bgcolor='#99CCFF'>".$sqllRow['visit_date']."</td>";
$td3.="<td bgcolor='#99CCFF'>".$sqllRow['joto_mwili']."</td>";
$td4.="<td bgcolor='#99CCFF'>".$sqllRow['blood_preassure']."</td>";
$td5.="<td bgcolor='#99CCFF'>".$sqllRow['hb']."</td>";
$td6.="<td bgcolor='#99CCFF'>".$sqllRow['lishe']."</td>";
$td7.="<td bgcolor='#99CCFF'>".$sqllRow['mtoto_ananyonya']."</td>";
$td8.="<td bgcolor='#99CCFF'>".$sqllRow['maziwa_yanatoka']."</td>";
$td9.="<td bgcolor='#99CCFF'>".$sqllRow['mtoto_kunyonya_ndani_saa1']."</td>";
$td10.="<td bgcolor='#99CCFF'>".$sqllRow['chuchu_vidonda']."</td>";
$td11.="<td bgcolor='#99CCFF'>".$sqllRow['matiti_yamejaa']."</td>";
$td12.="<td bgcolor='#99CCFF'>".$sqllRow['matiti_majipu']."</td>";
$td13.="<td bgcolor='#99CCFF'>".$sqllRow['tumbo_uzazi_linanyea']."</td>";
$td14.="<td bgcolor='#99CCFF'>".$sqllRow['tumbo_maumivu_makali']."</td>";
$td15.="<td bgcolor='#99CCFF'>".$sqllRow['msamba_kuchanika']."</td>";
$td16.="<td bgcolor='#99CCFF'>".$sqllRow['msamba_alichanika']."</td>";
$td17.="<td bgcolor='#99CCFF'>".$sqllRow['aliongezewa_njia']."</td>";
$td18.="<td bgcolor='#99CCFF'>".$sqllRow['kidonda_kimepona']."</td>";
$td19.="<td bgcolor='#99CCFF'>".$sqllRow['kidonda_kinausaa']."</td>";
$td20.="<td bgcolor='#99CCFF'>".$sqllRow['kidonda_kimeachia']."</td>";
$td21.="<td bgcolor='#99CCFF'>".$sqllRow['lokia_inanuka']."</td>";
$td22.="<td bgcolor='#99CCFF'>".$sqllRow['lokia']."</td>";
$td23.="<td bgcolor='#99CCFF'>".$sqllRow['lokia_rangi_ngapi']."</td>";
$td24.="<td bgcolor='#99CCFF'>".$sqllRow['hali_ya_akili']."</td>";
$td25.="<td bgcolor='#99CCFF'>".$sqllRow['ushauri_uzazi_wampango']."</td>";
$td26.="<td bgcolor='#99CCFF'>".$sqllRow['pepopunda']."</td>";
$td27.="<td bgcolor='#99CCFF'>".$sqllRow['ctx']."</td>";
$td28.="<td bgcolor='#99CCFF'>".$sqllRow['vitamin_a']."</td>";
$td29.="<td bgcolor='#99CCFF'>".$sqllRow['tiba_nyingine']."</td>";
$td30.="<td bgcolor='#99CCFF'>".$sqllRow['return_date']."</td>";
$td31.="<td bgcolor='#99CCFF'>".$sqllRow['officer_name']."</td>";


}

echo " <table border='0' class='report' align='center'>

<br><tr ><th bgcolor='#CCCCCC'align='left'>visiti_no</th>";
echo $td1;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'align='left'>visit date</th>";
echo $td2;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'align='left'>joto la mwili</th>";
echo $td3;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'align='left'>blood preassure</th>";
echo $td4;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>hb</th>";
echo $td5;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>PMTCT lishe ya mtoto</th>";
echo $td6;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>mtoto ananyonya?</th>";
echo $td7;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>maziwa yanatoka</th>";
echo $td8;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>mtoto ameanza kunyonya ndani ya saa 1</th>";
echo $td9;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>chuchu zina vidonda</th>";
echo $td10;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC' align='left'>matiti yamejaa sana</th>";
echo $td11;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>matiti yana majibu</th>";
echo $td12;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>tumbo la uzazi linanyea</th>";
echo $td13;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>tumbo la uzazi linamaumivu makali</th>";
echo $td14;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC' align='left'>msamba hakuchanika?</th>";
echo $td15;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC' align='left'>msamba alichanika</th>";
echo $td16;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC' align='left'>aliongezewa njia</th>";
echo $td17;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC' align='left'>kidonda kimepona</th>";
echo $td18;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>kidonda kinausaa</th>";
echo $td19;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>kidonda kimeachia</th>";
echo $td20;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>lokia inanuka?</th>";
echo $td21;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>lokia kiasi gani?</th>";
echo $td22;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>lokia rangi ngapi</th>";
echo $td23;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>hali ya akili</th>";
echo $td24;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>ushauri uzazi wa mpango</th>";
echo $td25;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>pepopunda</th>";
echo $td26;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>pmtct/ctx kama mama anaishi na VVU</th>";
echo $td27;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>vitamini A</th>";
echo $td28;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'align='left'>tiba nyingine</th>";
echo $td29;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC' align='left'>tarehe ya kurudi</th>";
echo $td30;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC' align='left'>jina la mhudumu</th>";
echo $td31;
echo "</tr>";


}



else if(isset($_POST['to'])){
$no_mimba=$_POST['mimba_no'];
$sqllquery="SELECT* FROM record_uchungu WHERE p_id=$id AND no_mimba_kusajiliwa=$no_mimba";
$sqllResult=mysql_query($sqllquery);
$td1='';$td4='';$td5='';$td6='';$td7='';$td8='';$td9='';$td10='';$td11='';$td12='';$td13='';$td14='';$td15='';
$td2='';$td16='';$td17='';$td18='';$td19='';$td20='';$td21='';$td22='';$td23='';$td24='';$td25='';$td26='';$td27='';
$td3='';$td28='';$td29='';$td30='';$td31='';

$sqllR=@mysql_num_rows($sqllResult);
if($sqllR>=1){
echo"<p align='center'><a href='pd2.php?id=".$id."' target='_blank'>Pakua Taarifa</a></p>";
}

while(@$sqllRow=mysql_fetch_assoc($sqllResult)){
$td1.="<td bgcolor='#99CCFF'>".$sqllRow['jina_kituo']."</td>";
$td2.="<td bgcolor='#99CCFF'>".$sqllRow['kulazwa_date']."</td>";
$td3.="<td bgcolor='#99CCFF'>".$sqllRow['uchungu_umeanza_date']."</td>";
$td4.="<td bgcolor='#99CCFF'>".$sqllRow['chupa_imepasuka']."</td>";
$td5.="<td bgcolor='#99CCFF'>".$sqllRow['date_chupakupasuka']."</td>";
$td6.="<td bgcolor='#99CCFF'>".$sqllRow['umri_mimba']."</td>";
$td7.="<td bgcolor='#99CCFF'>".$sqllRow['kimo_mimba']."</td>";
$td8.="<td bgcolor='#99CCFF'>".$sqllRow['mlalo_mtoto']."</td>";
$td9.="<td bgcolor='#99CCFF'>".$sqllRow['kitangulizi']."</td>";
$td10.="<td bgcolor='#99CCFF'>".$sqllRow['sacral_promontary']."</td>";
$td11.="<td bgcolor='#99CCFF'>".$sqllRow['ischial_spines']."</td>";
$td12.="<td bgcolor='#99CCFF'>".$sqllRow['outlet_finyu']."</td>";
$td13.="<td bgcolor='#99CCFF'>".$sqllRow['nyonga_kubwa_yakutosha']."</td>";
$td14.="<td bgcolor='#99CCFF'>".$sqllRow['maoni']."</td>";
$td15.="<td bgcolor='#99CCFF'>".$sqllRow['chupa_imepasuka_bila_uchungu']."</td>";
$td16.="<td bgcolor='#99CCFF'>".$sqllRow['uchungu_kabla']."</td>";
$td17.="<td bgcolor='#99CCFF'>".$sqllRow['saa_toka_uchungu_uanze']."</td>";
$td18.="<td bgcolor='#99CCFF'>".$sqllRow['tangulizi_kibaya']."</td>";
$td19.="<td bgcolor='#99CCFF'>".$sqllRow['toka_damu_ukeni']."</td>";
$td20.="<td bgcolor='#99CCFF'>".$sqllRow['mapigo_mtoto_kubadilika']."</td>";
$td21.="<td bgcolor='#99CCFF'>".$sqllRow['homa']."</td>";
$td22.="<td bgcolor='#99CCFF'>".$sqllRow['kondo_lanyuma']."</td>";
$td23.="<td bgcolor='#99CCFF'>".$sqllRow['kifafa']."</td>";
$td24.="<td bgcolor='#99CCFF'>".$sqllRow['upungufu_damu']."</td>";
$td25.="<td bgcolor='#99CCFF'>".$sqllRow['nyonga_mtoto_mkubwa']."</td>";
$td26.="<td bgcolor='#99CCFF'>".$sqllRow['meconium']."</td>";
$td27.="<td bgcolor='#99CCFF'>".$sqllRow['officer_name']."</td>";

}

echo " <table border='0' class='report' align='center'>

<br><tr ><th bgcolor='#CCCCCC'  align='left'>jina la kituo</th>";
echo $td1;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC' align='left'>Tarehe ya kulazwa</th>";
echo $td2;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'  align='left'>uchungu umeanza tarehe</th>";
echo $td3;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC' align='left'>chupa imepasuka?</th>";
echo $td4;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>tarehe chupa imepasuka</th>";
echo $td5;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>umri wa mimba (wiki)</th>";
echo $td6;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'  align='left'>kimo cha mimba</th>";
echo $td7;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>mlalo wa mtoto</th>";
echo $td8;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>kitangulizi</th>";
echo $td9;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>sacral promontory imefikiwa?</th>";
echo $td10;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>ischial spines imejitokeza</th>";
echo $td11;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>outlet finyu?</th>";
echo $td12;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>nyonga ni kubwa ya kutosha?</th>";
echo $td13;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>maoni</th>";
echo $td14;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>chupa imepasuka bila uchungu</th>";
echo $td15;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>uchungu kabla ya wiki 34</th>";
echo $td16;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>ni zaid ya saa 12 toka uchungu uanze</th>";
echo $td17;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>mlalo tangulizi kibaya cha mtoto</th>";
echo $td18;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>kutoka damu ukeni</th>";
echo $td19;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>mapigo ya moyo ya mtoto yanabadilika</th>";
echo $td20;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>homa zaidi ya 38 centigrade</th>";
echo $td21;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>kondo la nyuma kukwama</th>";
echo $td22;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>kifafa cha mimba au BP zaidi ya 140/90</th>";
echo $td23;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>upungufu wa damu chini ya(8.5gm/d)</th>";
echo $td24;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>nyonga nyembamba au mtoto mkubwa</th>";
echo $td25;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>meconium</th>";
echo $td26;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>jina la mhudumu</th>";
echo $td27;
echo "</tr>";


}


else if(isset($_POST['for'])){
$no_mimba=$_POST['mimba_no'];
$sqllquery="SELECT* FROM maelezo_uzazi WHERE p_id=$id AND no_mimba_kusajiliwa=$no_mimba";
$sqllResult=mysql_query($sqllquery);
$td1='';$td4='';$td5='';$td6='';$td7='';$td8='';$td9='';$td10='';$td11='';$td12='';$td13='';$td14='';$td15='';
$td2='';$td16='';$td17='';$td18='';$td19='';$td20='';$td21='';$td22='';$td23='';$td24='';$td25='';$td26='';$td27='';
$td3='';$td28='';$td29='';$td30='';$td31='';

$sqllR=@mysql_num_rows($sqllResult);
if($sqllR>=1){
echo"<p align='center'><a href='pd3.php?id=".$id."' target='_blank'>Pakua Taarifa</a></p>";
}


while(@$sqllRow=mysql_fetch_assoc($sqllResult)){
$td1.="<td bgcolor='#99CCFF'>".$sqllRow['kujifungua_date']."  ".$sqllRow['saa_kujifungua']."</td>";
$td2.="<td bgcolor='#99CCFF'>".$sqllRow['njia_yakujifungua']."</td>";
$td3.="<td bgcolor='#99CCFF'>".$sqllRow['sababu_kupasuliwa']."</td>";
$td4.="<td bgcolor='#99CCFF'>".$sqllRow['kondo_limetoka_date']."  ".$sqllRow['saa_kondokutoka']."</td>";
$td5.="<td bgcolor='#99CCFF'>".$sqllRow['kondo_na_membreni_kutoka']."</td>";
$td6.="<td bgcolor='#99CCFF'>".$sqllRow['kiasi_damu']."</td>";
$td7.="<td bgcolor='#99CCFF'>".$sqllRow['ergometrine']."</td>";
$td8.="<td bgcolor='#99CCFF'>".$sqllRow['msamba_kuchanika']."</td>";
$td9.="<td bgcolor='#99CCFF'>".$sqllRow['name_alieshona_msamba']."</td>";
$td10.="<td bgcolor='#99CCFF'>".$sqllRow['cheo']."</td>";
$td11.="<td bgcolor='#99CCFF'>".$sqllRow['BP']."</td>";
$td12.="<td bgcolor='#99CCFF'>".$sqllRow['hatua_ya_kwanza']."</td>";
$td13.="<td bgcolor='#99CCFF'>".$sqllRow['hatua_ya_pili']."</td>";
$td14.="<td bgcolor='#99CCFF'>".$sqllRow['hatua_ya_tatu']."</td>";
$td15.="<td bgcolor='#99CCFF'>".$sqllRow['name_mzalishaji']."</td>";
$td16.="<td bgcolor='#99CCFF'>".$sqllRow['mengineyo']."</td>";
$td17.="<td bgcolor='#99CCFF'>".$sqllRow['baada_ya_kujifungua_arv']."</td>";
$td18.="<td bgcolor='#99CCFF'>".$sqllRow['mtoto_jinsia']."</td>";
$td19.="<td bgcolor='#99CCFF'>".$sqllRow['uzito_mtoto']."</td>";
$td20.="<td bgcolor='#99CCFF'>".$sqllRow['mtoto_amepewa_arv']."</td>";
$td22.="<td bgcolor='#99CCFF'>".$sqllRow['lishe_ya_mtoto']."</td>";
$td23.="<td bgcolor='#99CCFF'>".$sqllRow['apgar1']."</td>";
$td24.="<td bgcolor='#99CCFF'>".$sqllRow['apgar5']."</td>";

}

echo " <table border='0' class='report' align='center'>

<br><tr ><th bgcolor='#CCCCCC'  align='left'>Kujifungua tarehe na saa</th>";
echo $td1;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC' align='left'>Njia ya kujifungua</th>";
echo $td2;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Kama mama amepasuliwa: Sababu za kupasuliwa</th>";
echo $td3;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC' align='left'>Kondo limetoka tarehe na saa</th>";
echo $td4;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Kondo na Membreni zimetoka kamili?</th>";
echo $td5;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Damu iliyotoka</th>";
echo $td6;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Ergometrine/oxtocin</th>";
echo $td7;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Msamba</th>";
echo $td8;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Jina la aliyeshona msamba</th>";
echo $td9;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>cheo</th>";
echo $td10;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>BP baada ya kujifungua</th>";
echo $td11;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Hatua ya 1 saa</th>";
echo $td12;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Hatua ya 2 saa</th>";
echo $td13;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Hatua ya 3 saa</th>";
echo $td14;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Jina la mzalishaji</th>";
echo $td15;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Mengineyo muhimu</th>";
echo $td16;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>ARV baada ya kujifungua</th>";
echo $td17;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Jinsia ya mtoto</th>";
echo $td18;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Uzito wa mtoto</th>";
echo $td19;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>APGAR score 1 dakika</th>";
echo $td23;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>APGAR score 5 dakika</th>";
echo $td24;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Kama mama ni PMTCT, je mtoto amepewa ARV </th>";
echo $td20;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Lishe ya mtoto</th>";
echo $td22;
echo "</tr>";



}



//graph
else if(isset($_POST['graph'])){

$mimba_no=$_POST['mimba_no'];
$sqllquery="SELECT* FROM muendelezo_uchungu WHERE p_id=$id AND no_mimba_kusajiliwa=$mimba_no ";
$sqllResult=mysql_query($sqllquery);
$td1='';$td4='';$td5='';$td6='';$td7='';$td8='';$td9='';$td10='';$td11='';$td12='';$td13='';$td14='';$td15='';
$td2='';$td16='';$td17='';$td18='';$td19='';$td20='';$td21='';$td22='';$td23='';$td24='';$td25='';$td26='';$td27='';
$td3='';$td28='';$td29='';$td30='';$td31='';


$sqll=@mysql_num_rows($sqllResult);
if($sqll>=1){
echo"<p align='center'><a href='pd4.php?id=".$id."' target='_blank'>Pakua Taarifa</a></p>";
}


while(@$sqllRow=mysql_fetch_assoc($sqllResult)){
$td1.="<td bgcolor='#99CCFF'>".$sqllRow['tarehe']."</td>";
$td2.="<td bgcolor='#99CCFF'>".$sqllRow['time']."</td>";
$td3.="<td bgcolor='#99CCFF'>".$sqllRow['mapigo_moyo_mtoto']."</td>";
$td4.="<td bgcolor='#99CCFF'>".$sqllRow['maji_chupa']."</td>";
$td5.="<td bgcolor='#99CCFF'>".$sqllRow['kubonywa_kichwa']."</td>";
$td6.="<td bgcolor='#99CCFF'>".$sqllRow['cervix']."</td>";
$td7.="<td bgcolor='#99CCFF'>".$sqllRow['kichwa_kutelemka']."</td>";
$td8.="<td bgcolor='#99CCFF'>".$sqllRow['dawa']."</td>";
$td9.="<td bgcolor='#99CCFF'>".$sqllRow['mapigo_moyo_mama']."</td>";
$td10.="<td bgcolor='#99CCFF'>".$sqllRow['bLood_pressure']."</td>";
$td11.="<td bgcolor='#99CCFF'>".$sqllRow['albumin']."</td>";
$td12.="<td bgcolor='#99CCFF'>".$sqllRow['sukari']."</td>";
$td13.="<td bgcolor='#99CCFF'>".$sqllRow['acetone']."</td>";
$td14.="<td bgcolor='#99CCFF'>".$sqllRow['joto_mwili']."</td>";
$td15.="<td bgcolor='#99CCFF'>".$sqllRow['checkk']."</td>";


}

echo " <table border='0' class='report' align='center'>

<br><tr ><th bgcolor='#CCCCCC'  align='left'>Tarehe</th>";
echo $td1;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC' align='left'>saa</th>";
echo $td2;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC' align='left'>kipimo cha</th>";
echo $td15;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC' align='left'>mapigo ya moyo ya mtoto</th>";
echo $td3;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'  align='left'>maji ya chupa</th>";
echo $td4;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC' align='left'>Kubonywa kichwa(moulding)</th>";
echo $td5;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>Ukubwa wa njia</th>";
echo $td5;
echo "</tr>";
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>kichwa kutelemka</th>";
echo $td7;
echo "</tr>";
echo"<tr ><th bgcolor='#CCCCCC'  align='left'>dawa zilizotolewa</th>";
echo $td8;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>mapigo moyo mama kwa dakika</th>";
echo $td9;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>shinikizo la damu</th>";
echo $td10;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>albumin</th>";
echo $td11;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>sukari</th>";
echo $td12;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>acetone</th>";
echo $td13;
echo "</tr>";echo"<tr ><th bgcolor='#CCCCCC'  align='left'>joto mwili</th>";
echo $td14;
echo "</tr>";



}





	echo"</form>";
	}
	
	
	}
	

	
	
function asubuhi(){
global $db;
	
$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);
 if (isset($_SESSION['user'])){
 $user=$_SESSION['user']['username'];
$sqlquery="SELECT* FROM pregnant_woman
INNER JOIN visit_after_delivery ON pregnant_woman.p_id=visit_after_delivery.p_id 
INNER JOIN visity_before_delivery ON pregnant_woman.p_id=visity_before_delivery.p_id 
INNER JOIN previous_inf ON pregnant_woman.p_id=previous_inf.p_id 
INNER JOIN record_uchungu ON pregnant_woman.p_id=record_uchungu.p_id  WHERE username='$user'";

$sqlResult=mysql_query($sqlquery);

@$sqlRow=mysql_fetch_assoc($sqlResult);

echo'<table border="0" width="900px" align="center"><form method="post">';
echo"<tr><td width='100px'><input type='text' name='tatizo' spaceholder='kuhusu' required></td><td><input type='submit' name='search' value='Tafuta'></td></tr></form>";
echo"<tr ><td colspan='2'><h2 style='color:#336699'>Ugonjwa wa Asubuhi</h2></td></tr>";

			
	echo"<tr ><td colspan='2'><p>Ugonjwa wa asubuhi ni dalili ya kawaida ya ujauzito wa mapema ambayo kwa kawaida huondoka mwishoni mwa miezi mitatu ya kwanza. Ugonjwa wa asubuhi au kichefuchefu (au bila kutapika) inaweza kutokea wakati wowote wa siku na husababishwa na mabadiliko ya homoni wakati wa ujauzito.<br><br>		
	Ingawa inaitwa 'ugonjwa wa asubuhi', kichefuchefu (au bila ya kutapika) inaweza kutokea wakati wowote wa siku.<br>
	Ugonjwa wa asubuhi husababisha matatizo yoyote kwa mtoto asiyezaliwa. Hata hivyo, ikiwa mwanamke mjamzito anapata kutapika kali na inayoendelea, ni muhimu kuwasiliana na daktari.<br><br>
	Baadhi ya chakula na mapendekezo ya kula ambayo inaweza kusaidia kudhibiti dalili za ugonjwa wa asubuhi au kichefuchefu ni pamoja na:<br>
	<ul style='color:#336699'><li>Kula chakula chache mara nyingi zaidi. Chakula kisichosema kinaweza kutengeneza kichefuchefu zaidi.</li>
	<li>Epuka vinywaji vingi. Kuwa na vinywaji vingi mara kwa mara kati ya chakula.</li>
	<li> Kupunguza mafuta, vyakula vya vitamu na vya kukaanga.</li>
	<li> Kuwa na ufahamu wa chakula una harufu nzuri au harufu wakati unapokaribia, ambayo inaweza kusababisha kichefuchefu zaidi. Ikiwezekana, kuwa na watu wengine kusaidia kwa kupika, au kuandaa chakula chako wakati wa siku unapojisikia vizuri zaidi.</li>
	<li>Jaribu kula biskuti kavu kabla ya kuondoka kitanda asubuhi.</li>
	<li>Kula vitafunio vyenye afya kabla ya kwenda kulala usiku. Hii inaweza kujumuisha matunda (safi, makopo, kavu), wasambazaji wenye jibini ngumu au yoghurt.</li>
	<li>Jaribu vidonge vya tangawizi, tangawizi kavu ale, chai ya peppermint au chai ya tangawizi (kuweka vipande vitatu au vinne vya tangawizi safi katika maji ya moto kwa dakika tano).</li>
	<li> Epuka vyakula kama ladha yao, harufu au kuonekana inakufanya uhisi mgonjwa.</li></ul><br></p><p>
	Kama kutapika, ni muhimu kunywa maji ya kutosha. Inaweza kuwa rahisi kuwa na vinywaji kidogo kuliko kujaribu na kunywa kiasi kikubwa kwa moja. Jaribu aina mbalimbali za maji kama vile maji, maji ya matunda, lemonade na supu zilizo wazi. Wakati mwingine inaweza kuwa na manufaa kujaribu barafu iliyovunjika, slushies, vitalu vya barafu, au hata kunyonya kwenye matunda yaliyohifadhiwa kama vile zabibu au makundi ya machungwa.<br><br>
    Kumbuka: tumbo asidi katika kutapika kunaweza kupunguza vidole vya meno. Ni vyema kutumia siki ya meno kusafisha meno moja kwa moja baada ya kutapika kama hii inaweza kuwaharibu. Uwe na maji ya kunywa kinywa chako.<br><br>
	Usichukue madawa ya aina yoyote kutibu magonjwa yako asubuhi, isipokuwa daktari wako anajua wewe ni mjamzito na ameagiza dawa maalum.<br><br>
	Ikiwa huwezi kuingia katika maji au kuhisi dhaifu, kizunguzungu au usijumuishe, huenda unakabiliwa na upungufu wa maji mwilini na unapaswa kutafuta matibabu kwa haraka.<br><br>
	<b>Muda</b><br>Ugonjwa wa asubuhi huanza kupata bora baada ya wiki 16 hadi 20 za ujauzito. Hata hivyo, baadhi ya wanawake wanaendelea kupata kichefuchefu kwa muda mrefu. Kuhusu mwanamke mmoja kati ya 10 anaendelea kujisikia mgonjwa baada ya wiki 20 ya ujauzito wao. Wakati mwingine ugonjwa wa asubuhi hufikiriwa kuwa ni ugumu mdogo wa ujauzito, lakini unaweza kuwa na athari kubwa, na athari mbaya kwa shughuli za kila siku za mama za kutarajia na ubora wa maisha. Inaweza kutibiwa mara nyingi kwa kufanya mabadiliko ya chakula na kuchukua mapumziko mengi. Msaada wa familia na marafiki pia unaweza kufanya ugonjwa wa asubuhi zaidi uwezekano.<br>
	<br><b>Ni nini kinasababisha ugonjwa wa asubuhi?</b><br>Sababu halisi ya ugonjwa wa asubuhi haijulikani. Hata hivyo, kuna sababu nyingi tofauti, ikiwa ni pamoja na:
	<ul style='color:#336699'><li>   viwango vya estrojeni vilivyoongezeka - mabadiliko katika viwango vya homoni ya kike ya estrogen wakati wa hatua za mwanzo za ujauzito inaweza kusababisha kichefuchefu ya muda mfupi na kutapika</li>
	<li> kuongezeka kwa viwango vya chorionic gonadotrophin (hCG) - homoni mwili huanza kuzalisha baada ya mimba</li>
	<li>  upungufu wa lishe - ukosefu wa vitamini B6 katika chakula hufikiriwa kuwa sababu nyingine inayowezekana</li>
	
	</p></td></tr>"; 
	
}}

	
function backhead(){
global $db;
	
$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);
 if (isset($_SESSION['user'])){
 $user=$_SESSION['user']['username'];
$sqlquery="SELECT* FROM pregnant_woman
INNER JOIN visit_after_delivery ON pregnant_woman.p_id=visit_after_delivery.p_id 
INNER JOIN visity_before_delivery ON pregnant_woman.p_id=visity_before_delivery.p_id 
INNER JOIN previous_inf ON pregnant_woman.p_id=previous_inf.p_id 
INNER JOIN record_uchungu ON pregnant_woman.p_id=record_uchungu.p_id  WHERE username='$user'";

$sqlResult=mysql_query($sqlquery);

@$sqlRow=mysql_fetch_assoc($sqlResult);

echo'<table border="0" width="900px" align="center"><form method="post">';
echo"<tr><td width='100px'><input type='text' name='tatizo' spaceholder='kuhusu' required></td><td><input type='submit' name='search' value='Tafuta'></td></tr></form>";
echo"<tr ><td colspan='2'><h2 style='color:#336699'>Maumivu ya nyonga wakati wa ujauzito</h2></td></tr>";

			
	echo"<tr ><td colspan='2'><p>Wakati wa ujauzito, mishipa katika mwili wako kawaida huwa nyepesi na kunyoosha ili kukuandaa kwa kazi. Hii inaweza kuweka matatizo kwenye viungo vya nyuma na pelvis, ambayo inaweza kusababisha backache. Uzito wa ziada wa uzazi wako na ukubwa wa ziada wa shimo kwenye nyuma yako ya chini pia unaweza kuongeza tatizo.<br><br>		
	<b>Kuepuka maumivu ya nyonga wakati wa ujauzito</b><br>
	Kuna mambo kadhaa unayoweza kufanya ili kusaidia kuzuia maumivu ya nyonga kutokea, na kukusaidia kukabiliana na kurudi nyuma ikiwa hutokea.
Vidokezo vilivyoorodheshwa hapa vinaweza kukusaidia kulinda nyuma yako - jaribu kukumbuka kila siku:<br><br>
	<ul style='color:#336699'><li>kuepuka kuinua vitu nzito.</li>
	<li> Piga magoti yako na kushika nyuma yako wakati unapoinua au ukichukua kitu kutoka kwenye sakafu.</li>
	<li> hoja miguu yako wakati wa kugeuka pande zote ili kuepuka kupotosha nyonga wako.</li>
	<li>  kuvaa viatu vya gorofa kama hizi kuruhusu uzito wako kuwa sawasawa kusambazwa.</li>
	<li>kazi juu ya uso juu ya kutosha ili kuzuia kuinama.</li>
	<li> jaribu kusawazisha uzito kati ya mifuko miwili wakati unafanya manunuzi.</li>
	<li> kuepuka kusimama au kukaa kwa muda mrefu.</li>
	<li> hakikisha kupata upumziko wa kutosha, hasa baadaye baada ya ujauzito.</li></ul><br></p><p>
	Godoro imara pia inaweza kusaidia kuzuia na kuondokana maumivu ya nyonga. Ikiwa godoro yako ni laini sana, weka kipande cha hardboard chini yake ili iwe firmer.
    <br>Shughuli nyingine ambazo zinaweza kusaidia kupunguza maumivu yako nyuma ni pamoja na:<br><br>
	<ul style='color:#336699'><li> aquarobics (zoezi la upole katika maji)</li>
	<li> acupuncture</li>
	<li> massage</li>
	<li> zoezi la kawaida, ikiwa ni pamoja na kutembea.</li></ul>
	<br><p>Mazoezi ya upole hapa chini yanaweza kusaidia kupunguza maumivu ya nyonga wakati wa ujauzito.<br>
    Inaweka kwa maumivu ya nyonga chini:</p><p>
   <ul style='color:#336699'><li> Kukaa na chini yako juu ya visigino yako na magoti yako mbali.</li>
    <li>Kusubiri mbele kuelekea sakafu, ukipiga viti vyao chini mbele yako.</li>
   <li> Punguza kidogo mikono yako mbele.</li>
   <li> Weka kwa sekunde chache.</li></ul></p><p>
   Inaweka maumivu ya nyonga kati:
<ul style='color:#336699'><li>
    Kwenda chini juu ya mikono na magoti.</li>
    <li>Chora katika tummy ya chini.</li>
    <li>Tuck mkia wako chini.</li>
   <li> Weka kwa sekunde chache.</li>
   <li> Upole kupunguza kasi yako nyuma hata kama anahisi vizuri.</li></ul>
   

	</p></td></tr>"; 
	
}}
	

function kibofu(){
global $db;
	
$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);
 if (isset($_SESSION['user'])){
 $user=$_SESSION['user']['username'];
$sqlquery="SELECT* FROM pregnant_woman
INNER JOIN visit_after_delivery ON pregnant_woman.p_id=visit_after_delivery.p_id 
INNER JOIN visity_before_delivery ON pregnant_woman.p_id=visity_before_delivery.p_id 
INNER JOIN previous_inf ON pregnant_woman.p_id=previous_inf.p_id 
INNER JOIN record_uchungu ON pregnant_woman.p_id=record_uchungu.p_id  WHERE username='$user'";

$sqlResult=mysql_query($sqlquery);

@$sqlRow=mysql_fetch_assoc($sqlResult);

echo'<table border="0" width="900px" align="center"><form method="post">';
echo"<tr><td width='100px'><input type='text' name='tatizo' spaceholder='kuhusu' required></td><td><input type='submit' name='search' value='Tafuta'></td></tr></form>";
echo"<tr ><td colspan='2'><h2 style='color:#336699'>Matumbo ya kibofu na kifua wakati wa ujauzito</h2></td></tr>";

			
	echo"<tr ><td colspan='2'><p>Wakati wa ujauzito, wanawake wengi hupata hali mbaya zaidi kama kuvimbiwa, wanaohitaji urinate mara nyingi zaidi, kutokuwepo na haemorrhoids (piles). Kudumisha lishe bora (lishe) na kufanya zoezi la kawaida (harakati) kunaweza kusaidia kufanya mimba yako isiwe na wasiwasi kidogo.<br><br>		
	<b>Kudumu</b><br>Unaweza kuwa mgonjwa sana mapema mimba kwa sababu ya mabadiliko ya homoni katika mwili wako. Kunyimwa kunaweza kumaanisha kuwa huenda kupita viti (mara kwa mara) mara nyingi kama unavyofanya kawaida, una shida zaidi kuliko kawaida au hauwezi kuondoa kabisa matumbo yako. Kunyimwa pia kunaweza kusababisha viti vyako kuwa ngumu, ngumu, kubwa au ndogo.<br>
	Kuna mambo machache ambayo unaweza kufanya ili kuzuia kuvimbiwa. Hizi ni pamoja na:<br><br>
	<ul style='color:#336699'><li>kula vyakula vilivyo juu ya nyuzi, kama vile mikate yote ya nafaka, nafaka nzima, matunda na mboga mboga, na vimelea kama vile maharagwe na lenti.</li>
	<li>   hoja mara kwa mara ili kuweka misuli yako toni.</li>
	<li>  kunywa maji mengi - kutosha kwamba huna kiu.</li>
	<li>   Epuka virutubisho vya chuma kama wanavyoweza kukufanya uidhinishwe: waulize daktari wako ikiwa unaweza kusimamia bila yao au kubadilisha aina tofauti.</li>
	</ul></p><p>
	<b>Hemorrhoids</b><br>
     Hemorrhoids, pia inajulikana kama 'piles', ni mishipa yaliyoenea na yenye kuvimba ndani au karibu na rectum ya chini na anus. Mtu yeyote anaweza kupata upungufu wa damu - hawana tu kutokea wakati wa ujauzito. Unapokuwa mjamzito, haemorrhoid inaweza kutokea kuvimbiwa na / au shinikizo kutoka kichwa cha mtoto.</p><p>Shughuli nyingine ambazo zinaweza kusaidia kupunguza maumivu yako nyuma ni pamoja na:<br>
	 Haemorrhoids inaweza kupoteza, kumaliza, kujisikia sana au hata kutokwa na damu. Kwa kawaida unaweza kujisikia ubongo wao karibu na anus yako. Wanaweza pia kwenda kwenye choo wasiwasi au chungu. Unaweza pia kuona maumivu wakati wa kupita kinyesi (futi, poo) na kutokwa kwa kamasi baadaye. Wakati mwingine unaweza kujisikia kama kwamba matumbo yako bado yujaa na yanahitaji kuacha.
    <br>Haemorrhoids kawaida kutoweka ndani ya wiki baada ya kuzaliwa.</p>
    <p><b>Jinsi ya kupunguza haemorrhoids</b><br>
     Kunyimwa huweza kusababisha damu na kama hii ni kesi kujaribu kuweka viti yako laini na ya kawaida. Unaweza kusaidia kupunguza damu, na kuwazuia, kwa kufanya mabadiliko mengine kwenye mlo wako na maisha yako:<br><br>
	<ul style='color:#336699'><li>  kula chakula kikubwa cha nyuzi, kama mkate mkate wote, matunda na mboga mboga, na kunywa maji mengi - hii itawazuia kuvimbiwa, ambayo inaweza kuwafanya kuwa mbaya zaidi.</li>
	<li> kuepuka kusimama kwa muda mrefu.</li>
	<li>  senda mara kwa mara ili kuboresha mzunguko wako.</li>
	<li> unaweza kupata ni manufaa kutumia kitambaa kilichopunguka katika maji ya iced ili kupunguza maumivu - shikike kwa upole dhidi ya haemorrhoids.</li>
	<li> ikiwa haemorrhoids hutazama nje, kuwafukuza kwa upole nyuma ndani ya kutumia jelly yenye kulainisha.</li>
	<li> kuepuka kupinga kupita kinyesi kama hii inaweza kuwafanya kuwa mbaya zaidi.</li>
	<li> baada ya kupitisha choo, kusafisha anus yako na karatasi ya choo yenye unyevu badala ya karatasi ya choo kavu</li></ul>
	<p>Kuna madawa ambayo yanaweza kusaidia kuvuta uvimbe karibu na anus yako. Hizi huchukua dalili lakini sio sababu ya damu. Waulize daktari wako, mkunga wa uzazi au mfamasia ikiwa wanaweza kupendekeza mafuta mazuri ili kupunguza urahisi. Usitumie cream au dawa bila kuangalia kwanza nao..<br>
  <br><b> Mzunguko wa mara kwa mara</b><br>
  Uhitaji wa kukimbia mara nyingi (kupitisha maji, au pee) mara nyingi huanza kutoka mapema mimba yako. Wakati mwingine inaendelea vizuri kupitia mimba. Katika mimba ya baadaye haja ya kurudisha mara kwa mara matokeo kutoka kichwa cha mtoto kinachozidi au kupumzika kwenye kibofu cha kibofu.<br></p><p>
   Ikiwa unapata kwamba unahitaji kuamka usiku ili urinate, jaribu kukata vinywaji wakati wa jioni. Lakini hakikisha kunywa maji mengi yasiyo ya pombe, vinywaji vya kahawa wakati wa mchana. Baadaye wakati wa ujauzito, wanawake fulani wanaona husaidia kuharudisha nyuma na mbele wakati wanapo kwenye choo. Hii inapunguza shinikizo la tumbo kwenye kibofu cha kibofu ili uweze kuitumia vizuri. Kisha huenda usihitaji kupitisha maji tena hivi karibuni.<br>
  

	</p></td></tr>"; 
	
}}
	
	
function ngozi(){
global $db;
	
$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);
 if (isset($_SESSION['user'])){
 $user=$_SESSION['user']['username'];
$sqlquery="SELECT* FROM pregnant_woman
INNER JOIN visit_after_delivery ON pregnant_woman.p_id=visit_after_delivery.p_id 
INNER JOIN visity_before_delivery ON pregnant_woman.p_id=visity_before_delivery.p_id 
INNER JOIN previous_inf ON pregnant_woman.p_id=previous_inf.p_id 
INNER JOIN record_uchungu ON pregnant_woman.p_id=record_uchungu.p_id  WHERE username='$user'";

$sqlResult=mysql_query($sqlquery);

@$sqlRow=mysql_fetch_assoc($sqlResult);

echo'<table border="0" width="900px" align="center"><form method="post">';
echo"<tr><td width='100px'><input type='text' name='tatizo' spaceholder='kuhusu' required></td><td><input type='submit' name='search' value='Tafuta'></td></tr></form>";
echo"<tr ><td colspan='2'><h2 style='color:#336699'>Mabadiliko ya ngozi yako wakati wa ujauzito</h2></td></tr>";

			
	echo"<tr ><td colspan='2'><p>Kama mimba yako inakua, unaweza kupata kwamba unapata mabadiliko kwenye ngozi yako na nywele. Wanawake wengine wanaweza kuendeleza patches giza juu ya uso wao na mabadiliko ya homoni inaweza kufanya ngozi yako kidogo nyeusi.
<br>Unaweza pia kuendeleza alama za kunyoosha kwenye mwili wako, hasa karibu na tumbo lako ambako ngozi yako imetambulisha ili kukubali mtoto wako.</p><p>		
	<b>Chloasma - patches giza juu ya uso</b><br>Baadhi ya wanawake wajawazito hujenga patches za kawaida za giza kwenye uso wao kwa kawaida kwenye shavu la juu, pua, midomo, na paji la uso. Hii inaitwa 'chloasma'. Wakati mwingine hujulikana kama 'melasma' au 'mask ya ujauzito'.</p><p>
	Chloasma inadhaniwa kuwa ni kutokana na kuchochea kwa seli za kuzalisha rangi na homoni za ngono za kike ili waweze kuzalisha rangi zaidi ya rangi ya rangi ya melanini (rangi nyekundu ya rangi) wakati ngozi inavyoonekana jua. Wanawake wengine huendeleza patches hizi wakati wanapopata uzazi wa mdomo (kidonge).</p><p>
	Wanawake walio na rangi nyekundu ya rangi ya rangi ya kahawia ambao wanaishi katika mikoa na mfiduo wa jua kali ni uwezekano wa kuendeleza patches hizi. Mara nyingi patches hupungua kwa kipindi cha miezi kadhaa baada ya kujifungua, ingawa wanaweza kuishi kwa miaka kadhaa kwa wanawake wengine.</p><p>
	Ulinzi wa ngozi kwa kutumia sunscreens ya wigo mpana kila siku wakati wa ujauzito na wakati kuchukua kidonge inaweza kusababisha uwezekano mdogo kuwa chloasma itaendeleza. Ni muhimu kuendelea kutumia screen ya jua baada ya ujauzito kama mfiduo wa jua huweza kusababisha patches kuonekana tena. Vitamini vingine vinavyohitajika kuagizwa na madaktari vinaweza kusaidia kufuta patches.<br>
	</p><p><b>Mimba inaweza kufanya ngozi yako na mabadiliko ya nywele</b><br>Mabadiliko ya humo yanayotokea wakati wa ujauzito itafanya vidole vyako na eneo liwazunguka liwe giza. Rangi yako ya ngozi inaweza pia kuwa giza kidogo, ama katika patches au kote. Vidokezo vya uzaliwaji wa mimba, miungu na mizigo inaweza pia kuwa giza. Wanawake wengine huendeleza mstari mweusi katikati ya tumbo yao, inayoitwa 'linea nigra'. Mabadiliko haya yatapungua baada ya mtoto kuzaliwa, ingawa vidonda vyako vinaweza kubaki kidogo.</p>
	<p>Ikiwa unapunguza jua wakati unavyo mimba, unaweza kuungua kwa urahisi. Jilinda ngozi yako na jua nzuri ya jua ya juu na usisalie jua kwa muda mrefu.</p>
	<p>Ukuaji wa nywele pia unaweza kuongezeka kwa ujauzito, na nywele zako zinaweza kuwa mbaya zaidi. Baada ya mtoto kuzaliwa, inaweza kuonekana kama wewe ni kupoteza nywele nyingi lakini wewe tu kupoteza nywele ziada.</p>
	</td></tr>"; 
	
}}
		
	

function uchovu (){
global $db;
	
$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);
 if (isset($_SESSION['user'])){
 $user=$_SESSION['user']['username'];
$sqlquery="SELECT* FROM pregnant_woman
INNER JOIN visit_after_delivery ON pregnant_woman.p_id=visit_after_delivery.p_id 
INNER JOIN visity_before_delivery ON pregnant_woman.p_id=visity_before_delivery.p_id 
INNER JOIN previous_inf ON pregnant_woman.p_id=previous_inf.p_id 
INNER JOIN record_uchungu ON pregnant_woman.p_id=record_uchungu.p_id  WHERE username='$user'";

$sqlResult=mysql_query($sqlquery);

@$sqlRow=mysql_fetch_assoc($sqlResult);

echo'<table border="0" width="900px" align="center"><form method="post">';
echo"<tr><td width='100px'><input type='text' name='tatizo' spaceholder='kuhusu' required></td><td><input type='submit' name='search' value='Tafuta'></td></tr></form>";
echo"<tr ><td colspan='2'><h2 style='color:#336699'>Kushughulika na uchovu wakati wa ujauzito</h2></td></tr>";

echo"<tr ><td colspan='2'><p>
Kujisikia uchovu na joto zaidi kuliko kawaida ni kawaida wakati wa ujauzito. Wengi wa wanawake wajawazito pia wanajivunjika na hii ni kutokana na mabadiliko ya homoni.</p>
<p><b>Ukatavu</b><br>
Mara nyingi wanawake wajawazito wanashangaa. Hii ni kwa sababu ya mabadiliko ya homoni yanayotokea katika mwili wako wakati wa ujauzito. Kukata tamaa hutokea ikiwa ubongo wako haukupata damu ya kutosha na kwa hiyo si oksijeni ya kutosha. Ikiwa viwango vya oksijeni wako vinapungua sana, inaweza kukufadhaisha. Una uwezekano wa kufadhaika ikiwa unasimama haraka sana kutoka kiti, kutoka kwenye choo au nje ya kuogelea, lakini pia inaweza kutokea unapokuwa amelala nyuma.</p>
<p><b>Hapa kuna vidokezo vya kukusaidia kukabiliana na:</b></p>
<ul style='color:#336699'><li> 
    jaribu kuinuka polepole baada ya kukaa au kulala</li>
   <li> ikiwa unajivunjika wakati unasimama, pata kiti haraka na kukata tamaa kunapaswa kupitishwa - kama haifai, ulala upande wako</li>
    <li>ikiwa unajivunjika wakati ukiwa juu ya nyonga wako, tembea upande wako (ni vizuri sio uongo juu ya nyonga wako baada ya ujauzito au wakati wa kazi).</li>
   <li> Ikiwa hali ya hewa ni ya moto kuwa na uhakika wa kunywa maji mengi.</li></ul>
<p><b> Moto</b><br>
Wakati wa ujauzito huenda ukahisi joto zaidi kuliko kawaida. Hii ni kutokana na mabadiliko ya homoni na ongezeko la damu kwa ngozi. Pia una uwezekano wa jasho zaidi. Inasaidia ikiwa:</p>
<ul style='color:#336699'><li> 
   kuvaa nguo za kutosha zilizofanywa kwa nyuzi za asili, kama hizi zinazidi zaidi na hupumu zaidi kuliko nyuzi za synthetic</li>
   <li> kuweka chumba chako baridi - unaweza kutumia shabiki wa umeme ili kuifanya</li>
   <li> Osha mara nyingi ili kukusaidia kujisikia safi.</li>
   <li> kunywa maji mengi.</li></ul>

<p><b>Uchovu na usingizi</b><br>
Ni kawaida kujisikia uchovu, au hata nimechoka, wakati wa ujauzito, hasa katika wiki 12 za kwanza au zaidi. Mabadiliko ya hormone yanayotokea katika mwili wako wakati huu yanaweza kukufanya uhisi umechoka, kichefuchefu na kihisia. Jibu pekee ni kujaribu kupumzika iwezekanavyo. Fanya muda wa kukaa na miguu yako hadi wakati wa mchana, na kukubali msaada wowote kutoka kwa wenzake na familia. Kuwa amechoka na kukimbia kunaweza kukufanya uhisi chini. Jaribu kuangalia afya yako ya kimwili kwa kula chakula cha afya na kupata mapumziko mengi na usingizi.</p>

<p>Baadaye wakati wa ujauzito, unaweza kujisikia uchovu kwa sababu ya uzito wa ziada unayobeba. Hakikisha kupata mapumziko mengi. Kama mtoto wako anapata kubwa, inaweza kuwa vigumu kupata usingizi mzuri wa usiku. Unaweza kupata sio usingizi amelala chini au, wakati tu unapostahili, unastahili kwenda kwenye choo.</p>

<p>Kuhisi uchovu hakutakuumiza wewe au mtoto wako, lakini inaweza kufanya maisha kujisikie zaidi, hasa katika siku za mwanzo kabla ya kuwaambia watu kuhusu mimba yako. Hakikisha kupata mapumziko mengi kama unaweza.</p>



</td></tr>"; 
	
}}
	

	
	
function kichwa(){
global $db;
	
$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);
 if (isset($_SESSION['user'])){
 $user=$_SESSION['user']['username'];
$sqlquery="SELECT* FROM pregnant_woman
INNER JOIN visit_after_delivery ON pregnant_woman.p_id=visit_after_delivery.p_id 
INNER JOIN visity_before_delivery ON pregnant_woman.p_id=visity_before_delivery.p_id 
INNER JOIN previous_inf ON pregnant_woman.p_id=previous_inf.p_id 
INNER JOIN record_uchungu ON pregnant_woman.p_id=record_uchungu.p_id  WHERE username='$user'";

$sqlResult=mysql_query($sqlquery);

@$sqlRow=mysql_fetch_assoc($sqlResult);

echo'<table border="0" width="900px" align="center"><form method="post">';
echo"<tr><td width='100px'><input type='text' name='tatizo' spaceholder='kuhusu' required></td><td><input type='submit' name='search' value='Tafuta'></td></tr></form>";
echo"<tr ><td colspan='2'><h2 style='color:#336699'>Kichwa cha kichwa na kuvimbiwa wakati wa ujauzito</h2></td></tr>";

echo"<tr ><td colspan='2'><p>
Wanawake wengi wanapata kuwa na maumivu ya kichwa na kuvimbiwa katika hatua mbalimbali za ujauzito wao. Kufanya mabadiliko katika maisha yako, kama kupata mapumziko mengi na kudumisha chakula cha afya kunaweza kusaidia kuboresha baadhi ya dalili.</p>
<p><b>Kichwa cha kichwa</b><br>

Mimba ni kuchochea kwa maumivu ya kichwa. Wanawake wengine wajawazito hupata kupata maumivu ya kichwa. Kichwa cha kichwa kinaweza kuwa mbaya zaidi katika wiki chache za mimba, lakini kwa kawaida huboresha au kuacha kabisa wakati wa miezi sita iliyopita (kutoka karibu na wiki 17 mjamzito). Hawana kumdhuru mtoto lakini wanaweza kuwa na wasiwasi kwako.</p>

<p>Mabadiliko ya maisha yako yanaweza kuzuia maumivu ya kichwa. Jaribu kupata mapumziko zaidi ya mara kwa mara na utulivu au unaweza pia kujaribu darasa la yoga la ujauzito.</p>

<p>Kuchukua paracetamol katika dozi iliyopendekezwa kwa ujumla huonekana kuwa salama kwa wanawake wajawazito. Ongea na mfamasia wako, mkunga, daktari au muuguzi kuhusu kiwango cha paracetamol ambacho unaweza kuchukua na kwa muda gani.</p>

<p>Hata hivyo, kuna wagonjwa wengine ambao unapaswa kuepuka wakati wa ujauzito, kama vile wale walio na codeine na kupambana na uchochezi, kama vile ibuprofen.</p>

<p>Wakati wa nusu ya pili ya ujauzito wako ikiwa unakua maumivu ya kichwa ambayo ni mapya, ambayo ni mbele ya kichwa chako na haiwezi kuondolewa na paracetamol inaweza kuwa ishara kwamba unaendeleza kitu kikubwa kama vile kabla ya eclampsia (ujauzito unaosababisha shinikizo la damu). Ni muhimu kuzungumza maumivu ya kichwa na daktari au mkunga wako.</p>

<p><b>Ufafanuzi</b><br>

Upungufu, pia unaojulikana kama 'dyspepsia', ni maumivu au wasiwasi katika tumbo la juu (tumbo). Ikiwa una kuvimbiwa, unaweza kupata dalili kadhaa, ikiwa ni pamoja na:</p>
<ul style='color:#336699'><li> 
    kupungua kwa moyo - hisia inayowaka ambayo husababishwa na asidi ya kupita kutoka tumbo hadi kwenye tumbo (bomba la chakula)</li>
    <li>kurudia (chakula kinachoirudi kutoka tumbo).</li> 
   <li> bloating.</li>
   <li> kichefuchefu (kuhisi mgonjwa).</li>
   <li> kutapika (kuwa mgonjwa).</li></ul>

<p>Watu wengi huathiriwa mara kwa mara, lakini mara nyingi wanawake wanaathiriwa wakati wanapojawazito. Wanawake 8 kati ya 10 wanapata kuvimbiwa wakati fulani wakati wa ujauzito. Unyogovu huelekea kuwa kawaida zaidi wakati mtoto anavyoendelea. Unyogovu wakati wa ujauzito ni hasa kutokana na mabadiliko yanayotokea katika mwili, kama vile viwango vya kupanda kwa homoni na shinikizo la juu la tumbo (tumbo). Mabadiliko haya mara nyingi yanaweza kusababisha asidi reflux, sababu ya kawaida ya kuvimbiwa. Reflux ya asidi hutokea wakati asidi ya tumbo inapita nyuma kutoka tumbo hadi kwenye tumbo (bomba la chakula) na inakera kitambaa (mucosa).</p>

<p>Mabadiliko kadhaa ya maisha yanaweza kusaidia kuboresha dalili za kuvimbiwa, kama vile kula chakula kidogo au kukata vyakula fulani. Pia kuna madawa, kama vile antacids, ambayo yanaweza kuchukuliwa salama wakati wa ujauzito ili kutibu kuvimbiwa - angalia na daktari wako au mfamasia wa eneo ambayo unaweza kuchukua. Wanawake wengine wanaweza kupata kuwa kuvimbiwa yao inakuwa mbaya zaidi wakati mimba yao inavyoendelea. Hata hivyo, mara nyingi, baada ya kuzaliwa, dalili hupotea.</p>
<p>Unyogovu wakati wa ujauzito huwa husababishwa na matatizo.</p>

<p>Hata hivyo, maumivu mapya ya kawaida, sawa na kuvimbiwa, kwenye tumbo lako la juu ambalo haliondolewa na antacids au mabadiliko ya maisha, inaweza kuwa ishara kwamba unaendeleza kabla ya eclampsia (ujauzito unahusisha shinikizo la damu). Ni muhimu kuzungumza hili na daktari wako au mkunga.</p>
</td></tr>"; 
	
}}
		
	
function ganzi(){
global $db;
	
$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);
 if (isset($_SESSION['user'])){
 $user=$_SESSION['user']['username'];
$sqlquery="SELECT* FROM pregnant_woman
INNER JOIN visit_after_delivery ON pregnant_woman.p_id=visit_after_delivery.p_id 
INNER JOIN visity_before_delivery ON pregnant_woman.p_id=visity_before_delivery.p_id 
INNER JOIN previous_inf ON pregnant_woman.p_id=previous_inf.p_id 
INNER JOIN record_uchungu ON pregnant_woman.p_id=record_uchungu.p_id  WHERE username='$user'";

$sqlResult=mysql_query($sqlquery);

@$sqlRow=mysql_fetch_assoc($sqlResult);

echo'<table border="0" width="900px" align="center"><form method="post">';
echo"<tr><td width='100px'><input type='text' name='tatizo' spaceholder='kuhusu' required></td><td><input type='submit' name='search' value='Tafuta'></td></tr></form>";
echo"<tr ><td colspan='2'><h2 style='color:#336699'>Ganzi ya mguu wakati wa ujauzito</h2></td></tr>";

echo"<tr ><td colspan='2'><p>
Pamoja na vidonda vya uvimbe na vurugu, mabuu ya mguu ni sehemu ya kawaida lakini wakati mwingine haifai mimba. Kujua nini cha kufanya unapopata mchanga na jinsi ya kuzuia mabuzi kutokea huweza kufanya mimba yako iwe rahisi zaidi.</p>
<p><b>Je! Ni mavuno gani na kwa nini ni kawaida wakati wa ujauzito?</b><br>

Mimea ni maumivu ya ghafla, mkali, kwa kawaida katika misuli yako au miguu. Mtiko ni ishara kwamba misuli yako inaambukizwa sana wakati haifai kuwa. Mara nyingi hutokea usiku na ni kawaida zaidi mwishoni mwa ujauzito wako. Wanaweza kuwa na wasiwasi sana na inaweza kuwa vigumu kujua nini cha kufanya.

</p><p>Kuna sababu nyingi zilizopendekezwa za kamba wakati ukiwa na mimba - ukibeba uzito, mabadiliko ya kimetaboliki yako, kuwa na upungufu wa vitamini, kuwa na kazi nyingi au kuwa hai kwa kutosha. Ukweli ni kwamba hakuna mtu anayejua.</p>
<p><b>Je, mabuu ya mguu yanaweza kuzuiwa?</b><br>

Mazoezi fulani yanaweza kukusaidia kuzuia mavuno.</p>

<p>Mazoezi ya upole, kama vile kutembea au kuogelea, na mazoezi maalum, ikiwa ni pamoja na ndama hufufua na kutembea papo hapo, ni nzuri kwa kusaidia damu kuingilia miguu na inaweza kusaidia kuzuia kuponda.</p>

<p>Kwa kweli, zoezi la kawaida, wakati wa ujauzito wakati wa ujauzito ni wazo nzuri, kwa sababu husaidia mwili wako kutumika kwa mabadiliko ya kimwili yanayotokea wakati wa ujauzito.</p>

<p>Unaweza kujaribu mazoezi maalum ya mguu na mguu kama vile:</p>
<ul style='color:#336699'><li> 
    kusonga na kunyoosha mguu wako kwa kasi na chini mara 30.</li>
    <li>kuzunguka mguu wako mara 8 kwa njia moja na mara nane.</li>
    <li>kurudia kwa mguu mwingine.</li></ul>

<p>Supplement magnesiamu inaweza pia kusaidia. Ongea na daktari wako kuhusu kama hii inaweza kukufanyia kazi.</p>
<p><b>Jinsi ya kuondokana na miamba</b><br>
Ili kupunguza mguu wa mguu, mara nyingi husaidia ikiwa unyoosha misuli kwa kuvuta vidole vyako vigumu kuelekea kwenye mguu wako. Unaweza pia kusukuma misuli imara au kutembea kwa muda. Ikiwa una mpenzi, waombe wasaidie.</p>

<p>Wakati mwingine khalini hupendekezwa kama tiba ya makoma, lakini hakuna ushahidi wowote unaofanya kazi.</p>
<p><b>Wakati wa kuzungumza na daktari wako au mkungaji kuhusu kamba zako</b><br>

Unapaswa kuzungumza na daktari wako au mchungaji juu ya miamba yako ikiwa:</p>
<ul style='color:#336699'><li> 
    wanachanganyiza usingizi wako</li>
   <li> wao ni chungu sana</li>
    <li>unasikia wasiwasi juu yao.</li></ul>

<p>Ikiwa hujui nini cha kufanya unapopata kamba, au usijui njia bora ya kukabiliana nao, wasiliana na daktari wako au mkunga.</p>
</td></tr>"; 
	
}}
	
	

function kuvimba(){
global $db;
	
$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);
 if (isset($_SESSION['user'])){
 $user=$_SESSION['user']['username'];
$sqlquery="SELECT* FROM pregnant_woman
INNER JOIN visit_after_delivery ON pregnant_woman.p_id=visit_after_delivery.p_id 
INNER JOIN visity_before_delivery ON pregnant_woman.p_id=visity_before_delivery.p_id 
INNER JOIN previous_inf ON pregnant_woman.p_id=previous_inf.p_id 
INNER JOIN record_uchungu ON pregnant_woman.p_id=record_uchungu.p_id  WHERE username='$user'";

$sqlResult=mysql_query($sqlquery);

@$sqlRow=mysql_fetch_assoc($sqlResult);

echo'<table border="0" width="900px" align="center"><form method="post">';
echo"<tr><td width='100px'><input type='text' name='tatizo' spaceholder='kuhusu' required></td><td><input type='submit' name='search' value='Tafuta'></td></tr></form>";
echo"<tr ><td colspan='2'><h2 style='color:#336699'>Kuvimba wakati wa ujauzito</h2></td></tr>";

echo"<tr ><td colspan='2'><p>
Wanawake wengi hupata vidole vya kuvimba na miguu wakati wajawazito. Ni ya kawaida kuwa na wasiwasi juu ya uvimbe kwa sababu inaweza kuwa na wasiwasi, kufanya viatu vyako vipigane na uwezekano wa kufanya kujisikia aibu. Kujua nini cha kuangalia na jinsi bora ya kusimamia inaweza kukusaidia kukaa vizuri iwezekanavyo.</p>
<p><b>Kwa nini wanawake hupata uvimbe wakati wa ujauzito?</b><br>

Kuna sababu tatu kuu ambazo wanawake hupata uvimbe wakati wajawazito.</p>
<ul style='color:#336699'><li> 
    Katika ujauzito, hutoa damu zaidi kuliko kawaida ili kumsaidia mtoto wako kukua.</li>
    <li>Wakati mtoto akikua, uterasi yako inacheza na kuzuia kidogo mishipa ambayo inarudi damu kutoka miguu yako kwa moyo wako.</li>
    <li>Mahomoni yako hufanya kuta za mishipa yako nyepesi, ambayo inafanya kuwa vigumu kwao kufanya kazi vizuri.</li></ul>
<p>Kwa sababu hizi, damu yako huelekea kuziba kwenye miguu yako. Huko, kiasi kidogo cha damu kinachovuja kwa njia ya mishipa ndogo ya damu ndani ya tishu na hutoa uvimbe unaweza kuona na kujisikia.
</p><p><b>Je, nitapata uvimbe wapi na lini?</b><br>

Uvimbe lazima iwe kwa miguu yako na vidole. Vidole vyako vinaweza kupata kubwa zaidi - kutosha kufanya pete yoyote kujisikia tight - lakini haipaswi kuwa wazi kuvimba.

</p><p>Miguu yako na vidole ni uwezekano wa kuzama baadaye wakati wa siku. Hii ni hasa kutokana na mvuto - maji yoyote ya ziada katika mwili wako yatazama miguu na vidole, hasa ikiwa unatumia muda mwingi kwa miguu yako.

</p><p>Kuvimba pia kuna uwezekano wa kutokea baadaye katika ujauzito wako.

</p><p>Kuvimba uvimbe sio hatari kwa wewe au mtoto wako, lakini inaweza kujisikia wasiwasi.</p>

<p><b>Ninawezaje kupunguza uvimbe?</b><br>

Mambo machache yanaweza kukusaidia kujisikia vizuri zaidi na pia inaweza kusaidia kuzuia uvimbe.<br>

Jaribu ku:</p>
<ul style='color:#336699'><li> 
    kuepuka kusimama kwa muda mrefu bila kusonga</li>
   <li> kuvaa viatu vizuri (kuepuka sahani zenye nguvu au kitu chochote ambacho kinaweza kunyoosha ikiwa miguu yako imeenea).</li>
   <li> Weka miguu yako juu kabisa iwezekanavyo.</li>
   <li> punguza vyakula vya chumvi na chumvi nyingi katika mlo wako.</li>
    <li>kulala upande wako wa kushoto, ambayo itasaidia damu kurudi moyoni.</li>
   <li> zoezi mara kwa mara kwa kutembea au kuogelea - hii inasaidia kuweka mzunguko wako.</li></ul>
<p>Ikiwa unahitaji kusimama kwa muda mrefu, jaribu kuzunguka na kubadilisha nafasi mara kwa mara.

</p><p>Vipuri vya ukandamizaji vinaweza kusaidia mtiririko wa damu kurudi moyoni na kupunguza kiasi cha kuvimba. Massage na reflexology pia inaweza kusaidia kupunguza dalili za uvimbe na kuhusishwa.

</p><p>Hata ikiwa uvimbe wako unakukosesha, kumbuka bado kunywa maji mengi. Kuweka fluids yako ni muhimu ili kuepuka maji mwilini na kukaa na afya.</p>


</td></tr>"; 
	
}}
	




function magonjwa(){
global $db;
	
$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);
 if (isset($_SESSION['user'])){
 $user=$_SESSION['user']['username'];
$sqlquery="SELECT* FROM pregnant_woman
INNER JOIN visit_after_delivery ON pregnant_woman.p_id=visit_after_delivery.p_id 
INNER JOIN visity_before_delivery ON pregnant_woman.p_id=visity_before_delivery.p_id 
INNER JOIN previous_inf ON pregnant_woman.p_id=previous_inf.p_id 
INNER JOIN record_uchungu ON pregnant_woman.p_id=record_uchungu.p_id  WHERE username='$user'";

$sqlResult=mysql_query($sqlquery);

@$sqlRow=mysql_fetch_assoc($sqlResult);

echo'<table border="0" width="900px" align="center"><form method="post">';
echo"<tr><td width='100px'><input type='text' name='tatizo' spaceholder='kuhusu' required></td><td><input type='submit' name='search' value='Tafuta'></td></tr></form>";
echo"<tr ><td colspan='2'><h2 style='color:#336699'>Utoaji wa magonjwa wakati wa ujauzito</h2></td></tr>";

echo"<tr ><td colspan='2'><p>
Wanawake wote, ikiwa ni mjamzito au la, huwa na kutokwa kwa uke kuanzia mwaka mmoja au mbili kabla ya kuacha na kumaliza baada ya kumaliza. Umebadilisha kiasi gani mara kwa mara na kwa kawaida hupata uzito kabla ya kipindi chako.</p>
<p><b>Je, ni kawaida kuwa na uke wa kike katika ujauzito?</b><br>

Karibu wanawake wote wana ukimbizi zaidi wa uke katika ujauzito. Hii ni ya kawaida na hutokea kwa sababu kadhaa. Wakati wa ujauzito kizazi (shingo ya tumbo) na kuta za uke huongezeka zaidi na kutokwa ili kuzuia maambukizi yoyote yanayosafiri kutoka kwenye uke hadi tumboni.
</p><p>Karibu na mwisho wa ujauzito, kiwango cha kutokwa huongezeka na inaweza kuchanganyikiwa na mkojo.
</p><p>Katika juma la mwisho au la mimba, kutokwa kwako kunaweza kuwa na mishipa ya mucus mwembamba na damu fulani. Hii inaitwa 'show' na hutokea wakati kamasi ambayo imekuwapo katika kizazi chako wakati wa ujauzito inakuja mbali. Ni ishara kwamba mwili unaanza kujiandaa kwa kuzaliwa, na huenda ukawa na 'maonyesho' madogo machache kabla ya kwenda kwenye kazi.
</p><p>Kuongezeka kwa kutokwa ni sehemu ya kawaida ya ujauzito, lakini ni muhimu kushika jicho na kumwambia daktari wako au mkunga kama inabadilika kwa njia yoyote.</p>
<p><b>Wakati wa kuona mkunga wako au daktari wako</b><br>
Mwambie mkunga wako au daktari kama:</p>
<ul style='color:#336699'><li>
    kutokwa ni rangi hasa ikiwa ni rangi ya rangi</li>
   <li> inatukia ajabu</li>
   <li> unajisikia au kuumiza.</li></ul>

<p>Utoaji wa uke wa afya unapaswa kuwa wazi na nyeupe na haipaswi kusikia haifai. Ikiwa utekelezaji ni rangi au harufu ya ajabu, au ikiwa unahisi au huumiza, unaweza kuwa na maambukizi ya uke. Ikiwa mtuhumiwa ametokana na uke, angalia ushauri wa matibabu haraka.
</p><p>Maambukizi ya kawaida ni thrush, ambayo daktari wako anaweza kutibu kwa urahisi. Unapaswa kutumia dawa za thrush wakati wa ujauzito.
</p><p>Daima kuzungumza na daktari wako, mfamasia au mkunga kama unadhani una thrush. Unaweza kusaidia kuzuia thrush kwa kuvaa nguo za pamba huru, na baadhi ya wanawake wanapata husaidia kuepuka sabuni yenye ubani au bidhaa za kuoga.
</p><p>Unapaswa pia kumwambia mkunga wako au daktari ikiwa ukimbizi wako wa uke huongeza mengi katika mimba ya baadaye.
</p><p>Ikiwa una damu ya uke wakati wa ujauzito, unapaswa kuwasiliana na mkunga wako au daktari, kwa sababu wakati mwingine inaweza kuwa ishara ya tatizo kubwa zaidi kama uharibifu wa mimba au tatizo la placenta.</p>



</td></tr>"; 
	
}}
	
	


function mishipa(){
global $db;
	
$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);
 if (isset($_SESSION['user'])){
 $user=$_SESSION['user']['username'];
$sqlquery="SELECT* FROM pregnant_woman
INNER JOIN visit_after_delivery ON pregnant_woman.p_id=visit_after_delivery.p_id 
INNER JOIN visity_before_delivery ON pregnant_woman.p_id=visity_before_delivery.p_id 
INNER JOIN previous_inf ON pregnant_woman.p_id=previous_inf.p_id 
INNER JOIN record_uchungu ON pregnant_woman.p_id=record_uchungu.p_id  WHERE username='$user'";

$sqlResult=mysql_query($sqlquery);

@$sqlRow=mysql_fetch_assoc($sqlResult);

echo'<table border="0" width="900px" align="center"><form method="post">';
echo"<tr><td width='100px'><input type='text' name='tatizo' spaceholder='kuhusu' required></td><td><input type='submit' name='search' value='Tafuta'></td></tr></form>";
echo"<tr ><td colspan='2'><h2 style='color:#336699'>Mishipa ya vurugu</h2></td></tr>";

echo"<tr ><td colspan='2'><p>
Kuwa na miguu ya kuvimba, kwa kupotosha, mishipa yenye mishipa ni ya kawaida, lakini haifai, ni sehemu ya ujauzito. Kwa kawaida, mishipa ya vurugu huenda mbali wakati mtoto wako akiwa mzee mmoja. Na kuna njia za kupunguza usumbufu.
Mishipa ya uvimbe katika ujauzito</p><p>Mishipa ya vurugu ni ya kawaida wakati wa ujauzito. Kuvaa tights msaada au soksi inaweza kusaidia na mzunguko.</p>
<p><b>Kwa nini mishipa ya varicose hutokea?</b><br>
Mishipa ya mguu mzuri yana valves ya njia moja ili kusaidia damu kurudi kwa moyo. Unapotembea, misuli yako ya ndama hupiga damu hadi kwenye moyo wako, na valves huacha kuanguka nyuma.
</p><p>Mishipa ya uvimbe huendeleza wakati hizi valves za njia moja hazifanyi kazi vizuri. Hii inasababisha damu kuifunga katika mishipa, ambayo hupanua kuta za mviringo na husababisha mishipa kuenea, kupotoka na kupasuka. Ikiwa vinakuwa kubwa kwa kutosha, unaweza kuwaona chini ya ngozi yako.</p>
<p><b>Kwa nini ni kawaida wakati wa ujauzito?</b><br>
Mimba huongeza uwezekano wako wa kuendeleza mishipa ya vurugu kwa sababu tatu kuu.</p>
<ul style='color:#336699'><li>
    Katika ujauzito, hutoa damu zaidi kuliko kawaida ili kumsaidia mtoto wako kukua.</li>
  <li>  Wakati mtoto akikua, uterasi yako inacheza na sehemu fulani huzuia mishipa ambayo inarudi damu kutoka miguu yako kwa moyo wako.</li>
   <li> Homoni zako za ujauzito hufanya kuta za mishipa yako ya safu, ambayo inafanya kuwa vigumu kwao kufanya kazi vizuri.</li></ul>
<p>Katika kila kesi, damu huelekea kwenye miguu yako, hukupa miguu ya kuvimba na mishipa ya varicose.</p>
<p><b>Unaweza kupata wapi mishipa ya varicose wapi?</b><br>
Mishipa ya varicose huendeleza sana miguu. Hata hivyo, unaweza pia kupata yao katika vulva (katika ufunguzi wa uke) au rectum. Mishipa ya vurugu ya rectum pia inajulikana kama haemorrhoids.
</p><p><b>Je, ni chungu na husababisha matatizo yoyote ya afya?</b><br>
Mishipa ya vurugu inaweza kusababisha chungu mbaya na maumivu katika miguu yako. Miguu yako inaweza kujisikia nzito au isiyopumzika, na inaweza kupiga, kuchoma au kuponda. Wanawake wengine hupata mishipa ya varicose kuwapa matatizo yoyote, lakini hiyo si ya kawaida.
</p><p>Pengine utapata kwamba dalili zozote unazozidi baadaye wakati wa siku tangu umesimama kwa muda mrefu. Kwa asubuhi iliyofuata, utakuwa huhisi vizuri kwa sababu umekuwa amelala chini na shinikizo la mishipa yako limepungua.</p>
<p><b>Je, chochote kinaweza kufanywa ili kuzuia?</b><br>
Kutembea au kuogelea husaidia mzunguko wako kwa ujumla na ni manufaa wakati wa mimba. Mazoezi maalum kama ndama yanafufua na kutembea papo hapo ni nzuri kwa kusaidia damu inapita kwenye miguu.
</p><p>Hakuna njia ya uhakika ya kuzuia mishipa ya varicose wakati unavyo mimba. Hata hivyo, wanaweza kuwa na uwezekano mdogo wa kuendeleza ikiwa:</p>
<ul style='color:#336699'><li>
    endelea kazi</li>
    <li>usiketi kwa muda mrefu sana</li>
   <li> kuacha kuvaa visigino vya juu, ikiwa sasa unavaa</li>
   <li> kuweka miguu yako juu, juu kuliko vidole vyako iwezekanavyo, wakati unapumzika au ukiwa</li>
   <li> Epuka kuvaa kitu chochote sana karibu na kiuno chako au pelvis</li></ul>
<p><b>Je, unaweza kujiondoa mishipa ya vurugu?</b><br>
Ikiwa unaendeleza mishipa ya vurugu, labda wataondoka bila matibabu wakati mtoto wako ana umri wa miezi 3 hadi 4. Lakini kwa wanawake wengine, hii inaweza kuchukua hadi mwaka.
</p><p>Wakati huo huo, unaweza kujaribu kuvaa soksi za compression, kuchukua dawa, kuwa na massage au kutumia reflexology. Chaguzi hizi zinaweza au zisizokusaidia tangu hakuna hata kuthibitishwa kuwa na ufanisi.
</p><p>Watu wengine wana upasuaji wa kuondoa mimba iliyoathiriwa, lakini ikiwa unafikiri juu ya hili, jaribu mpaka angalau mwaka mmoja baada ya kuzaliwa kwa mtoto wako ili kuona kama mishipa ya vurugu inakwenda bila matibabu.
</p>
</td></tr>"; 
	
}}
	

	
function ushaur(){
global $db;
	
$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);
 if (isset($_SESSION['user'])){
 $user=$_SESSION['user']['username'];
$sqlquery="SELECT* FROM pregnant_woman
INNER JOIN record_uchungu ON pregnant_woman.p_id=record_uchungu.p_id 
INNER JOIN other_inf ON pregnant_woman.p_id=other_inf.p_id   
INNER JOIN maelezo_uzazi ON pregnant_woman.p_id=maelezo_uzazi.p_id  WHERE username='$user'";

$sqlquer="SELECT* FROM pregnant_woman
INNER JOIN ushauri ON pregnant_woman.p_id=ushauri.p_id  WHERE username='$user'";

$sqlResult=mysql_query($sqlquery);
$sqlResul=mysql_query($sqlquer);

@$sqlRow=mysql_fetch_assoc($sqlResult);

echo'<table border="0" width="900px" align="center"><form method="post">';
echo"<tr><td width='100px'><input type='text' name='tatizo' spaceholder='kuhusu' required></td><td><input type='submit' name='search' value='Tafuta'></td></tr></form>";
echo"<tr ><td colspan='2'><h2 style='color:#336699'>Ushauri wa Nurse</h2></td></tr>";

/*if(date("Y-m-d")<$datekujifungu){
$curent=date_create(date("Y-m-d"));
$destination=date_create($datekujifungu);
$days=date_diff($curent,$destination);*/

$date_hedhi=$sqlRow['date_hedhi'];
$kujifungua_date=$sqlRow['kujifungua_date'];
$kujifunguadate=date_create($kujifungua_date);
$datekujifungu=$sqlRow['date_kujifungua'];
$curent=date_create(date("Y-m-d"));
$destination=date_create($date_hedhi);
$days=date_diff($curent,$destination);
$dayss=date_diff($curent,$kujifunguadate);

$day=$days->format("%a ");
$d=$dayss->format("%a ");

if($day>=280){
if($d>=0){
}else{
echo"<tr ><td colspan='2'><p>utakiwa uhudhurie kliniki kila wiki na ujiandae na kujifungua pamoja na maandalizi yote ya ujifungua</p></td></tr>";
}
}
if($day<=280){
if($sqlRow['Age']<20|| $sqlRow['miaka_mimba_mwisho']>=10
		||$sqlRow['njia_yakujifungua']=="ndio"||$sqlRow['mtoto_mfu']=="ndio"
		||$sqlRow['no_mimba_zilizohalibika']>=2||$sqlRow['moyo']="ndio"
		||$sqlRow['kisukari']=="ndio"||$sqlRow['kifua_kikuu']=="ndio"){
		echo"<tr ><td colspan='2'><p>Mama mjamzito unapaswa ufikishwe kituo cha afya au hospital kwa uchunguzi na ushauri</p></td></tr>";
}

if($sqlRow['mimba_no']>=5|| $sqlRow['Age']>=35
		||$sqlRow['kimo']<150||$sqlRow['njia_yakujifungua']=="ndio"
		||$sqlRow['kondo_kukwama']>="ndio"||$sqlRow['damu_nyingi']="ndio"
		||$sqlRow['kilema_nyonga']=="ndio"){
		echo"<tr ><td colspan='2'><p>Mama mjamzito unapaswa ukajifungulie katika kituo cha afya au hospital</p></td></tr>";
}

}

if($d>=0){
echo"<tr ><td colspan='2'><p>".$sqlRow['maoni']."</p></td></tr>";}
while(@$sqlRo=mysql_fetch_assoc($sqlResul))
{ 
echo "<tr>";
echo "<td colspan='2'><p>".$sqlRo['maon']."</p></td>";
echo"</tr>";
}echo"</table>";
}

}


	
	
function ushauri(){
global $db;

$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);
 if (isset($_SESSION['user'])){
$id=$_SESSION['user']['username'];
$ql="SELECT *FROM health_officer WHERE  username='$id'";
$result=mysql_query($ql);
@$row=mysql_fetch_assoc($result);



echo'<form name="ushauri" method="post">';
echo'<h2 align="center">Midwfe Counseling to Pregnant Woman</h2>';
echo'<table width="500px"  border="0" align="center" style=" background-color:#99CCFF; border-radius:7px;" >';
echo'<tr><td>Pregnant Woman Number</td><td ><input type="text" name="p_id" required></td></tr>';
echo"<tr><td>Name of Midwife</td><td ><input type='text' name='Dname' value='".$row['fname']." ".$row['lname']."'required></td></tr>";
echo'<tr><td>Counseling</td><td><textarea type="text" name="maoni" required></textarea></td></tr>';
echo'<tr><td><input type="reset" value="cancel"></td><td><input type="submit" value="submit" name="send"></td></tr></table></form>';

}



if(isset($_POST['send'])){
$p_id=$_POST['p_id'];
$d_name=$_POST['Dname'];
$maoni=$_POST['maoni'];

$sql="INSERT INTO ushauri(p_id,d_name,maon)

VALUES

('$p_id','$d_name','$maoni')";
$result=@mysql_query($sql);
if (!$result)
  {

  die('Error: ' . mysql_error());

  }
  else{
  
  echo"<table border='0' width='800px' align='center'><tr><td align='center'><p>ushauri umetumwa kikamilifu</p></td></tr>";}



}

}



function prind(){

  require('FPDF-master/fpdf.php');
    $fullname = "";
	$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);



	$sqlquery="SELECT * FROM pregnant_woman
INNER JOIN ushauri ON pregnant_woman.p_id=ushauri.p_id 
INNER JOIN record_uchungu ON pregnant_woman.p_id=record_uchungu.p_id 
INNER JOIN other_inf ON pregnant_woman.p_id=other_inf.p_id   
INNER JOIN maelezo_uzazi ON pregnant_woman.p_id=maelezo_uzazi.p_id   ";
$reslt=mysql_query($sqlquery);
$_REQUEST=mysql_fetch_assoc($reslt);

    $contractno = $_REQUEST['fname'];
   $sname = $_REQUEST['lname'];
  $fname = $_REQUEST['fname'];
   $age = $_REQUEST['Age'];
  $dob = $_REQUEST['lname'];
    $cpprefix = $_REQUEST['lname'];
     $cpnum = $_REQUEST['lname'];
     $eadd = $_REQUEST['lname'];
    
    class PDF extends FPDF
    {
            function Header()
            {
//$this->Image('lifehead.jpg',25,10,150);
                $this->SetFont('Times','B',12);
                $this->Cell(80);
                $this->Ln(20);
            }
    }
    $pdf=new PDF();
    $pdf->AliasNbPages();
    $pdf->AddPage();
    $pdf->SetFont('Times','B','12');  
    //for($i=1;$i<=40;$i++)
    //(x,y)
	$pdf->SetXY(50,10);
    $pdf->Cell(10,30,'Record ya Mahudhurio ya Mama Mjamzito Kabla ya Kujifungua');
	$pdf->SetFont('Times','','12');  
    $pdf->SetXY(30,10);
    $pdf->Cell(10,60,'Jina la Mama :'. '  ' .$fname. '  '.$sname);
    //$pdf->SetXY(69,10);
    //$pdf->Cell(10,73);
    $pdf->SetXY(30,10); //TO INDENT
    $pdf->Cell(10,80,'Umri :'.'  '  .$age);
    //$pdf->SetXY(136,10);
    //$pdf->Cell(10,73,                                            'Contract Date');
   
$pdf->SetXY(20,60);
$width_cell=array(50,30,30,30,30);
$pdf->SetFillColor(193,229,252); // Background color of header 
// Header starts /// 
$pdf->Cell($width_cell[0],7,'KUHUSU',1,0,'C',true); // First header column 
$pdf->Cell($width_cell[1],7,'HUDHURIO 1',1,0,'C',true); // Second header column
$pdf->Cell($width_cell[2],7,'HUDHURIO 2',1,0,'C',true); // Third header column 
$pdf->Cell($width_cell[3],7,'HUDHURIO 3',1,0,'C',true); // Fourth header column
$pdf->Cell($width_cell[4],7,'HUDHURIO 4',1,1,'C',true); // Fourth header column
 // Fourth header column
$pdf->SetXY(20,67);
// First row of data 
$pdf->Cell($width_cell[0],7,'Tarehe',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1 

 $pdf->SetXY(20,74);
// First row of data 
$pdf->Cell($width_cell[0],7,'Uzito',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,81);
// First row of data 
$pdf->Cell($width_cell[0],7,'Blood preassure',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,88);
// First row of data 
$pdf->Cell($width_cell[0],7,'albumin kwenye mkojo',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,95);
// First row of data 
$pdf->Cell($width_cell[0],7,'Damu/Hb (8.5Gram/dl)',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,102);
// First row of data 
$pdf->Cell($width_cell[0],7,'Sukari kwenye mkojo',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,109);
// First row of data 
$pdf->Cell($width_cell[0],7,'Umri wa mimba kwa wiki',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,116);
// First row of data 
$pdf->Cell($width_cell[0],7,'Kimo cha mimba kwa wiki',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,123);
// First row of data 
$pdf->Cell($width_cell[0],7,'Mlalo wa mtoto',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,130);
// First row of data 
$pdf->Cell($width_cell[0],7,'Kitangulizi',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,137);
// First row of data 
$pdf->Cell($width_cell[0],7,'Mtoto anacheza',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,144);
// First row of data 
$pdf->Cell($width_cell[0],7,'Mapigo ya moyo',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,151);
// First row of data 
$pdf->Cell($width_cell[0],7,'Kuvimba miguu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,158);
// First row of data 
$pdf->Cell($width_cell[0],7,'Pepopunda',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,165);
// First row of data 
$pdf->Cell($width_cell[0],7,'Dalili za hatari',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,172);
// First row of data 
$pdf->Cell($width_cell[0],7,'Uzazi wa mpango',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,179);
// First row of data 
$pdf->Cell($width_cell[0],7,'Magonjwa ya kujamiiana',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,186);
// First row of data 
$pdf->Cell($width_cell[0],7,'Lishe ya mtoto',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,193);
// First row of data 
$pdf->Cell($width_cell[0],7,'HIV',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,200);
// First row of data 
$pdf->Cell($width_cell[0],7,'Tarehe ya kurudi',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,207);
// First row of data 
$pdf->Cell($width_cell[0],7,'Jina la Muhudumu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,214);
// First row of data 
$pdf->Cell($width_cell[0],7,'Cheo',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,'75',1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,'75',1,1,'C',false); // Fourth column of row 1
    $pdf->Output();


}

