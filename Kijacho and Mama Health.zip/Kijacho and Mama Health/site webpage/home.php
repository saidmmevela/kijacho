<?php 
	
include('functions.php');

if (!isLoggedIn()) {
	header('location: login.php');
}


if (isset($_GET['logout'])) {
	session_destroy();
	unset($_SESSION['user']);
	header("location: ../kijacho/login.php");
}
?> 
<!DOCTYPE html>
<html>
<head>
<link Rel="stylesheet" Href="index.css" type="text/css">
<title>kijacho and mama health</title>
</head>
<body id="main">
<div id="hmcontainer">
<h1 align="center"style="color:#3399CC" >Kijacho and Mama Health</h1>
<div class="bar"><form method="post">
<ul class="ul">
<li class="ulli"><a href="home.php" >Home</a></li>
<li class="ulli"><a><input class="buttn" type="submit" value="Register" name="registere"></a></li>
<li class="ulli"><a><input class="buttn" type="submit" value="Registered" name="registered"></a></li>
<li class="ulli"><a>Record</a>
<ul ><li><input class="buttn" type="submit" value="Before derivery" name="bfdelivery"></li> 
	<li><input class="buttn" type="submit" value="After derivery" name="aftdelivery"></li>
	<li><input class="buttn" type="submit" value="To delivery" name="todelivery"></li>
	<li><input class="buttn" type="submit" value="For delivery" name="fordelivery"></li>
	<li><input class="buttn" type="submit" value="Labour pain Progress" name="progress"></li>
	<li><input class="buttn" type="submit" value="Counseling" name="ushauri"></li>
	<li><input class="buttn" type="submit" value="Timely Report" name="annual"></li></ul>

</li>
</li>
<li class="ulli"><a  href="login.php?logout='1'">Log out</a></li>
</ul></form>
</div>
<div id="hm">
<form method='POST'>

<?php

if (isset($_POST['registere'])){
pwregistration();
}


else if(isset($_POST['registered'])){
preinfo();
}

else if(isset($_POST['srch'])){
preinfo();
}


else if (isset($_POST['annual'])){
anualreport();
}

else if (isset($_POST['bfdelivery'])){
bfdelivery();
}



else if (isset($_POST['aftdelivery'])){
aftdelivery();
}

else if (isset($_POST['todelivery'])){
todelivery();
}

else if (isset($_POST['fordelivery'])){
fordelivery();
}

else if(isset($_POST['progress'])){
progress();
}


else if(isset($_POST['generate'])){
anualreport();
}


else if (isset($_POST['password'])){
password();
}
else if(isset($_POST['submit'])){
password();
}

else if (isset($_GET['mimba'])){
nyingine();
}

else if(isset($_POST['ushauri'])){
ushauri();
}

else if(isset($_POST['send'])){
ushauri();
}

else if(isset($_POST['pregister'])){
pregister();
}


else if(isset($_POST['bfregister']))
{bfregister();
}

else if(isset($_POST['aftregister'])){
aftregister();
}

else if(isset($_POST['toregister'])){
toregister();
}
else if(isset($_POST['forregister'])){
forregister();
}
else if(isset($_POST['progrss'])){
progrss();
}


else if (isset($_GET['nyingine'])){
mimba();
}


else if (isset($_GET['name'])){
report();
}

else if (isset($_GET['id'])){
enablep();
}
else if (isset($_GET['change'])){
changep();
}

else{
home();
}

?>

</form>
</div>
<div class="buttom">
<div class="footer">
<form method="post"><ul class="ful">
<li class="full"><a href="pwoman.php" >Home</a></li>
<li class="full"><a><input class="buttn" type="submit" value="Change Password" name="password"></a></li>
<li class="full"><a  href="login.php?logout='1'">log out</a></li></ul>


</form></div><div class="footer">
said_mmevela copyright &copy; 2018</div>
</div>
</div>
</body>
</html>