
         <?php
		 
include('functions.php');	
$id=$_GET['id'];

	
    require('FPDF-master/fpdf.php');
    $fullname = "";
	$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);



$sqlquery="SELECT* FROM pregnant_woman WHERE p_id=$id";
$reslt=mysql_query($sqlquery);
$_REQUEST=@mysql_fetch_assoc($reslt);

$sqlquery5="SELECT* FROM other_inf WHERE p_id=$id";
$reslt5=mysql_query($sqlquery5);
$_REQUEST5=@mysql_fetch_assoc($reslt5);

	$sqlquery1="SELECT * FROM maelezo_uzazi WHERE p_id=$id ";
$reslt1=mysql_query($sqlquery1);
$_REQUEST1=@mysql_fetch_assoc($reslt1);










    $contractno = $_REQUEST['fname'];
   $sname = $_REQUEST['lname'];
  $fname = $_REQUEST['fname'];
   $age = $_REQUEST5['Age'];
  $dob = $_REQUEST['lname'];
    $cpprefix = $_REQUEST['lname'];
     $cpnum = $_REQUEST['lname'];
     $eadd = $_REQUEST['lname'];
    
    class PDF extends FPDF
    {
            function Header()
            {
//$this->Image('lifehead.jpg',25,10,155);
                $this->SetFont('Times','B',12);
                $this->Cell(80);
                $this->Ln(55);
            }
    }
    $pdf=new PDF();
    $pdf->AliasNbPages();
    $pdf->AddPage();
    $pdf->SetFont('Times','B','12');  
    //for($i=1;$i<=55;$i++)
    //(x,y)
	$pdf->SetXY(70,10);
    $pdf->Cell(10,30,'Maelezo ya Uzazi ya Mama Mjamzito');
	$pdf->SetFont('Times','','12');  
    $pdf->SetXY(80,10);
    $pdf->Cell(10,55,'Jina la Mama :'. '  ' . $fname. '  '.$sname);
    //$pdf->SetXY(69,10);
    //$pdf->Cell(10,73);
    $pdf->SetXY(90,10); //TO INDENT
    $pdf->Cell(10,80,'Umri :'.'  '  .$age);
    //$pdf->SetXY(136,10);
    //$pdf->Cell(10,73,                                            'Contract Date');
   
$pdf->SetXY(55,53);
$width_cell=array(70,40);
$pdf->SetFillColor(193,229,252); // Background color of header 
// Header starts /// 
$pdf->Cell($width_cell[0],7,'KUHUSU',1,0,'C',true); // First header column 
$pdf->Cell($width_cell[1],7,'MAJIBU',1,1,'C',true); // Second header column

$pdf->SetXY(55,60);
// First row of data 
$pdf->Cell($width_cell[0],7,'Tarehe ya kujifungua',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kujifungua_date'],1,1,'C',false); // Second column of row 1 


 $pdf->SetXY(55,67);
// First row of data 
$pdf->Cell($width_cell[0],7,'Saa ya kujifungua',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['saa_kujifungua'],1,1,'C',false); // Second column of row 1 

$pdf->SetXY(55,74);
// First row of data 
$pdf->Cell($width_cell[0],7,'njia ya kujifungua',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['njia_yakujifungua'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,81);
// First row of data 
$pdf->Cell($width_cell[0],7,'sababu ya kupasuliwa',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['sababu_kupasuliwa'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,88);
// First row of data 
$pdf->Cell($width_cell[0],7,'Tarehe kondo limetoka',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kondo_limetoka_date'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,95);
// First row of data 
$pdf->Cell($width_cell[0],7,'Saa kondo limetoka',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['saa_kondokutoka'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,102);
// First row of data 
$pdf->Cell($width_cell[0],7,'kondo na membreni kutoka',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kondo_na_membreni_kutoka'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,109);
// First row of data 
$pdf->Cell($width_cell[0],7,'kiasi cha damu kilichotoka',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kiasi_damu'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,116);
// First row of data 
$pdf->Cell($width_cell[0],7,'ergometrine',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['ergometrine'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,123);
// First row of data 
$pdf->Cell($width_cell[0],7,'msamba kuchanika',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['msamba_kuchanika'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,130);
// First row of data 
$pdf->Cell($width_cell[0],7,'Jina la aliyeshona msamba',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['name_alieshona_msamba'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,137);
// First row of data 
$pdf->Cell($width_cell[0],7,'cheo cha aliyeshona msamba',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['cheo'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,144);
// First row of data 
$pdf->Cell($width_cell[0],7,'BP',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['BP'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,151);
// First row of data 
$pdf->Cell($width_cell[0],7,'hatua ya kwanza',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['hatua_ya_kwanza'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,158);
// First row of data 
$pdf->Cell($width_cell[0],7,'hatua ya pili',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['hatua_ya_pili'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,165);
// First row of data 
$pdf->Cell($width_cell[0],7,'hatua ya tatu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['hatua_ya_tatu'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,172);
// First row of data 
$pdf->Cell($width_cell[0],7,'Jina la mzalishaji',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['name_mzalishaji'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,179);
// First row of data 
$pdf->Cell($width_cell[0],7,'arv baada ya kujifungua',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['baada_ya_kujifungua_arv'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,186);
// First row of data 
$pdf->Cell($width_cell[0],7,'jinsia ya mtoto',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['mtoto_jinsia'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,193);
// First row of data 
$pdf->Cell($width_cell[0],7,'uzito wa mtoto',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['uzito_mtoto'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,200);
// First row of data 
$pdf->Cell($width_cell[0],7,'mtoto amepewa arv',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['mtoto_amepewa_arv'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,207);
// First row of data 
$pdf->Cell($width_cell[0],7,'lishe ya mtoto',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['lishe_ya_mtoto'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,214);
// First row of data 
$pdf->Cell($width_cell[0],7,'apgar score dakika 1',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['apgar1'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,221);
// First row of data 
$pdf->Cell($width_cell[0],7,'apgar score dakika 5',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['apgar5'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,228);
// First row of data 
$pdf->Cell($width_cell[0],7,'mengineyo',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['mengineyo'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,235);
// First row of data 
$pdf->Cell($width_cell[0],7,'kituo cha afya',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kituo'],1,0,'C',false); // Second column of row 1 

    $pdf->Output();
    ?>