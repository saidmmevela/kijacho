<?php
require_once("config.php");
require('fpdf.php');
$pdf = new FPDF();
$pdf->AddPage();
 
// code for print Heading of tables
$pdf->SetFont('Arial','B',12);
$ret ="SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='kijacho' AND `TABLE_NAME`='pregnant_woman' ";
$query1 = $dbh -> prepare($ret);
$query1->execute();
$header=$query1->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query1->rowCount() > 0)
{
foreach($header as $heading) {
foreach($heading as $column_heading)
$pdf->Cell(30,5,$column_heading,1);
}}
//code for print data
$sql = "SELECT fname,lname from  pregnant_woman ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->columnCount() > 0)
{
foreach($results as $row) {
$pdf->SetFont('Arial','',12);
$pdf->Ln();
foreach($row as $row)
$pdf->Cell(30,5,$row,1);


} }
$pdf->Output();
?>