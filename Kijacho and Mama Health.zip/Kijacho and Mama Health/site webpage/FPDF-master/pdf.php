<?php
require('fpdf.php'); 
class PDF extends FPDF {
 
function Header() {
    $this->SetFont('Times','',12);
    $this->SetY(0.25);
   // $this->Cell(0, .25, "Kijacho and Mama Health ".$this->PageNo(), 2, "C");
    //reset Y
    $this->SetY(1);
}
 
function Footer() {
//This is the footer; it's repeated on each page.
//enter filename: phpjabber logo, x position: (page width/2)-half the picture size,
//y position: rough estimate, width, height, filetype, link: click it!
  //$this->Cell(0,17,"kijacho".$this->PageNo());
}
 
}
 
//class instantiation
$pdf=new PDF("P","in","Letter");
 
$pdf->SetMargins(1,1,1);
 
$pdf->AddPage();
$pdf->SetFont('Times','B',12);
$pdf->Cell(0, .1, "Report ya Mama Mjamzito", 0, 0, "C");
$pdf->Cell(1, 2, "Report ya Mama Mjamzito", 0, 0,"l");



 
$lipsum1="Lorem ipsum dolor sit amet, nam aliquam dolore est, est in eget.";
  
$lipsum2="Nibh lectus, pede fusce ullamcorper vel porttitor.";
  
$lipsum3 ="Duis maecenas et curabitur, felis dolor.";
  
$pdf->SetFillColor(240, 100, 100);
$pdf->SetFont('Times','BU',12);
  

$pdf->AddPage();
$pdf->Write(0.5, $lipsum1.$lipsum2.$lipsum3);
  
$pdf->Output();
?>

/*
   $pdf->SetXY(40,10,'LR');
   // $pdf->Cell(10,95,'Contact number');
    $pdf->SetXY(42,10);
   // $pdf->Cell(10,110,'Application Number');
    //$pdf->SetXY(69,10);
    //$pdf->Cell(10,110);
    $pdf->SetXY(72,10); //TO INDENT 
  //  $pdf->Cell(10,110,'                                              Email Address', $eadd);
    //$pdf->SetXY(95,10); //TO INDENT 
    //$pdf->Cell(10,110,'                                              Contract Date');
    $pdf->SetXY(40,10);
    $pdf->Cell(10,177,'Conforme:');
    $pdf->SetXY(48,10);
    $pdf->Cell(10,195,'___________________');
    $pdf->SetXY(56,10);
    $pdf->Cell(10,202,'Planholder');
    $pdf->SetXY(58,10);
    $pdf->Cell(10,195,'                                              _______________');
    $pdf->SetXY(66,10);
    $pdf->Cell(10,202,'                                              Date');*/
