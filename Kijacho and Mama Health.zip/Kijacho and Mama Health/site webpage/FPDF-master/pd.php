
         <?php
		 
include('functions.php');	
 global  $pw;

	
    require('fpdf.php');
    $fullname = "";
	$sqlConnect=mysql_connect('localhost','root','badchata');
mysql_select_db('kijacho',$sqlConnect);



	$sqlquery="SELECT * FROM pregnant_woman
INNER JOIN other_inf ON pregnant_woman.p_id=other_inf.p_id WHERE p_id= $pw ";
$reslt=mysql_query($sqlquery);
$_REQUEST=@mysql_fetch_assoc($reslt);

	$sqlquery1="SELECT * FROM pregnant_woman
INNER JOIN visity_before_delivery ON pregnant_woman.p_id=visity_before_delivery.p_id  WHERE visiti_no=1";
$reslt1=mysql_query($sqlquery1);
$_REQUEST1=mysql_fetch_assoc($reslt1);

$sqlquery2="SELECT * FROM pregnant_woman
INNER JOIN visity_before_delivery ON pregnant_woman.p_id=visity_before_delivery.p_id  WHERE visiti_no=2";
$reslt2=mysql_query($sqlquery2);
$_REQUEST2=mysql_fetch_assoc($reslt2);

$sqlquery3="SELECT * FROM pregnant_woman
INNER JOIN visity_before_delivery ON pregnant_woman.p_id=visity_before_delivery.p_id  WHERE visiti_no=3";
$reslt3=mysql_query($sqlquery3);
$_REQUEST3=mysql_fetch_assoc($reslt3);

$sqlquery4="SELECT * FROM pregnant_woman
INNER JOIN visity_before_delivery ON pregnant_woman.p_id=visity_before_delivery.p_id  WHERE visiti_no=4";
$reslt4=mysql_query($sqlquery4);
$_REQUEST4=mysql_fetch_assoc($reslt4);









    $contractno = $_REQUEST['fname'];
   $sname = $_REQUEST['lname'];
  $fname = $_REQUEST['fname'];
   $age = $_REQUEST['Age'];
  $dob = $_REQUEST['lname'];
    $cpprefix = $_REQUEST['lname'];
     $cpnum = $_REQUEST['lname'];
     $eadd = $_REQUEST['lname'];
    
    class PDF extends FPDF
    {
            function Header()
            {
//$this->Image('lifehead.jpg',25,10,150);
                $this->SetFont('Times','B',12);
                $this->Cell(80);
                $this->Ln(20);
            }
    }
    $pdf=new PDF();
    $pdf->AliasNbPages();
    $pdf->AddPage();
    $pdf->SetFont('Times','B','12');  
    //for($i=1;$i<=40;$i++)
    //(x,y)
	$pdf->SetXY(50,10);
    $pdf->Cell(10,30,'Record ya Mahudhurio ya Mama Mjamzito Kabla ya Kujifungua');
	$pdf->SetFont('Times','','12');  
    $pdf->SetXY(30,10);
    $pdf->Cell(10,60,'Jina la Mama :'. '  ' . $pw. '  '.$sname);
    //$pdf->SetXY(69,10);
    //$pdf->Cell(10,73);
    $pdf->SetXY(30,10); //TO INDENT
    $pdf->Cell(10,80,'Umri :'.'  '  .$age);
    //$pdf->SetXY(136,10);
    //$pdf->Cell(10,73,                                            'Contract Date');
   
$pdf->SetXY(20,60);
$width_cell=array(50,30,30,30,30);
$pdf->SetFillColor(193,229,252); // Background color of header 
// Header starts /// 
$pdf->Cell($width_cell[0],7,'KUHUSU',1,0,'C',true); // First header column 
$pdf->Cell($width_cell[1],7,'HUDHURIO 1',1,0,'C',true); // Second header column
$pdf->Cell($width_cell[2],7,'HUDHURIO 2',1,0,'C',true); // Third header column 
$pdf->Cell($width_cell[3],7,'HUDHURIO 3',1,0,'C',true); // Fourth header column
$pdf->Cell($width_cell[4],7,'HUDHURIO 4',1,1,'C',true); // Fourth header column
 // Fourth header column
$pdf->SetXY(20,67);
// First row of data 
$pdf->Cell($width_cell[0],7,'Tarehe',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['visit_date'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['visit_date'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['visit_date'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['visit_date'],1,1,'C',false); // Fourth column of row 1 

 $pdf->SetXY(20,74);
// First row of data 
$pdf->Cell($width_cell[0],7,'Uzito',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['weight'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['weight'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['weight'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['weight'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,81);
// First row of data 
$pdf->Cell($width_cell[0],7,'Blood preassure',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['blood_preassure'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['blood_preassure'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['blood_preassure'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['blood_preassure'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,88);
// First row of data 
$pdf->Cell($width_cell[0],7,'albumin kwenye mkojo',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['albumin'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['albumin'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['albumin'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['albumin'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,95);
// First row of data 
$pdf->Cell($width_cell[0],7,'Damu/Hb (8.5Gram/dl)',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['damu'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['damu'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['damu'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['damu'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,102);
// First row of data 
$pdf->Cell($width_cell[0],7,'Sukari kwenye mkojo',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['sukari_mkojo'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['sukari_mkojo'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['sukari_mkojo'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['sukari_mkojo'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,109);
// First row of data 
$pdf->Cell($width_cell[0],7,'Umri wa mimba kwa wiki',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['umri_mimba'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['umri_mimba'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['umri_mimba'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['umri_mimba'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,116);
// First row of data 
$pdf->Cell($width_cell[0],7,'Kimo cha mimba kwa wiki',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kimo_mimba'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['kimo_mimba'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['kimo_mimba'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['kimo_mimba'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,123);
// First row of data 
$pdf->Cell($width_cell[0],7,'Mlalo wa mtoto',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['mlalo_mtoto'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['mlalo_mtoto'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['mlalo_mtoto'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['mlalo_mtoto'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,130);
// First row of data 
$pdf->Cell($width_cell[0],7,'Kitangulizi',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kitangulizi'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['kitangulizi'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['kitangulizi'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['kitangulizi'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,137);
// First row of data 
$pdf->Cell($width_cell[0],7,'Mtoto anacheza',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['mtoto_kucheza'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['mtoto_kucheza'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['mtoto_kucheza'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['mtoto_kucheza'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,144);
// First row of data 
$pdf->Cell($width_cell[0],7,'Mapigo ya moyo',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['mapigo_moyo_mtoto'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['mapigo_moyo_mtoto'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['mapigo_moyo_mtoto'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['mapigo_moyo_mtoto'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,151);
// First row of data 
$pdf->Cell($width_cell[0],7,'Kuvimba miguu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kuvimba_miguu'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['kuvimba_miguu'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['kuvimba_miguu'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['kuvimba_miguu'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,158);
// First row of data 
$pdf->Cell($width_cell[0],7,'Pepopunda',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['pepopunda'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['pepopunda'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['pepopunda'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['pepopunda'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,165);
// First row of data 
$pdf->Cell($width_cell[0],7,'Dalili za hatari',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['dalili_za_hatari'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['dalili_za_hatari'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['dalili_za_hatari'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['dalili_za_hatari'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,172);
// First row of data 
$pdf->Cell($width_cell[0],7,'Uzazi wa mpango',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['uzazi_wa_mpango'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['uzazi_wa_mpango'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['uzazi_wa_mpango'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['uzazi_wa_mpango'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,179);
// First row of data 
$pdf->Cell($width_cell[0],7,'Magonjwa ya kujamiiana',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['magonjwa_ya_kujamiiana'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['magonjwa_ya_kujamiiana'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['magonjwa_ya_kujamiiana'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['magonjwa_ya_kujamiiana'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,186);
// First row of data 
$pdf->Cell($width_cell[0],7,'Lishe ya mtoto',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['lishe_mtoto'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['lishe_mtoto'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['lishe_mtoto'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['lishe_mtoto'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,193);
// First row of data 
$pdf->Cell($width_cell[0],7,'HIV',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['hiv'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['hiv'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['hiv'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['hiv'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,200);
// First row of data 
$pdf->Cell($width_cell[0],7,'Tarehe ya kurudi',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['return_date'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['return_date'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['return_date'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['return_date'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,207);
// First row of data 
$pdf->Cell($width_cell[0],7,'Jina la Muhudumu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['officer_name'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['officer_name'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['officer_name'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['officer_name'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,214);
// First row of data 
$pdf->Cell($width_cell[0],7,'Cheo',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['cheo_muhudumu'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['cheo_muhudumu'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['cheo_muhudumu'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['cheo_muhudumu'],1,1,'C',false); // Fourth column of row 1
    $pdf->Output();
    ?>