
         <?php
		 
include('functions.php');	
$id=$_GET['id'];

	
    require('FPDF-master/fpdf.php');
    $fullname = "";
	$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);



$sqlquery="SELECT* FROM pregnant_woman WHERE p_id=$id";
$reslt=mysql_query($sqlquery);
$_REQUEST=@mysql_fetch_assoc($reslt);

$sqlquery5="SELECT* FROM other_inf WHERE p_id=$id";
$reslt5=mysql_query($sqlquery5);
$_REQUEST5=@mysql_fetch_assoc($reslt5);

	$sqlquery1="SELECT * FROM visit_after_delivery  WHERE visit_no=1 AND p_id=$id";
$reslt1=mysql_query($sqlquery1);
$_REQUEST1=@mysql_fetch_assoc($reslt1);

$sqlquery2="SELECT * FROM visit_after_delivery   WHERE visit_no=2 AND p_id=$id";
$reslt2=mysql_query($sqlquery2);
$_REQUEST2=@mysql_fetch_assoc($reslt2);

$sqlquery3="SELECT * FROM visit_after_delivery  WHERE visit_no=3 AND p_id=$id";
$reslt3=mysql_query($sqlquery3);
$_REQUEST3=@mysql_fetch_assoc($reslt3);

$sqlquery4="SELECT * FROM visit_after_delivery  WHERE visit_no=4 AND p_id=$id";
$reslt4=mysql_query($sqlquery4);
$_REQUEST4=@mysql_fetch_assoc($reslt4);









    $contractno = $_REQUEST['fname'];
   $sname = $_REQUEST['lname'];
  $fname = $_REQUEST['fname'];
   $age = $_REQUEST5['Age'];
  $dob = $_REQUEST['lname'];
    $cpprefix = $_REQUEST['lname'];
     $cpnum = $_REQUEST['lname'];
     $eadd = $_REQUEST['lname'];
    
    class PDF extends FPDF
    {
            function Header()
            {
//$this->Image('lifehead.jpg',25,10,150);
                $this->SetFont('Times','B',12);
                $this->Cell(80);
                $this->Ln(20);
            }
    }
    $pdf=new PDF();
    $pdf->AliasNbPages();
    $pdf->AddPage();
    $pdf->SetFont('Times','B','12');  
    //for($i=1;$i<=40;$i++)
    //(x,y)
	$pdf->SetXY(50,10);
    $pdf->Cell(10,30,'Record ya Mahudhurio ya Mama Mjamzito Baada ya Kujifungua');
	$pdf->SetFont('Times','','12');  
    $pdf->SetXY(30,10);
    $pdf->Cell(10,60,'Jina la Mama :'. '  ' . $fname. '  '.$sname);
    //$pdf->SetXY(69,10);
    //$pdf->Cell(10,73);
    $pdf->SetXY(30,10); //TO INDENT
    $pdf->Cell(10,80,'Umri :'.'  '  .$age);
    //$pdf->SetXY(136,10);
    //$pdf->Cell(10,73,                                            'Contract Date');
   
$pdf->SetXY(20,60);
$width_cell=array(50,30,30,30,30);
$pdf->SetFillColor(193,229,252); // Background color of header 
// Header starts /// 
$pdf->Cell($width_cell[0],7,'KUHUSU',1,0,'C',true); // First header column 
$pdf->Cell($width_cell[1],7,'HUDHURIO 1',1,0,'C',true); // Second header column
$pdf->Cell($width_cell[2],7,'HUDHURIO 2',1,0,'C',true); // Third header column 
$pdf->Cell($width_cell[3],7,'HUDHURIO 3',1,0,'C',true); // Fourth header column
$pdf->Cell($width_cell[4],7,'HUDHURIO 4',1,1,'C',true); // Fourth header column
 // Fourth header column
$pdf->SetXY(20,67);
// First row of data 
$pdf->Cell($width_cell[0],7,'Tarehe',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['visit_date'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['visit_date'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['visit_date'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['visit_date'],1,1,'C',false); // Fourth column of row 1 

 $pdf->SetXY(20,74);
// First row of data 
$pdf->Cell($width_cell[0],7,'Joto la mwili',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['joto_mwili'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['joto_mwili'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['joto_mwili'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['joto_mwili'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,81);
// First row of data 
$pdf->Cell($width_cell[0],7,'Blood preassure',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['blood_preassure'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['blood_preassure'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['blood_preassure'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['blood_preassure'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,88);
// First row of data 
$pdf->Cell($width_cell[0],7,'Damu/Hb (8.5Gram/dl)',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['hb'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['hb'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['hb'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['hb'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,95);
// First row of data 
$pdf->Cell($width_cell[0],7,'mtoto ananyonya',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['mtoto_ananyonya'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['mtoto_ananyonya'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['mtoto_ananyonya'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['mtoto_ananyonya'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,102);
// First row of data 
$pdf->Cell($width_cell[0],7,'maziwa yanatoka',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['maziwa_yanatoka'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['maziwa_yanatoka'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['maziwa_yanatoka'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['maziwa_yanatoka'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,109);
// First row of data 
$pdf->Cell($width_cell[0],7,'mtoto kunyonya ndani saa1',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['mtoto_kunyonya_ndani_saa1'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['mtoto_kunyonya_ndani_saa1'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['mtoto_kunyonya_ndani_saa1'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['mtoto_kunyonya_ndani_saa1'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,116);
// First row of data 
$pdf->Cell($width_cell[0],7,'chuchu zina vidonda',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['chuchu_vidonda'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['chuchu_vidonda'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['chuchu_vidonda'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['chuchu_vidonda'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,123);
// First row of data 
$pdf->Cell($width_cell[0],7,'matiti yamejaa',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['matiti_yamejaa'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['matiti_yamejaa'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['matiti_yamejaa'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['matiti_yamejaa'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,130);
// First row of data 
$pdf->Cell($width_cell[0],7,'matiti yana majipu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['matiti_majipu'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['matiti_majipu'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['matiti_majipu'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['matiti_majipu'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,137);
// First row of data 
$pdf->Cell($width_cell[0],7,'tumbo la uzazi linanyea',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['tumbo_uzazi_linanyea'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['tumbo_uzazi_linanyea'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['tumbo_uzazi_linanyea'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['tumbo_uzazi_linanyea'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,144);
// First row of data 
$pdf->Cell($width_cell[0],7,'tumbo lina maumivu makali',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['tumbo_maumivu_makali'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['tumbo_maumivu_makali'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['tumbo_maumivu_makali'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['tumbo_maumivu_makali'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,151);
// First row of data 
$pdf->Cell($width_cell[0],7,'msamba kuchanika',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['msamba_kuchanika'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['msamba_kuchanika'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['msamba_kuchanika'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['msamba_kuchanika'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,158);
// First row of data 
$pdf->Cell($width_cell[0],7,'msamba alichanika',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['msamba_alichanika'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['msamba_alichanika'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['msamba_alichanika'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['msamba_alichanika'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,165);
// First row of data 
$pdf->Cell($width_cell[0],7,'aliongezewa njia',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['aliongezewa_njia'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['aliongezewa_njia'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['aliongezewa_njia'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['aliongezewa_njia'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,172);
// First row of data 
$pdf->Cell($width_cell[0],7,'kidonda kimepona',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kidonda_kimepona'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['kidonda_kimepona'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['kidonda_kimepona'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['kidonda_kimepona'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,179);
// First row of data 
$pdf->Cell($width_cell[0],7,'kidonda kinausaa',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kidonda_kinausaa'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['kidonda_kinausaa'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['kidonda_kinausaa'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['kidonda_kinausaa'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,186);
// First row of data 
$pdf->Cell($width_cell[0],7,'kidonda kimeachia',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kidonda_kimeachia'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['kidonda_kimeachia'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['kidonda_kimeachia'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['kidonda_kimeachia'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,193);
// First row of data 
$pdf->Cell($width_cell[0],7,'lokia inanuka',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['lokia_inanuka'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['lokia_inanuka'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['lokia_inanuka'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['lokia_inanuka'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,200);
// First row of data 
$pdf->Cell($width_cell[0],7,'kiasi cha lokia',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['lokia'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['lokia'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['lokia'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['lokia'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,207);
// First row of data 
$pdf->Cell($width_cell[0],7,'lokia rangi ngapi',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['lokia_rangi_ngapi'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['lokia_rangi_ngapi'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['lokia_rangi_ngapi'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['lokia_rangi_ngapi'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,214);
// First row of data 
$pdf->Cell($width_cell[0],7,'hali ya akili',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['hali_ya_akili'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['hali_ya_akili'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['hali_ya_akili'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['hali_ya_akili'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,221);
// First row of data 
$pdf->Cell($width_cell[0],7,'ushauri uzazi wampango',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['ushauri_uzazi_wampango'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['ushauri_uzazi_wampango'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['ushauri_uzazi_wampango'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['ushauri_uzazi_wampango'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,228);
// First row of data 
$pdf->Cell($width_cell[0],7,'tiba nyingine',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['tiba_nyingine'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['tiba_nyingine'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['tiba_nyingine'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['tiba_nyingine'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,235);
// First row of data 
$pdf->Cell($width_cell[0],7,'saa ya kujifungua',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['saa_kujifungua'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['saa_kujifungua'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['saa_kujifungua'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['saa_kujifungua'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,242);
// First row of data 
$pdf->Cell($width_cell[0],7,'saa ya kondokutoka',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['saa_kondokutoka'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['saa_kondokutoka'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['saa_kondokutoka'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['saa_kondokutoka'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,249);
// First row of data 
$pdf->Cell($width_cell[0],7,'lishe ya mtoto',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['lishe'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['lishe'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['lishe'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['lishe'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,256);
// First row of data 
$pdf->Cell($width_cell[0],7,'vitamin_a',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['vitamin_a'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['vitamin_a'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['vitamin_a'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['vitamin_a'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,263);
// First row of data 
$pdf->Cell($width_cell[0],7,'folic',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['folic'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['folic'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['folic'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['folic'],1,1,'C',false); // Fourth column of row 1

$pdf->AddPage();
$pdf->SetXY(20,30);
// First row of data 
$pdf->Cell($width_cell[0],7,'furrous',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['furrous'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['furrous'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['furrous'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['furrous'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,37);
// First row of data 
$pdf->Cell($width_cell[0],7,'ctx',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['ctx'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['ctx'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['ctx'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['ctx'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,44);
// First row of data 
$pdf->Cell($width_cell[0],7,'pepopunda',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['pepopunda'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['pepopunda'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['pepopunda'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['pepopunda'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,51);
// First row of data 
$pdf->Cell($width_cell[0],7,'Tarehe ya kurudi',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['return_date'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['return_date'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['return_date'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['return_date'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,58);
// First row of data 
$pdf->Cell($width_cell[0],7,'Jina la mhudumu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['officer_name'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['officer_name'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['officer_name'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['officer_name'],1,1,'C',false); // Fourth column of row 1
$pdf->SetXY(20,65);
// First row of data 
$pdf->Cell($width_cell[0],7,'cheo cha mhudumu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['cheo'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['cheo'],1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['cheo'],1,0,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['cheo'],1,1,'C',false); // Fourth column of row 1




    $pdf->Output();
    ?>