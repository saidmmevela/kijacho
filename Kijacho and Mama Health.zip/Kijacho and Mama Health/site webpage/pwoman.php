<?php 
	
include('functions.php');
//include('FPDF-master/pd.php');


if (!isLoggedIn()) {
	$_SESSION['msg'] = "You must log in first";
	header('location: login.php');
}

if (isset($_GET['logout'])) {
	session_destroy();
	unset($_SESSION['user']);
	header("location: ../kijacho/login.php");
}
?>  
<!DOCTYPE html>      
<html>
<head>
<link Rel="stylesheet" Href="index.css" type="text/css">

<title>kijacho and mama health</title>
</head>
<body id="main">
<div id="phm">  
<?php 
 mtazamo();
?>
<?php //echo'<p align="right" style="margin:0; padding: 0;">tarehe ya kurudi clinic date(y-m-d)</p>';?>
<h1 align="center" style="color:#3399CC">Kijacho and Mama Health</h1>
<div class="bar"><form method="post">
<ul class="ul" >
<li class="ullii" ><a href="pwoman.php" >Home</a></li>
<li class="ullii"><a><input class="buttn" type="submit" value="Counseling" name="counseling"></a></li>
<li class="ullii"><a><input class="buttn" type="submit" value="Record" name="record"></a></li>
<li class="ullii"><a  href="login.php?logout='1'">Log out</a></li>
</ul></form>
</div>
<div id="hm">
<form method='POST'>

<?php
if (isset($_POST['registere'])){
pwregistration();
}

else if(isset($_POST['record'])){
pwnr();
}

else if(isset($_POST['to'])){
pwnr();
}
else if(isset($_POST['asubuhi'])){
asubuhi();
}

else if(isset($_POST['backhead'])){
backhead();
}
else if(isset($_POST['kibofu'])){
kibofu();
}
else if(isset($_POST['ngozi'])){
ngozi();
}
else if(isset($_POST['uchovu'])){
uchovu();
}
else if(isset($_POST['kichwa'])){
kichwa();
}

else if(isset($_POST['print'])){

}


else if(isset($_POST['ganzi'])){
ganzi();
}

else if(isset($_POST['kuvimba'])){
kuvimba();
}

else if(isset($_POST['magonjwa'])){
magonjwa();
}

else if(isset($_POST['mishipa'])){
mishipa();
}

else if(isset($_POST['ushauri'])){
ushaur();
}

else if(isset($_POST['for'])){
pwnr();
}
else if(isset($_POST['graph'])){
pwnr();
}
else if(isset($_POST['after'])){
pwnr();
}
else if(isset($_POST['before'])){
pwnr();
}

else if (isset($_GET['id'])){
report();
}

else if (isset($_POST['counseling'])){
counseling();
}

else if (isset($_POST['password'])){
password();
}
else if(isset($_POST['submit'])){
password();
}

else if (isset($_POST['search'])){
search();
}

else{
phome();
}

?>

</div>
<div class="buttom">
<div class="footer">
<form method="post"><ul class="ful">
<li class="full"><a href="pwoman.php" >Home</a></li>
<li class="full"><a><input class="buttn" type="submit" value="Change Password" name="password"></a></li>
<li class="full"><a  href="login.php?logout='1'">log out</a></li></ul>


</form></div><div class="footer">
said_mmevela copyright &copy; 2018</div>
</div>
</div>
</body>
</html>