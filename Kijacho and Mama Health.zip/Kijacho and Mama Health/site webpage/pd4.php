
         <?php
		 
include('functions.php');	
$id=$_GET['id'];

	
    require('FPDF-master/fpdf.php');
    $fullname = "";
	$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);



$sqlquery="SELECT* FROM pregnant_woman WHERE p_id=$id";
$reslt=mysql_query($sqlquery);
$_REQUEST=@mysql_fetch_assoc($reslt);

$sqlquery5="SELECT* FROM other_inf WHERE p_id=$id";
$reslt5=mysql_query($sqlquery5);
$_REQUEST5=@mysql_fetch_assoc($reslt5);

	$sqlquery1="SELECT * FROM muendelezo_uchungu WHERE p_id=$id AND checkk=1";
$reslt1=mysql_query($sqlquery1);
$_REQUEST1=@mysql_fetch_assoc($reslt1);

$sqlquery2="SELECT * FROM muendelezo_uchungu WHERE p_id=$id AND checkk=2";
$reslt2=mysql_query($sqlquery2);
$_REQUEST2=@mysql_fetch_assoc($reslt2);
$sqlquery3="SELECT * FROM muendelezo_uchungu WHERE p_id=$id AND checkk=3";
$reslt3=mysql_query($sqlquery3);
$_REQUEST3=@mysql_fetch_assoc($reslt3);
$sqlquery4="SELECT * FROM muendelezo_uchungu WHERE p_id=$id AND checkk=4";
$reslt4=mysql_query($sqlquery4);
$_REQUEST4=@mysql_fetch_assoc($reslt4);


$sqlquery5="SELECT * FROM muendelezo_uchungu WHERE p_id=$id AND checkk=5";
$reslt5=mysql_query($sqlquery5);
$_REQUEST5=@mysql_fetch_assoc($reslt5);






    $contractno = $_REQUEST['fname'];
   $sname = $_REQUEST['lname'];
  $fname = $_REQUEST['fname'];
   $age = $_REQUEST5['Age'];
  $dob = $_REQUEST['lname'];
    $cpprefix = $_REQUEST['lname'];
     $cpnum = $_REQUEST['lname'];
     $eadd = $_REQUEST['lname'];
    
    class PDF extends FPDF
    {
            function Header()
            {
//$this->Image('lifehead.jpg',25,10,130);
                $this->SetFont('Times','B',12);
                $this->Cell(80);
                $this->Ln(30);
            }
    }
    $pdf=new PDF();
    $pdf->AliasNbPages();
    $pdf->AddPage();
    $pdf->SetFont('Times','B','12');  
    //for($i=1;$i<=30;$i++)
    //(x,y)
	$pdf->SetXY(70,10);
    $pdf->Cell(10,30,'Trend ya uchungu ya Mama Mjamzito');
	$pdf->SetFont('Times','','12');  
    $pdf->SetXY(80,10);
    $pdf->Cell(10,55,'Jina la Mama :'. '  ' . $fname. '  '.$sname);
    //$pdf->SetXY(69,10);
    //$pdf->Cell(10,73);
    $pdf->SetXY(90,10); //TO INDENT
    $pdf->Cell(10,80,'Umri :'.'  '  .$age);
    //$pdf->SetXY(136,10);
    //$pdf->Cell(10,73,                                            'Contract Date');
   
$pdf->SetXY(30,53);
$width_cell=array(70,20,20,20,20,20);
$pdf->SetFillColor(193,229,252); // Background color of header 
// Header starts /// 
$pdf->Cell($width_cell[0],7,'KUHUSU',1,0,'C',true); // First header column 
$pdf->Cell($width_cell[1],7,'MAJIBU',1,0,'C',true); // Second header column
$pdf->Cell($width_cell[2],7,'MAJIBU',1,0,'C',true); // Second header column
$pdf->Cell($width_cell[3],7,'MAJIBU',1,0,'C',true); // Second header column
$pdf->Cell($width_cell[4],7,'MAJIBU',1,0,'C',true); // Second header column
$pdf->Cell($width_cell[5],7,'MAJIBU',1,0,'C',true); // Second header column


$pdf->SetXY(30,60);
// First row of data 
$pdf->Cell($width_cell[0],7,'Tarehe ',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['tarehe'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['tarehe'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['tarehe'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['tarehe'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[5],7,''. $_REQUEST5['tarehe'],1,1,'C',false); // Second column of row 1 


 $pdf->SetXY(30,67);
// First row of data 
$pdf->Cell($width_cell[0],7,'Saa',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['time'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['time'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['time'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['time'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[5],7,''. $_REQUEST5['time'],1,1,'C',false); // Second column of row 1 

$pdf->SetXY(30,74);
// First row of data 
$pdf->Cell($width_cell[0],7,'mapigo ya moyo ya mtoto',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['mapigo_moyo_mtoto'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['mapigo_moyo_mtoto'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['mapigo_moyo_mtoto'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['mapigo_moyo_mtoto'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[5],7,''. $_REQUEST5['mapigo_moyo_mtoto'],1,1,'C',false); // Second column of row 1 

$pdf->SetXY(30,81);
// First row of data 
$pdf->Cell($width_cell[0],7,'maji ya chupa',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['maji_chupa'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['maji_chupa'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['maji_chupa'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['maji_chupa'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[5],7,''. $_REQUEST5['maji_chupa'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(30,88);
// First row of data 
$pdf->Cell($width_cell[0],7,'kubonywa kichwa',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kubonywa_kichwa'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['kubonywa_kichwa'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['kubonywa_kichwa'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['kubonywa_kichwa'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[5],7,''. $_REQUEST5['kubonywa_kichwa'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(30,95);
// First row of data 
$pdf->Cell($width_cell[0],7,'ukubwa wa cervix',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['cervix'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['cervix'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['cervix'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['cervix'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[5],7,''. $_REQUEST5['cervix'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(30,102);
// First row of data 
$pdf->Cell($width_cell[0],7,'kichwa kutelemka',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kichwa_kutelemka'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['kichwa_kutelemka'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['kichwa_kutelemka'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['kichwa_kutelemka'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[5],7,''. $_REQUEST5['kichwa_kutelemka'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(30,109);
// First row of data 
$pdf->Cell($width_cell[0],7,'maumivu ya uchungu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['maumivu_uchungu'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['maumivu_uchungu'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['maumivu_uchungu'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['maumivu_uchungu'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[5],7,''. $_REQUEST5['maumivu_uchungu'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(30,116);
// First row of data 
$pdf->Cell($width_cell[0],7,'dawa aliyopewa',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['dawa'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['dawa'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['dawa'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['dawa'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[5],7,''. $_REQUEST5['dawa'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(30,123);
// First row of data 
$pdf->Cell($width_cell[0],7,'mapigo ya moyo ya mama',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['mapigo_moyo_mama'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['mapigo_moyo_mama'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['mapigo_moyo_mama'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['mapigo_moyo_mama'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[5],7,''. $_REQUEST5['mapigo_moyo_mama'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(30,130);
// First row of data 
$pdf->Cell($width_cell[0],7,'bLood pressure',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['bLood_pressure'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['bLood_pressure'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['bLood_pressure'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['bLood_pressure'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[5],7,''. $_REQUEST5['bLood_pressure'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(30,137);
// First row of data 
$pdf->Cell($width_cell[0],7,'albumin kwenye mkojo',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['albumin'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['albumin'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['albumin'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['albumin'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[5],7,''. $_REQUEST5['albumin'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(30,144);
// First row of data 
$pdf->Cell($width_cell[0],7,'sukari kwenye mkojo',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['sukari'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['sukari'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['sukari'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['sukari'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[5],7,''. $_REQUEST5['sukari'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(30,151);
// First row of data 
$pdf->Cell($width_cell[0],7,'acetone kwenye mkojo',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['acetone'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['acetone'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['acetone'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['acetone'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['acetone'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(30,158);
// First row of data 
$pdf->Cell($width_cell[0],7,'joto mwili',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['joto_mwili'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],7,''. $_REQUEST2['joto_mwili'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[3],7,''. $_REQUEST3['joto_mwili'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[4],7,''. $_REQUEST4['joto_mwili'],1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[5],7,''. $_REQUEST5['joto_mwili'],1,0,'C',false); // Second column of row 1 

    $pdf->Output();
    ?>