<?php
include('functions.php');


?>
<!DOCTYPE html>
<html>
<head>
<link Rel="stylesheet" Href="index.css" type="text/css">
<title>kijacho and mama health</title>
</head>
<body id="main">
<div id="admcontainer">
<h1 align="center" style="color:#3399CC">Kijacho and Mama Health</h1>
<div class="bar">
<div class="hmbar"><form method="post">
<ul class="ul">
<li class="hmaulli"><a href="index.php">Home</a></li>
<li class="hmaulli"><a href="index.php">About us</a></li>
<li class="hmaulli"><a href="login.php">log in</a></li>
</ul></form>
</div></div>
<div class="container">
<h2 align="center" class="txtlg">Login Form</h2>

<form  name="loginform"  method="post">
<table witdh="70px" border="0"  align="center">
	<tr><td style="padding:10px">
	<input name="username" class="usericn" type="text" placeholder="user name" size="35" align="center" style="border-radius:6px;" required></td></tr>
	<tr><td style="padding:10px"><input name="password" class="passcod"type="password" placeholder="password" size="35" style="border-radius:6px;" required></td></tr>
	<tr><td style="padding:10px" align="center"><button  name="login" type="submit" style="border-radius:6px;">log in</button>
	<button  name="cancel" type="reset" style="border-radius:6px;">cancel</button>
	</td></tr>
	</table>
</form>
</div><?php echo display_error(); ?>
<div class="buttom">
<div class="hmfooter">
<form method="post"><ul class="ful">
<li class="hmfull"><a href="index.php" >Home</a></li>
<li class="hmfull"><a  href="login.php">log in</a></li></ul>

</form></div><div class="footer">
said_mmevela copyright &copy; 2018</div>
</div>
</div>
</body>
</html>