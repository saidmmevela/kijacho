
         <?php
		 
include('functions.php');	
$id=$_GET['id'];

	
    require('FPDF-master/fpdf.php');
    $fullname = "";
	$sqlConnect=mysql_connect('localhost','root','');
mysql_select_db('kijacho',$sqlConnect);



$sqlquery="SELECT* FROM pregnant_woman WHERE p_id=$id";
$reslt=mysql_query($sqlquery);
$_REQUEST=@mysql_fetch_assoc($reslt);

$sqlquery5="SELECT* FROM other_inf WHERE p_id=$id";
$reslt5=mysql_query($sqlquery5);
$_REQUEST5=@mysql_fetch_assoc($reslt5);

$sqlquery2="SELECT* FROM partner WHERE p_id=$id";
$reslt2=mysql_query($sqlquery2);
$_REQUEST2=@mysql_fetch_assoc($reslt2);

	$sqlquery1="SELECT * FROM other_inf WHERE p_id=$id ";
$reslt1=mysql_query($sqlquery1);
$_REQUEST1=@mysql_fetch_assoc($reslt1);










    $contractno = $_REQUEST['fname'];
   $sname = $_REQUEST['lname'];
  $fname = $_REQUEST['fname'];
   $age = $_REQUEST5['Age'];
  $dob = $_REQUEST['lname'];
    $cpprefix = $_REQUEST['lname'];
     $cpnum = $_REQUEST['lname'];
     $eadd = $_REQUEST['lname'];
    
    class PDF extends FPDF
    {
            function Header()
            {
//$this->Image('lifehead.jpg',25,10,155);
                $this->SetFont('Times','B',12);
                $this->Cell(80);
                $this->Ln(55);
            }
    }
    $pdf=new PDF();
    $pdf->AliasNbPages();
    $pdf->AddPage();
    $pdf->SetFont('Times','B','12');  
    //for($i=1;$i<=55;$i++)
    //(x,y)
	$pdf->SetXY(75,10);
    $pdf->Cell(10,30,'Taarifa Nyingine za Mama Mjamzito');
	$pdf->SetFont('Times','','12');  
    $pdf->SetXY(80,10);
    $pdf->Cell(10,55,'Jina la Mama :'. '  ' . $fname. '  '.$sname);
    //$pdf->SetXY(69,10);
    //$pdf->Cell(10,73);
    $pdf->SetXY(90,10); //TO INDENT
    $pdf->Cell(10,80,'Umri :'.'  '  .$age);
    //$pdf->SetXY(136,10);
    //$pdf->Cell(10,73,                                            'Contract Date');
   
$pdf->SetXY(55,53);
$width_cell=array(70,40);
$pdf->SetFillColor(193,229,252); // Background color of header 
// Header starts /// 
$pdf->Cell($width_cell[0],7,'KUHUSU',1,0,'C',true); // First header column 
$pdf->Cell($width_cell[1],7,'MAJIBU',1,1,'C',true); // Second header column

$pdf->SetXY(55,60);
// First row of data 
$pdf->Cell($width_cell[0],7,'Umri wa Mjamzito',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['Age'],1,1,'C',false); // Second column of row 1 


 $pdf->SetXY(55,67);
// First row of data 
$pdf->Cell($width_cell[0],7,'Kiwango cha elimu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['E_level'],1,1,'C',false); // Second column of row 1 

$pdf->SetXY(55,74);
// First row of data 
$pdf->Cell($width_cell[0],7,'wilaya',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['wilaya'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,81);
// First row of data 
$pdf->Cell($width_cell[0],7,'mtaa',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['mtaa'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,88);
// First row of data 
$pdf->Cell($width_cell[0],7,'jina la mwenyekiti',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['jina_mwenyekiti'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,95);
// First row of data 
$pdf->Cell($width_cell[0],7,'kazi',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kazi'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,102);
// First row of data 
$pdf->Cell($width_cell[0],7,'mimba zilizohalibika',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['no_mimba_zilizohalibika'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,109);
// First row of data 
$pdf->Cell($width_cell[0],7,'umri wa mimba zilipoalibika',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['umri_mimba_zilipoalibika'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,116);
// First row of data 
$pdf->Cell($width_cell[0],7,'mimba mwisho ilikuwa mwaka',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['miaka_mimba_mwisho'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,123);
// First row of data 
$pdf->Cell($width_cell[0],7,'njia yakujifungua',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['njia_yakujifungua'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,130);
// First row of data 
$pdf->Cell($width_cell[0],7,' kuzaa mtoto mfu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['mtoto_mfu'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,137);
// First row of data 
$pdf->Cell($width_cell[0],7,'ugonjwa wa moyo',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['moyo'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,144);
// First row of data 
$pdf->Cell($width_cell[0],7,'ugonjwa wa kisukari',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kisukari'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,151);
// First row of data 
$pdf->Cell($width_cell[0],7,'ugonjwa wa kifua kikuu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kifua_kikuu'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,158);
// First row of data 
$pdf->Cell($width_cell[0],7,'kilema cha nyonga',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kilema_nyonga'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,165);
// First row of data 
$pdf->Cell($width_cell[0],7,'kimo',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kimo'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,172);
// First row of data 
$pdf->Cell($width_cell[0],7,'kondo kukwama',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['kondo_kukwama'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,179);
// First row of data 
$pdf->Cell($width_cell[0],7,'kutokwa damu nyingi',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['damu_nyingi'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,186);
// First row of data 
$pdf->Cell($width_cell[0],7,'Tarehe ya hedhi ya mwisho',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['date_hedhi'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,193);
// First row of data 
$pdf->Cell($width_cell[0],7,'Tarehe inayotazamiwa kujifungua',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['date_kujifungua'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,200);
// First row of data 
$pdf->Cell($width_cell[0],7,'kuzaa mara ngapi',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['nokuzaa'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,207);
// First row of data 
$pdf->Cell($width_cell[0],7,'watoto walio hai',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['watoto_hai'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,214);
// First row of data 
$pdf->Cell($width_cell[0],7,'namba chandarua',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['no_chandarua'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,221);
// First row of data 
$pdf->Cell($width_cell[0],7,'group la damu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['blood_group'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,228);
// First row of data 
$pdf->Cell($width_cell[0],7,'vipimo vingine',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST1['vipimo_vingine'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,235);
// First row of data 
$pdf->Cell($width_cell[0],7,'Jina la mwenzi',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST2['name'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,242);
// First row of data 
$pdf->Cell($width_cell[0],7,'umri wa mwenzi',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST2['age'],1,0,'C',false); // Second column of row 1 

$pdf->SetXY(55,249);
// First row of data 
$pdf->Cell($width_cell[0],7,'Kazi ya mwenzi',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST2['job'],1,0,'C',false); // Second column of row 1 


$pdf->SetXY(55,256);
// First row of data 
$pdf->Cell($width_cell[0],7,'Kiwango cha elimu',1,0,'L',false); // First column of row 1 
$pdf->Cell($width_cell[1],7,''. $_REQUEST2['e_level'],1,0,'C',false); // Second column of row 1 

    $pdf->Output();
    ?>