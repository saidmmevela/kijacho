<?php
include('functions.php');


?>
<!DOCTYPE html>
<html>
<head>
<link Rel="stylesheet" Href="index.css" type="text/css">
<title>kijacho and mama health</title>
</head>
<body id="main">
<div id="admcontainer">
<h1 align="center" style="color:#3399CC">Kijacho and Mama Health</h1>
<div class="bar">
<div class="hmbar"><form method="post">
<ul class="ul">
<li class="hmaulli"><a href="index.php">Home</a></li>
<li class="hmaulli"><a><input class="buttn" type="submit" value="About us" name="register"></a></li>
<li class="hmaulli"><a href="login.php">log in</a></li>
</ul></form>
</div></div>

<div>
<div class="pic">

</div>
<form method="post">
<?php
if (isset($_POST['register'])) {
about();
}
else if(isset($_POST['registere'])){
tast();
}

else{
main();
}
?>
</form>
</div>
<div class="buttom">
<div class="hmfooter">
<form method="post"><ul class="ful">
<li class="hmfull"><a href="index.php" >Home</a></li>
<li class="hmfull"><a  href="login.php">log in</a></li></ul>


</form></div><div class="footer">
said_mmevela copyright &copy; 2018</div>
</div>
</div>
</body>
</html>