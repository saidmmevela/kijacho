---------------- Kijacho and Mama Health ---------------

--------------- Server:username=root  ,  no password ------------------

-------------------- Database name = kijacho --------------------------

---------------------------- System  log in account with credential--------------------------------

------------------- Administrator:username=admin ,  password=admin678 --------------------------------------

---------------------  health officer:username=rehemash , password=shemangalere ----------------------------------

----------------------  Pregnant woman:username=happywi , password=wilbertha  ------------------------------------

